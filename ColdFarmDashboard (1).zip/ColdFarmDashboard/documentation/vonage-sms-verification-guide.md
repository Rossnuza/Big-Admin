# Vonage SMS Verification Integration Guide

## Overview

This document provides a detailed guide on the integration of Vonage SMS verification in the Coldfarms application. It covers the setup, configuration, and API usage for developers building both the admin panel and mobile farmer application.

## Table of Contents

1. [System Architecture](#system-architecture)
2. [Configuration](#configuration)
3. [Server Implementation](#server-implementation)
4. [Mobile App Implementation](#mobile-app-implementation)
5. [Admin Panel Features](#admin-panel-features)
6. [Troubleshooting](#troubleshooting)
7. [Security Considerations](#security-considerations)

## System Architecture

The SMS verification system consists of the following components:

1. **Vonage API Service**: External service for sending and verifying SMS codes
2. **Verification Service**: Server-side utility for interacting with Vonage API
3. **Mobile API Endpoints**: REST endpoints for mobile app authentication
4. **Admin API Endpoints**: REST endpoints for verification management
5. **Admin UI**: Interface for monitoring and configuring verification settings

The flow of data is as follows:

```
Mobile App → Mobile API → Verification Service → Vonage API
                                 ↑
Admin Panel → Admin API ←--------+
```

## Configuration

### Environment Variables

The following environment variables must be set:

```
VONAGE_API_KEY=your_api_key
VONAGE_API_SECRET=your_api_secret
```

These credentials are used to authenticate with the Vonage API and should be kept secure.

### Configurable Settings

The following settings can be configured through the admin panel:

| Setting | Default | Description |
|---------|---------|-------------|
| `brandName` | ColdFarms | Brand name shown in SMS messages (max 11 chars) |
| `codeLength` | 4 | Length of verification codes (4-10 digits) |
| `pinExpiry` | 300 | How long a code remains valid (60-900 seconds) |
| `resendTimeout` | 60 | Minimum wait time between code resends (30-300 seconds) |
| `maxAttempts` | 3 | Maximum number of verification attempts (1-10) |

## Server Implementation

### Vonage Service

The core functionality is implemented in `server/utils/vonage-service.ts`, which provides:

- `sendVerificationCode(phone, farmerId?)`: Sends a verification code to a phone number
- `verifyCode(requestId, code)`: Verifies a code entered by the user
- `cancelVerification(requestId)`: Cancels an ongoing verification
- `getVerificationLogs(filters?)`: Retrieves verification logs
- `getVerificationStats()`: Retrieves verification statistics

### Mobile API Endpoints

The mobile API endpoints are implemented in `server/api/mobile-farmer-api.ts`:

#### Send Verification Code

```
POST /api/mobile/farmer/send-code
Body: { "phone": "+237XXXXXXXXX" }
Response: { 
  "message": "Verification code sent", 
  "requestId": "abcd1234..." 
}
```

This endpoint:
1. Validates the phone number format
2. Checks if a farmer with that phone number exists
3. Uses the Vonage service to send a verification code
4. Stores the `requestId` in the farmer's record

#### Verify Code (Login)

```
POST /api/mobile/farmer/login
Body: { 
  "phone": "+237XXXXXXXXX", 
  "passcode": "1234",
  "requestId": "abcd1234..." 
}
```

This endpoint:
1. Validates the phone number and passcode
2. Verifies the code with Vonage using the `requestId`
3. Checks the farmer's verification status
4. Updates the last login timestamp
5. Returns the farmer's information

### Admin API Endpoints

The admin API endpoints are implemented in `server/api/verification-admin-api.ts`:

- `GET /api/admin/verification-logs`: Retrieves verification logs with filtering options
- `GET /api/admin/verification-stats`: Retrieves verification statistics
- `GET /api/admin/verification-settings`: Retrieves verification settings
- `POST /api/admin/verification-settings`: Updates verification settings
- `GET /api/admin/verification-test-connection`: Tests the Vonage API connection
- `POST /api/admin/verification-cancel`: Cancels an ongoing verification
- `POST /api/admin/verification-send`: Manually sends a verification code

## Mobile App Implementation

### Authentication Flow

The mobile app authentication flow should follow these steps:

1. **Phone Number Entry**:
   - User enters their phone number
   - App validates format and sends to `/api/mobile/farmer/check-phone`
   - If the phone number exists, proceed to code verification

2. **Send Verification Code**:
   - Call `/api/mobile/farmer/send-code` with the phone number
   - Store the returned `requestId` for later use
   - Display a countdown timer for code expiration (default: 5 minutes)
   - Show a resend button that becomes active after the timeout (default: 60 seconds)

3. **Code Verification**:
   - User enters the code they received
   - Send the code, phone number, and `requestId` to `/api/mobile/farmer/login`
   - Handle success or failure responses accordingly

### Sample Code (React Native)

```javascript
// Send verification code
const sendVerificationCode = async (phone) => {
  setLoading(true);
  try {
    const response = await fetch('https://api.coldfarms.com/api/mobile/farmer/send-code', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone })
    });
    
    const data = await response.json();
    
    if (response.ok) {
      setRequestId(data.requestId);
      setCodeSent(true);
      startCountdown();
    } else {
      setError(data.message || 'Failed to send verification code');
    }
  } catch (error) {
    setError('Network error. Please try again.');
  } finally {
    setLoading(false);
  }
};

// Verify code
const verifyCode = async () => {
  setLoading(true);
  try {
    const response = await fetch('https://api.coldfarms.com/api/mobile/farmer/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        phone,
        passcode: code,
        requestId
      })
    });
    
    const data = await response.json();
    
    if (response.ok) {
      // Store user data and token
      await SecureStore.setItemAsync('user', JSON.stringify(data.farmer));
      navigation.replace('Home');
    } else {
      setError(data.message || 'Invalid verification code');
    }
  } catch (error) {
    setError('Network error. Please try again.');
  } finally {
    setLoading(false);
  }
};
```

### UI/UX Considerations

1. **Clear Guidance**:
   - Inform the user they will receive an SMS with a verification code
   - Explain this is for security purposes
   - Show the phone number where the code will be sent

2. **Timer Indicators**:
   - Display a countdown for code expiration
   - Show when the resend option will be available

3. **Error Handling**:
   - Show specific error messages for different failure scenarios
   - Provide clear instructions for resolution

4. **Accessibility**:
   - Use large input fields for the code
   - Support auto-reading of the code from SMS if platform allows

## Admin Panel Features

The admin panel provides the following features for verification management:

### Verification Logs

The verification logs section allows administrators to:

- View all verification attempts
- Filter by phone number, status, and date range
- See detailed information including:
  - Timestamp
  - Phone number
  - Farmer name (if applicable)
  - Status (initiated, success, failed, cancelled)
  - Request ID
  - Error messages (if any)

### Statistics Dashboard

The statistics dashboard provides:

- Total number of verification attempts
- Success count
- Failure count
- Success rate (percentage)

This data helps in monitoring the effectiveness of the SMS verification system and identifying potential issues.

### Settings Management

The settings section allows administrators to configure:

- Brand name shown in SMS messages
- Code length
- Code expiration time
- Resend timeout
- Maximum verification attempts

These settings can be adjusted based on security requirements and user experience considerations.

### API Connection Testing

Administrators can test the Vonage API connection to ensure:

- API credentials are valid
- The service is operational
- Account has sufficient credits

### Manual Verification

Administrators can:

- Manually trigger verification codes for specific phone numbers
- Cancel ongoing verifications
- Assist users experiencing difficulties with the automated process

## Troubleshooting

### Common Issues

1. **Code Not Received**:
   - Verify the phone number format is correct (international format)
   - Check if the user's carrier blocks short codes
   - Confirm Vonage account has sufficient credits
   - Check Vonage API logs for delivery failures

2. **Verification Failures**:
   - Ensure the correct `requestId` is being used
   - Verify the code has not expired
   - Check if the maximum attempts have been reached
   - Confirm the code is being entered correctly

3. **API Connection Issues**:
   - Verify API credentials are correct
   - Check network connectivity
   - Confirm Vonage service status

### Debugging Tools

1. **API Logs**:
   - Check server logs for API request/response details
   - Review Vonage dashboard for API activity

2. **Verification Status Check**:
   - Use the admin panel to view verification status
   - Check verification logs for specific request IDs

3. **Test Mode**:
   - Use Vonage test credentials for development
   - Test verification flow in controlled environment

## Security Considerations

### Best Practices

1. **Rate Limiting**:
   - Limit verification attempts per phone number
   - Implement cooldown periods after failed attempts
   - Consider IP-based rate limiting for registration

2. **Secure Storage**:
   - Store verification codes and request IDs securely
   - Never log full verification codes
   - Encrypt sensitive data at rest and in transit

3. **Code Validation**:
   - Validate code format before sending to API
   - Implement server-side validation rules
   - Use HTTPS for all API communication

4. **Account Takeover Prevention**:
   - Require verification for important account changes
   - Implement suspicious activity detection
   - Lock accounts after multiple failed verification attempts

### Compliance

1. **Data Protection**:
   - Store only necessary data for verification
   - Implement data retention policies
   - Follow local regulations for SMS communication

2. **User Consent**:
   - Clearly explain why phone verification is required
   - Obtain explicit consent for SMS communications
   - Provide alternatives when possible

3. **Documentation**:
   - Maintain records of verification activities
   - Document security measures implemented
   - Keep audit logs for verification events

---

## Appendix: Vonage API Documentation

For detailed information about the Vonage Verify API, refer to the official documentation:

- [Vonage Verify API Documentation](https://developer.vonage.com/verify/overview)
- [API Reference](https://developer.vonage.com/api/verify)
- [Error Codes](https://developer.vonage.com/verify/guides/verification-events)

## Integration Testing Checklist

- [ ] Verify successful code delivery to valid phone numbers
- [ ] Test invalid phone number handling
- [ ] Verify code expiration functionality
- [ ] Test resend functionality with timeout
- [ ] Verify maximum attempts limitation
- [ ] Test authentication success flow
- [ ] Test authentication failure flow
- [ ] Verify admin panel logging functionality
- [ ] Test settings update functionality
- [ ] Verify statistics accuracy