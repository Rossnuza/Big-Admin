# Coldfarms Marketplace App Integration Documentation

## Overview
This documentation provides comprehensive guidance for developing the Coldfarms Marketplace app that seamlessly integrates with the admin panel. It covers architecture, API endpoints, data structures, authentication, and integration points to ensure both systems work harmoniously.

## Table of Contents
1. [System Architecture](#system-architecture)
2. [Data Models](#data-models)
3. [API Endpoints](#api-endpoints)
4. [Authentication & Security](#authentication--security)
5. [Integration Points](#integration-points)
6. [Notifications](#notifications)
7. [Development Guidelines](#development-guidelines)
8. [Deployment Considerations](#deployment-considerations)

## System Architecture

### Overall Architecture
```
┌─────────────────────┐        ┌─────────────────────┐
│                     │        │                     │
│    Admin Panel      │◄───────┤  Shared Database    │
│    (Web App)        │        │  (PostgreSQL)       │
│                     │        │                     │
└─────────────────────┘        └─────────┬───────────┘
                                         │
                                         │
                               ┌─────────▼───────────┐
                               │                     │
                               │  Marketplace App    │
                               │  (Mobile App)       │
                               │                     │
                               └─────────────────────┘
```

### Key Components
1. **Shared PostgreSQL Database**: Both apps connect to the same database to ensure data consistency.
2. **RESTful API Layer**: Endpoint structure follows consistent patterns and returns standardized responses.
3. **WebSocket Service**: For real-time notifications and updates.
4. **Authentication Service**: Uses SMS verification with Vonage for marketplace users.

## Data Models

The marketplace app relies on the following core data models that are already defined in the shared schema:

### Products
```typescript
// From shared/schema.ts
// Used for marketplace listings
// Links to inventory items created from approved storage bookings
```

### Orders
```typescript
// Key fields in orders table:
// - customerName: string
// - customerEmail: string
// - total: number
// - status: string (pending, confirmed, preparing, delivering, completed, cancelled)
// - orderDate: Date
// - deliveryAddress: string
// - paymentMethod: string
```

### Order Items
```typescript
// Relates to specific products in an order
// - orderId: number
// - productId: number
// - quantity: number
// - price: number (at time of purchase)
// - unit: string
```

### Delivery Settings
```typescript
// Key fields:
// - minimumOrderAmount: number (default 1500 XAF)
// - baseDeliveryFee: number (default 500 XAF)
// - perKilometerRate: number (default 50 XAF/km)
// - maximumDistance: number (default 15 km)
```

### Consumers (Marketplace Users)
```typescript
// - phone: string (used as unique identifier)
// - name: string
// - email: string (optional)
// - verificationStatus: string (unverified, pending, verified)
// - temporaryPasscode: string (for SMS verification)
// - lastLoginDate: Date
```

### Cart Items
```typescript
// - consumerId: number
// - productId: number
// - quantity: number
```

## API Endpoints

### Authentication APIs
```
POST /api/mobile/consumer/register
  - Request: { phone, name, email? }
  - Response: { success, message, consumerId? }

POST /api/mobile/consumer/verify
  - Request: { phone, code }
  - Response: { success, token?, message }

POST /api/mobile/consumer/login
  - Request: { phone }
  - Response: { success, message, requireVerification? }

POST /api/mobile/consumer/verify-login
  - Request: { phone, code }
  - Response: { success, token?, message }

GET /api/mobile/consumer/profile
  - Headers: Authorization: Bearer {token}
  - Response: { id, name, phone, email, ... }

PUT /api/mobile/consumer/profile
  - Headers: Authorization: Bearer {token}
  - Request: { name?, email?, ... }
  - Response: { success, consumer }
```

### Marketplace APIs
```
GET /api/mobile/products
  - Query: { category?, search?, sort?, page?, limit? }
  - Response: { products: [...], total, page, pageSize }

GET /api/mobile/products/:id
  - Response: { product details with farmer info }

GET /api/mobile/products/categories
  - Response: { categories: [...] }

GET /api/mobile/products/featured
  - Response: { products: [...] }
```

### Cart APIs
```
GET /api/mobile/cart
  - Headers: Authorization: Bearer {token}
  - Response: { items: [...], subtotal, deliveryFee, total }

POST /api/mobile/cart
  - Headers: Authorization: Bearer {token}
  - Request: { productId, quantity }
  - Response: { success, cart }

PUT /api/mobile/cart/:itemId
  - Headers: Authorization: Bearer {token}
  - Request: { quantity }
  - Response: { success, item }

DELETE /api/mobile/cart/:itemId
  - Headers: Authorization: Bearer {token}
  - Response: { success }

DELETE /api/mobile/cart
  - Headers: Authorization: Bearer {token}
  - Response: { success }
```

### Order APIs
```
GET /api/mobile/orders
  - Headers: Authorization: Bearer {token}
  - Query: { status?, page?, limit? }
  - Response: { orders: [...], total, page, pageSize }

GET /api/mobile/orders/:id
  - Headers: Authorization: Bearer {token}
  - Response: { order details with items }

POST /api/mobile/orders
  - Headers: Authorization: Bearer {token}
  - Request: { deliveryAddress, deliveryLocation, paymentMethod }
  - Response: { success, order }

PUT /api/mobile/orders/:id/cancel
  - Headers: Authorization: Bearer {token}
  - Response: { success, order }
```

### Delivery APIs
```
GET /api/mobile/delivery/settings
  - Response: { minimumOrderAmount, baseDeliveryFee, perKilometerRate, maximumDistance }

GET /api/mobile/delivery/estimate
  - Query: { latitude, longitude, subtotal }
  - Response: { deliveryFee, distance, estimatedDeliveryTime }
```

## Authentication & Security

### Vonage SMS Verification Flow
1. User registers or requests login with phone number
2. System generates a 6-digit code and sends via Vonage SMS
3. User enters code in app
4. System verifies code and issues JWT token
5. JWT token used for subsequent authenticated requests

### Security Best Practices
1. All API calls use HTTPS
2. JWTs expire after 30 days
3. Sensitive operations require re-verification
4. Rate limiting implemented on auth endpoints
5. Input validation for all requests

## Integration Points

### Real-time Updates via WebSocket
The marketplace app should connect to the same WebSocket service as the admin panel:

```javascript
// Client-side WebSocket connection
const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
const wsUrl = `${protocol}//${API_BASE_URL}/ws`;
const socket = new WebSocket(wsUrl);

// Listen for specific events
socket.onmessage = (event) => {
  const data = JSON.parse(event.data);
  
  switch (data.type) {
    case "order_status_updated":
      // Update order status in UI
      break;
    case "product_inventory_changed":
      // Update product availability
      break;
    // Handle other event types
  }
};
```

### Admin Events to Marketplace
The following events from admin panel are relevant to marketplace:
1. Order status changes
2. Product availability updates
3. Price changes
4. Delivery setting updates

### Marketplace Events to Admin
The following events from marketplace should be broadcast to admin:
1. New order placed
2. Order cancellation requests
3. New consumer registrations
4. High demand for specific products

## Notifications

### Push Notification Integration
Implement Firebase Cloud Messaging (FCM) to enable push notifications:

1. Order status updates
2. Special promotions
3. Delivery alerts
4. Restocked items (for items in wishlist)

### Notification Types
```typescript
enum NotificationType {
  ORDER_STATUS_CHANGE = 'order_status_change',
  DELIVERY_UPDATE = 'delivery_update',
  PROMOTION = 'promotion',
  PRODUCT_RESTOCK = 'product_restock',
  ACCOUNT = 'account'
}
```

## Development Guidelines

### API Response Format
All API responses should follow this standard format:
```typescript
interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
  meta?: {
    total?: number;
    page?: number;
    pageSize?: number;
  };
}
```

### Error Handling
Implement consistent error handling:
```typescript
// HTTP Status Codes
// 200 - Success
// 400 - Bad Request (client error)
// 401 - Unauthorized
// 403 - Forbidden
// 404 - Not Found
// 500 - Server Error

// Example error response
{
  "success": false,
  "error": "INVALID_INPUT",
  "message": "The provided input contains invalid data",
  "details": [
    { "field": "quantity", "message": "Must be greater than 0" }
  ]
}
```

### Versioning Strategy
API endpoints should include versioning to support future changes:
```
/api/v1/mobile/products
```

## Database Considerations

### Schema Alignment
Ensure consistent schema usage:
1. The `customerName` and `customerEmail` fields in the orders table are used (not `consumerId`)
2. Always use explicit column selection in Drizzle queries:
   ```typescript
   const [order] = await db.select({
     id: orders.id,
     customerName: orders.customerName,
     customerEmail: orders.customerEmail,
     // other fields...
   }).from(orders).where(eq(orders.id, id));
   ```

### Data Querying
1. Use pagination for all list endpoints
2. Include proper indexes for frequently queried fields
3. Use transactions for operations that modify multiple tables

## Deployment Considerations

### Environment Configuration
Set up the following environment variables:
```
DATABASE_URL - Shared PostgreSQL database URL
VONAGE_API_KEY - For SMS verification
VONAGE_API_SECRET - For SMS verification
JWT_SECRET - For authentication tokens
FCM_SERVER_KEY - For push notifications
```

### Monitoring & Logging
Implement logging for:
1. Failed payment attempts
2. Authentication failures
3. Order status transitions
4. API errors
5. Performance metrics

### Performance Optimization
1. Implement caching for product listings and categories
2. Use database indexes for frequently queried fields
3. Optimize image sizes and implement CDN for product images
4. Implement lazy loading for product lists

## Testing Recommendations

### Integration Tests
Test scenarios that verify seamless integration:
1. Order creation in marketplace appearing in admin panel
2. Status updates in admin panel reflecting in marketplace app
3. Inventory changes affecting product availability

### API Tests
1. Authentication flow tests
2. Order creation and management
3. Cart operations
4. Product search and filtering

## Troubleshooting Common Integration Issues

### Orders Not Appearing in Admin Panel
Check:
1. Are the order fields matching the database schema?
2. Is the WebSocket notification being sent?
3. Is the admin panel properly refreshing data?

### Product Updates Not Reflecting
Check:
1. Cache invalidation
2. WebSocket connections
3. Database query specifics

### Authentication Issues
1. Verify JWT secret matches between services
2. Check token expiration logic
3. Ensure proper payload structure in tokens