# Coldfarms Farmer Mobile App Integration Guide

## Overview

This guide documents the API endpoints, data structures, and integration points between the Coldfarms admin panel and the farmer mobile application. Following these guidelines will ensure proper communication between both systems.

## Table of Contents

1. [Authentication Flow](#authentication-flow)
2. [API Endpoints](#api-endpoints)
3. [Data Structures](#data-structures)
4. [WebSocket Integration](#websocket-integration)
5. [SMS Verification](#sms-verification)
6. [Error Handling](#error-handling)
7. [Best Practices](#best-practices)

## Authentication Flow

### Registration Process

The farmer registration process follows these steps:

1. Farmer enters personal information (name, phone, region, etc.)
2. System checks if the phone number is already registered
3. If new, a verification code is sent via SMS using Vonage
4. Farmer enters the verification code
5. System validates the code and creates the account with `verificationStatus: "pending"`
6. Admin approves the account, changing status to `verificationStatus: "verified"`
7. Farmer can now log in to the mobile app

### Login Process

The login process follows these steps:

1. Farmer enters phone number
2. System checks if the phone number exists and the account is verified
3. If the account exists, a verification code is sent via SMS
4. Farmer enters the verification code
5. System validates the code and grants access if valid
6. The `lastLogin` timestamp is updated

### Session Management

- The mobile app should store a token or session identifier securely
- Include this token in the `Authorization` header for all authenticated requests
- Sessions expire after a configurable period (default: 30 days)

## API Endpoints

### Authentication Endpoints

#### Check Phone Number
```
POST /api/mobile/farmer/check-phone
Body: { "phone": "+237XXXXXXXXX" }
Response: { "exists": true|false, "verificationStatus": "verified"|"pending" }
```

#### Send Verification Code
```
POST /api/mobile/farmer/send-code
Body: { "phone": "+237XXXXXXXXX" }
Response: { "message": "Verification code sent", "requestId": "abcd1234..." }
```

#### Register Farmer
```
POST /api/mobile/farmer/register
Body: {
  "name": "John Doe",
  "phone": "+237XXXXXXXXX",
  "region": "Central",
  "location": "Yaoundé",
  "farmType": "Fruit",
  "marketplaceOptIn": true,
  "storageAgreement": true
}
Response: { "message": "Registration successful", "farmer": {...} }
```

#### Login
```
POST /api/mobile/farmer/login
Body: { 
  "phone": "+237XXXXXXXXX", 
  "passcode": "1234",
  "requestId": "abcd1234..." 
}
Response: { 
  "message": "Login successful",
  "farmer": {
    "id": 123,
    "name": "John Doe",
    "phone": "+237XXXXXXXXX",
    "region": "Central",
    "email": "john@example.com",
    "verificationStatus": "verified",
    "marketplaceOptIn": true,
    "storageAgreement": true
  }
}
```

### Content Endpoints

#### Get Categories
```
GET /api/mobile/farmer/categories
Response: [
  { "id": 1, "name": "Vegetables", "description": "...", "icon": "..." },
  { "id": 2, "name": "Fruits", "description": "...", "icon": "..." }
]
```

#### Get Product Types by Category
```
GET /api/mobile/farmer/product-types-by-category/:categoryName
Response: [
  { "id": 1, "name": "Tomatoes", "categoryId": 1, "unit": "kg", "icon": "..." },
  { "id": 2, "name": "Carrots", "categoryId": 1, "unit": "kg", "icon": "..." }
]
```

#### Get All Product Types
```
GET /api/mobile/farmer/product-types
Response: [
  { "id": 1, "name": "Tomatoes", "categoryId": 1, "unit": "kg", "icon": "..." },
  { "id": 2, "name": "Carrots", "categoryId": 1, "unit": "kg", "icon": "..." },
  { "id": 3, "name": "Apples", "categoryId": 2, "unit": "kg", "icon": "..." }
]
```

### Inventory Management

#### Get Farmer's Inventory
```
GET /api/mobile/farmer/inventory
Headers: { "Authorization": "Bearer TOKEN" }
Response: [
  {
    "id": 1,
    "farmerId": 123,
    "productTypeId": 1,
    "productName": "Tomatoes",
    "quantity": 50,
    "unit": "kg",
    "harvestDate": "2025-04-01T12:00:00Z",
    "expiryDate": "2025-04-15T12:00:00Z",
    "price": 500,
    "currency": "XAF",
    "status": "available",
    "listedOnMarketplace": true
  }
]
```

#### Add Inventory Item
```
POST /api/mobile/farmer/inventory
Headers: { "Authorization": "Bearer TOKEN" }
Body: {
  "productTypeId": 1,
  "quantity": 50,
  "harvestDate": "2025-04-01T12:00:00Z",
  "expiryDate": "2025-04-15T12:00:00Z",
  "price": 500,
  "listedOnMarketplace": true
}
Response: { "message": "Inventory added successfully", "inventory": {...} }
```

#### Update Inventory Item
```
PUT /api/mobile/farmer/inventory/:id
Headers: { "Authorization": "Bearer TOKEN" }
Body: {
  "quantity": 45,
  "price": 550,
  "listedOnMarketplace": true
}
Response: { "message": "Inventory updated successfully", "inventory": {...} }
```

#### Delete Inventory Item
```
DELETE /api/mobile/farmer/inventory/:id
Headers: { "Authorization": "Bearer TOKEN" }
Response: { "message": "Inventory deleted successfully" }
```

### Storage Booking

#### Get Farmer's Storage Bookings
```
GET /api/mobile/farmer/storage-bookings
Headers: { "Authorization": "Bearer TOKEN" }
Response: [
  {
    "id": 1,
    "farmerId": 123,
    "storageUnitId": "CSU-CA-YA-001",
    "productTypeId": 1,
    "productName": "Tomatoes",
    "quantity": 50,
    "unit": "kg",
    "startDate": "2025-04-01T12:00:00Z",
    "endDate": "2025-04-15T12:00:00Z",
    "status": "approved",
    "totalCost": 7000,
    "currency": "XAF"
  }
]
```

#### Create Storage Booking
```
POST /api/mobile/farmer/storage-bookings
Headers: { "Authorization": "Bearer TOKEN" }
Body: {
  "storageUnitId": "CSU-CA-YA-001",
  "productTypeId": 1,
  "quantity": 50,
  "startDate": "2025-04-01T12:00:00Z",
  "endDate": "2025-04-15T12:00:00Z"
}
Response: { "message": "Booking request submitted", "booking": {...} }
```

#### Cancel Storage Booking
```
PUT /api/mobile/farmer/storage-bookings/:id/cancel
Headers: { "Authorization": "Bearer TOKEN" }
Response: { "message": "Booking cancelled successfully" }
```

### Orders & Marketplace

#### Get Farmer's Orders
```
GET /api/mobile/farmer/orders
Headers: { "Authorization": "Bearer TOKEN" }
Response: [
  {
    "id": 1,
    "customerId": 456,
    "customerName": "Alice Smith",
    "items": [
      {
        "id": 1,
        "productId": 1,
        "productName": "Tomatoes",
        "quantity": 10,
        "unit": "kg",
        "price": 500,
        "totalPrice": 5000
      }
    ],
    "status": "pending",
    "totalAmount": 5000,
    "currency": "XAF",
    "createdAt": "2025-04-01T12:00:00Z"
  }
]
```

#### Update Order Status
```
PUT /api/mobile/farmer/orders/:id/status
Headers: { "Authorization": "Bearer TOKEN" }
Body: { "status": "accepted"|"rejected"|"completed" }
Response: { "message": "Order status updated successfully" }
```

## Data Structures

### Farmer

```typescript
interface Farmer {
  id: number;
  name: string;
  phone: string;
  email?: string;
  region: string;
  location: string;
  farmType: string;
  registrationType: "admin" | "self";
  verificationStatus: "verified" | "pending";
  temporaryPasscode?: string;
  marketplaceOptIn: boolean;
  storageAgreement: boolean;
  lastLogin?: Date;
  createdAt: Date;
  updatedAt: Date;
}
```

### Product Type

```typescript
interface ProductType {
  id: number;
  name: string;
  categoryId: number;
  categoryName: string;
  unit: string;
  icon?: string;
  description?: string;
  createdAt: Date;
  updatedAt: Date;
}
```

### Inventory Item

```typescript
interface FarmerInventory {
  id: number;
  farmerId: number;
  productTypeId: number;
  productName: string;
  quantity: number;
  unit: string;
  harvestDate: Date;
  expiryDate: Date;
  price: number;
  currency: string;
  status: "available" | "sold" | "expired";
  listedOnMarketplace: boolean;
  createdAt: Date;
  updatedAt: Date;
}
```

### Storage Booking

```typescript
interface StorageBooking {
  id: number;
  farmerId: number;
  storageUnitId: string;
  storageUnitLocation?: string;
  productTypeId: number;
  productName: string;
  quantity: number;
  unit: string;
  startDate: Date;
  endDate: Date;
  status: "pending" | "approved" | "rejected" | "cancelled" | "completed";
  adminNotes?: string;
  totalCost: number;
  currency: string;
  createdAt: Date;
  updatedAt: Date;
}
```

### Order

```typescript
interface Order {
  id: number;
  customerId: number;
  customerName: string;
  items: OrderItem[];
  status: "pending" | "accepted" | "rejected" | "completed";
  totalAmount: number;
  currency: string;
  createdAt: Date;
  updatedAt: Date;
}

interface OrderItem {
  id: number;
  orderId: number;
  inventoryId: number;
  productId: number;
  productName: string;
  quantity: number;
  unit: string;
  price: number;
  totalPrice: number;
}
```

## WebSocket Integration

### Connection Setup

1. Establish WebSocket connection:
   ```javascript
   const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
   const wsUrl = `${protocol}//${window.location.host}/ws`;
   const socket = new WebSocket(wsUrl);
   ```

2. Listen for connection events:
   ```javascript
   socket.onopen = () => {
     console.log("WebSocket connection established");
     // Authenticate the connection
     authenticate(socket, farmerId);
   };
   
   socket.onclose = () => {
     console.log("WebSocket connection closed");
     // Implement reconnection logic
   };
   ```

### Authentication

Authenticate the WebSocket connection after establishing it:

```javascript
function authenticate(socket, farmerId) {
  if (socket.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify({
      type: "authenticate",
      farmerId: farmerId,
      timestamp: new Date()
    }));
  }
}
```

### Message Types

1. **Authentication Response**:
   ```javascript
   {
     type: "authentication_result",
     success: true,
     message: "Authentication successful",
     timestamp: "2025-04-01T12:00:00Z"
   }
   ```

2. **Order Notification**:
   ```javascript
   {
     type: "new_order",
     orderId: 123,
     customerName: "Alice Smith",
     totalAmount: 5000,
     timestamp: "2025-04-01T12:00:00Z"
   }
   ```

3. **Storage Booking Status**:
   ```javascript
   {
     type: "booking_status_update",
     bookingId: 123,
     status: "approved",
     message: "Your storage booking has been approved",
     timestamp: "2025-04-01T12:00:00Z"
   }
   ```

4. **Admin Notification**:
   ```javascript
   {
     type: "admin_notification",
     title: "System Maintenance",
     message: "The system will undergo maintenance on April 15",
     timestamp: "2025-04-01T12:00:00Z"
   }
   ```

### Message Handling

```javascript
socket.onmessage = (event) => {
  try {
    const message = JSON.parse(event.data);
    
    switch (message.type) {
      case "authentication_result":
        handleAuthResult(message);
        break;
      case "new_order":
        handleNewOrder(message);
        break;
      case "booking_status_update":
        handleBookingUpdate(message);
        break;
      case "admin_notification":
        handleAdminNotification(message);
        break;
      default:
        console.log("Unknown message type:", message.type);
    }
  } catch (error) {
    console.error("Error processing WebSocket message", error);
  }
};
```

## SMS Verification

### Verification Flow

1. **Send Code**:
   - Call `/api/mobile/farmer/send-code` with the phone number
   - Store the returned `requestId` for verification

2. **Verify Code**:
   - When the user enters the code, send it with the `requestId` to `/api/mobile/farmer/login`
   - The system will validate the code with Vonage

3. **Error Handling**:
   - If verification fails, display the error message to the user
   - Provide a resend option after the timeout period (default: 60 seconds)

### UI/UX Best Practices

1. Show a countdown timer for code expiration (default: 5 minutes)
2. Show a secondary timer for resend capability (default: 1 minute)
3. Inform users that standard SMS charges may apply
4. Create a fallback mechanism for areas with poor cellular coverage

## Error Handling

### Common Error Responses

```javascript
{
  message: "Error message here",
  error: "Optional detailed error description",
  code: 123  // Optional error code
}
```

### HTTP Status Codes

- `200`: Success
- `201`: Created successfully
- `400`: Bad request (invalid input)
- `401`: Unauthorized (not logged in)
- `403`: Forbidden (not allowed)
- `404`: Not found
- `409`: Conflict (e.g., duplicate record)
- `500`: Server error

### Error Handling Strategy

1. Display user-friendly error messages
2. Implement retry logic for network failures
3. Cache data when possible to support offline functionality
4. Log errors for debugging but remove sensitive information

## Best Practices

### Security

1. **Never store sensitive data in local storage**
   - Use secure storage mechanisms for tokens
   - Do not store passwords or PINs

2. **Implement proper logout**
   - Clear all stored tokens and sensitive data
   - Inform the server to invalidate the session

3. **Secure API requests**
   - Always use HTTPS
   - Include authorization headers for authenticated endpoints
   - Validate all server responses before processing

### Performance

1. **Minimize network requests**
   - Batch API calls when possible
   - Implement intelligent caching
   - Use pagination for large datasets

2. **Optimize image loading**
   - Use thumbnails and progressive loading
   - Compress images for mobile network conditions
   - Cache images locally when appropriate

3. **Implement offline capabilities**
   - Allow forms to be filled offline
   - Queue transactions for later submission
   - Provide clear sync status indicators

### UX/UI

1. **Provide clear feedback**
   - Show loading states for all async operations
   - Confirm successful actions with visual feedback
   - Use intuitive error messages

2. **Support multilingual content**
   - The primary languages in Cameroon are French and English
   - Allow switching between languages
   - Use universal icons to supplement text

3. **Design for diverse devices**
   - Support various screen sizes
   - Optimize for low-end devices common in rural areas
   - Consider high-contrast mode for outdoor use

---

## Appendix A: Environment Configuration

### Development Environment

- API base URL: `https://dev-api.coldfarms.com`
- WebSocket URL: `wss://dev-api.coldfarms.com/ws`
- Vonage test mode: Enabled (uses test credentials)

### Production Environment

- API base URL: `https://api.coldfarms.com`
- WebSocket URL: `wss://api.coldfarms.com/ws`
- Vonage test mode: Disabled (uses production credentials)

### Configuration Parameters

| Parameter | Development | Production | Description |
|-----------|-------------|------------|-------------|
| `API_TIMEOUT` | 30000 | 10000 | API request timeout in ms |
| `WEBSOCKET_RECONNECT_DELAY` | 5000 | 3000 | WS reconnection delay in ms |
| `MAX_RETRY_ATTEMPTS` | 5 | 3 | Max API retry attempts |
| `CACHE_DURATION` | 300 | 900 | Cache duration in seconds |

## Appendix B: API Update Schedule

| Version | Release Date | Features | Breaking Changes |
|---------|--------------|----------|------------------|
| v1.0 | Current | Basic functionality | N/A |
| v1.1 | May 2025 | Enhanced marketplace | None |
| v2.0 | July 2025 | Payments, analytics | Auth token format |