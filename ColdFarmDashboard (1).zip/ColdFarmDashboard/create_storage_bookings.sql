CREATE TABLE IF NOT EXISTS storage_bookings (
  id SERIAL PRIMARY KEY,
  farmer_id INTEGER NOT NULL,
  storage_unit_id INTEGER NOT NULL,
  product_name TEXT NOT NULL,
  quantity REAL NOT NULL,
  unit TEXT NOT NULL,
  request_date TIMESTAMP NOT NULL DEFAULT NOW(),
  start_date TIMESTAMP NOT NULL,
  end_date TIMESTAMP,
  status TEXT NOT NULL DEFAULT 'pending',
  admin_notes TEXT,
  farmer_notes TEXT,
  last_updated TIMESTAMP NOT NULL DEFAULT NOW(),
  inventory_item_id INTEGER
);

CREATE INDEX IF NOT EXISTS storage_bookings_farmer_id_idx ON storage_bookings (farmer_id);
CREATE INDEX IF NOT EXISTS storage_bookings_storage_unit_id_idx ON storage_bookings (storage_unit_id);
CREATE INDEX IF NOT EXISTS storage_bookings_status_idx ON storage_bookings (status);