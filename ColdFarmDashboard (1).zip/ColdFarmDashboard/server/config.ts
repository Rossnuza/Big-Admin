/**
 * Application configuration
 * Centralizes environment variable handling with proper defaults
 */

// Database configuration
export const DB_CONFIG = {
  connectionString: process.env.DATABASE_URL
};

// Server configuration
export const SERVER_CONFIG = {
  port: process.env.PORT || 5000,
  host: '0.0.0.0',
  nodeEnv: process.env.NODE_ENV || 'development',
};

// Session configuration
export const SESSION_CONFIG = {
  secret: process.env.SESSION_SECRET || 'coldfarms-secret',
  cookie: {
    maxAge: 24 * 60 * 60 * 1000, // 24 hours
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    sameSite: process.env.NODE_ENV === 'production' ? 'strict' : 'lax',
  },
  name: 'coldfarms.sid',
};

// Rate limiting configuration
export const RATE_LIMIT_CONFIG = {
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: process.env.NODE_ENV === 'production' 
    ? 200  // 200 requests per 15 minutes in production
    : 1000, // 1000 requests per 15 minutes in development
};

// CORS configuration
export const CORS_CONFIG = {
  origin: '*', // Allow all origins for development and mobile app access
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true,
};

// Logging configuration 
export const LOGGING_CONFIG = {
  level: process.env.NODE_ENV === 'production' ? 'info' : 'debug',
  redactedFields: ['password', 'token', 'secret', 'authorization'],
};

// Export default config object
export default {
  db: DB_CONFIG,
  server: SERVER_CONFIG,
  session: SESSION_CONFIG,
  rateLimit: RATE_LIMIT_CONFIG,
  cors: CORS_CONFIG,
  logging: LOGGING_CONFIG,
};