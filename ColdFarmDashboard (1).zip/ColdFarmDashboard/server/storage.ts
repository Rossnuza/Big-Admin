import { 
  users, type User, type InsertUser,
  storageUnits, type StorageUnit, type InsertStorageUnit,
  farmers, type Farmer, type InsertFarmer,
  farmerInventory, type FarmerInventory, type InsertFarmerInventory,
  products, type Product, type InsertProduct,
  activities, type Activity, type InsertActivity,
  orders, type Order, type InsertOrder,
  orderItems, type OrderItem, type InsertOrderItem,
  storageBookings, type StorageBooking, type InsertStorageBooking,
  categories, type Category, type InsertCategory,
  productTypes, type ProductType, type InsertProductType,
  consumers, type Consumer, type InsertConsumer,
  cartItems, type CartItem, type InsertCartItem,
  deliverySettings, type DeliverySetting, type InsertDeliverySetting
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import { broadcastUpdate } from "./utils/websocket";
import session from "express-session";

export interface IStorage {
  // Session store for authentication
  sessionStore: any;

  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Storage Units
  getStorageUnits(): Promise<StorageUnit[]>;
  getStorageUnit(id: number): Promise<StorageUnit | undefined>;
  getStorageUnitByUnitId(unitId: string): Promise<StorageUnit | undefined>;
  createStorageUnit(storageUnit: InsertStorageUnit): Promise<StorageUnit>;
  updateStorageUnit(id: number, storageUnit: Partial<StorageUnit>): Promise<StorageUnit | undefined>;
  deleteStorageUnit(id: number): Promise<boolean>;
  
  // Farmers
  getFarmers(): Promise<Farmer[]>;
  getFarmer(id: number): Promise<Farmer | undefined>;
  getFarmerByPhone(phone: string): Promise<Farmer | undefined>;
  createFarmer(farmer: InsertFarmer): Promise<Farmer>;
  updateFarmer(id: number, farmer: Partial<Farmer>): Promise<Farmer | undefined>;
  updateFarmerVerification(id: number, verificationStatus: string, temporaryPasscode?: string): Promise<Farmer | undefined>;
  updateFarmerLastLogin(id: number): Promise<Farmer | undefined>;
  deleteFarmer(id: number): Promise<boolean>;
  getTopFarmers(limit: number): Promise<Farmer[]>;
  
  // Consumers
  getConsumers(): Promise<Consumer[]>;
  getConsumer(id: number): Promise<Consumer | undefined>;
  getConsumerByPhone(phone: string): Promise<Consumer | undefined>;
  createConsumer(consumer: InsertConsumer): Promise<Consumer>;
  updateConsumer(id: number, consumer: Partial<Consumer>): Promise<Consumer | undefined>;
  updateConsumerVerification(id: number, verificationStatus: string, temporaryPasscode?: string): Promise<Consumer | undefined>;
  updateConsumerLastLogin(id: number): Promise<Consumer | undefined>;
  deleteConsumer(id: number): Promise<boolean>;
  
  // Farmer Inventory
  getFarmerInventory(farmerId: number): Promise<FarmerInventory[]>;
  getFarmerInventoryItem(id: number): Promise<FarmerInventory | undefined>;
  createFarmerInventory(inventory: InsertFarmerInventory): Promise<FarmerInventory>;
  updateFarmerInventory(id: number, inventory: Partial<FarmerInventory>): Promise<FarmerInventory | undefined>;
  deleteFarmerInventory(id: number): Promise<boolean>;
  getAllFarmerInventories(): Promise<FarmerInventory[]>;
  
  // Products
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  getProductsByFarmer(farmerId: number): Promise<Product[]>;
  getMarketplaceProducts(): Promise<Product[]>; // Only products that are set to be listed
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<Product>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;
  
  // Cart Items
  getCartItems(consumerId: number): Promise<CartItem[]>;
  getCartItem(id: number): Promise<CartItem | undefined>;
  createCartItem(cartItem: InsertCartItem): Promise<CartItem>;
  updateCartItemQuantity(id: number, quantity: number): Promise<CartItem | undefined>;
  deleteCartItem(id: number): Promise<boolean>;
  clearCart(consumerId: number): Promise<boolean>;
  
  // Activities
  getActivities(limit?: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  
  // Orders
  getOrders(): Promise<Order[]>;
  getOrdersByConsumer(consumerId: number): Promise<Order[]>;
  getOrdersByStatus(status: string): Promise<Order[]>;
  getOrder(id: number): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: number, status: string): Promise<Order | undefined>;
  updateOrderPaymentStatus(id: number, paymentStatus: string, paymentReference?: string): Promise<Order | undefined>;
  
  // Order Items
  getOrderItems(orderId: number): Promise<OrderItem[]>;
  createOrderItem(orderItem: InsertOrderItem): Promise<OrderItem>;
  
  // Delivery Settings
  getDeliverySettings(): Promise<DeliverySetting | undefined>;
  createDeliverySettings(settings: InsertDeliverySetting): Promise<DeliverySetting>;
  updateDeliverySettings(id: number, settings: Partial<DeliverySetting>): Promise<DeliverySetting | undefined>;
  
  // Storage Bookings
  getStorageBookings(): Promise<StorageBooking[]>;
  getStorageBookingsByFarmer(farmerId: number): Promise<StorageBooking[]>;
  getStorageBookingsByStatus(status: string): Promise<StorageBooking[]>;
  getStorageBooking(id: number): Promise<StorageBooking | undefined>;
  createStorageBooking(booking: InsertStorageBooking): Promise<StorageBooking>;
  updateStorageBooking(id: number, booking: Partial<StorageBooking>): Promise<StorageBooking | undefined>;
  updateStorageBookingStatus(id: number, status: string, adminNotes?: string): Promise<StorageBooking | undefined>;
  deleteStorageBooking(id: number): Promise<boolean>;
  
  // Analytics
  getStorageUtilization(): Promise<{location: string, capacityPercentage: number}[]>;
  getMonthlyRevenue(): Promise<{month: string, revenue: number}[]>;
  getFarmerParticipation(): Promise<{optIn: number, optOut: number}>;
  getMarketplaceAnalytics(): Promise<{
    totalOrders: number;
    pendingOrders: number;
    totalRevenue: number;
    topProducts: {productName: string, quantity: number}[];
  }>;
  
  // Categories
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  getCategoryByName(name: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, category: Partial<Category>): Promise<Category | undefined>;
  deleteCategory(id: number): Promise<boolean>;
  
  // Product Types
  getProductTypes(): Promise<ProductType[]>;
  getProductTypesByCategory(category: string): Promise<ProductType[]>;
  getProductType(id: number): Promise<ProductType | undefined>;
  createProductType(productType: InsertProductType): Promise<ProductType>;
  updateProductType(id: number, productType: Partial<ProductType>): Promise<ProductType | undefined>;
  deleteProductType(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  sessionStore: any;
  
  private users: Map<number, User>;
  private storageUnits: Map<number, StorageUnit>;
  private farmers: Map<number, Farmer>;
  private consumers: Map<number, Consumer>;
  private farmerInventories: Map<number, FarmerInventory>;
  private products: Map<number, Product>;
  private activities: Map<number, Activity>;
  private orders: Map<number, Order>;
  private orderItems: Map<number, OrderItem>;
  private cartItems: Map<number, CartItem>;
  private storageBookings: Map<number, StorageBooking>;
  private categories: Map<number, Category>;
  private productTypes: Map<number, ProductType>;
  private deliverySettings: Map<number, DeliverySetting>;
  
  private currentUserId: number;
  private currentStorageUnitId: number;
  private currentFarmerId: number;
  private currentConsumerId: number;
  private currentFarmerInventoryId: number;
  private currentProductId: number;
  private currentActivityId: number;
  private currentOrderId: number;
  private currentOrderItemId: number;
  private currentCartItemId: number;
  private currentStorageBookingId: number;
  private currentCategoryId: number;
  private currentProductTypeId: number;
  private currentDeliverySettingId: number;

  constructor() {
    // Initialize session store with memorystore
    const MemoryStore = require('memorystore')(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
    this.users = new Map();
    this.storageUnits = new Map();
    this.farmers = new Map();
    this.consumers = new Map();
    this.farmerInventories = new Map();
    this.products = new Map();
    this.activities = new Map();
    this.orders = new Map();
    this.orderItems = new Map();
    this.cartItems = new Map();
    this.storageBookings = new Map();
    this.categories = new Map();
    this.productTypes = new Map();
    this.deliverySettings = new Map();
    
    this.currentUserId = 1;
    this.currentStorageUnitId = 1;
    this.currentFarmerId = 1;
    this.currentConsumerId = 1;
    this.currentFarmerInventoryId = 1;
    this.currentProductId = 1;
    this.currentActivityId = 1;
    this.currentOrderId = 1;
    this.currentOrderItemId = 1;
    this.currentCartItemId = 1;
    this.currentStorageBookingId = 1;
    this.currentCategoryId = 1;
    this.currentProductTypeId = 1;
    this.currentDeliverySettingId = 1;
    
    // Create default delivery settings
    this.createDeliverySettings({
      minimumOrderAmount: 1500, // 1500 XAF minimum order
      baseDeliveryFee: 500,     // 500 XAF base delivery fee
      perKilometerFee: 50,      // 50 XAF per km
      maximumDeliveryRadius: 15 // 15 km max delivery radius
    });
    
    // Initialize with admin user
    this.createUser({
      username: "admin",
      password: "admin123",
      name: "James Wilson",
      role: "administrator",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
    });
    
    // Initialize with sample storage units
    this.createStorageUnit({
      unitId: "CSU-001",
      location: "Amsterdam Central Market",
      temperature: 3.5,
      capacity: 75,
      maxCapacity: 100,
      status: "operational",
      lastMaintenance: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
      nextMaintenance: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000),
      solarPanelStatus: "operational",
      batteryLevel: 85
    });
    
    this.createStorageUnit({
      unitId: "CSU-002",
      location: "Rotterdam Market Square",
      temperature: 2.8,
      capacity: 90,
      maxCapacity: 100,
      status: "operational",
      lastMaintenance: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000),
      nextMaintenance: new Date(Date.now() + 75 * 24 * 60 * 60 * 1000),
      solarPanelStatus: "operational",
      batteryLevel: 92
    });
    
    this.createStorageUnit({
      unitId: "CSU-003",
      location: "Utrecht Farmers Market",
      temperature: 4.7,
      capacity: 45,
      maxCapacity: 100,
      status: "maintenance",
      lastMaintenance: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000),
      nextMaintenance: new Date(),
      solarPanelStatus: "operational",
      batteryLevel: 76
    });
    
    this.createStorageUnit({
      unitId: "CSU-004",
      location: "Amsterdam North Market",
      temperature: null,
      capacity: 0,
      maxCapacity: 100,
      status: "offline",
      lastMaintenance: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000),
      nextMaintenance: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
      solarPanelStatus: "offline",
      batteryLevel: 0
    });
    
    // Initialize with sample farmers
    this.createFarmer({
      name: "Green Valley Farms",
      region: "Amsterdam Region",
      contactPerson: "Jan Bakker",
      phone: "+31 20 123 4567",
      email: "info@greenvalleyfarms.nl",
      joinDate: new Date(Date.now() - 180 * 24 * 60 * 60 * 1000),
      marketplaceOptIn: true,
      storageAgreement: true,
      avatar: "https://images.unsplash.com/photo-1560343090-f0409e92791a?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
      notes: "Premium organic producer",
      registrationType: "admin",
      verificationStatus: "verified",
      lastLogin: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)
    });
    
    this.createFarmer({
      name: "Fresh Harvest Co-op",
      region: "Rotterdam Area",
      contactPerson: "Eva Jansen",
      phone: "+31 10 765 4321",
      email: "contact@freshharvestcoop.nl",
      joinDate: new Date(Date.now() - 120 * 24 * 60 * 60 * 1000),
      marketplaceOptIn: true,
      storageAgreement: true,
      avatar: "https://images.unsplash.com/photo-1507914997326-f351f8d0ea6a?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
      notes: "Cooperative of small-scale farmers",
      registrationType: "admin",
      verificationStatus: "verified",
      lastLogin: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000)
    });
    
    this.createFarmer({
      name: "Organic Roots",
      region: "Utrecht Region",
      contactPerson: "Thomas de Vries",
      phone: "+31 30 987 6543",
      email: "hello@organicroots.nl",
      joinDate: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000),
      marketplaceOptIn: true,
      storageAgreement: true,
      avatar: "https://images.unsplash.com/photo-1516211697506-8360dbcfe9a4?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
      notes: "Specializes in root vegetables",
      registrationType: "admin",
      verificationStatus: "verified",
      lastLogin: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000)
    });
    
    this.createFarmer({
      name: "Sunrise Farms",
      region: "Haarlem Area",
      contactPerson: "Lisa van Dijk",
      phone: "+31 23 456 7890",
      email: "info@sunrisefarms.nl",
      joinDate: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000),
      marketplaceOptIn: true,
      storageAgreement: true,
      avatar: "https://images.unsplash.com/photo-1520052575296-c3e9addc6647?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
      notes: "Family-owned for three generations",
      registrationType: "admin",
      verificationStatus: "verified",
      lastLogin: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000)
    });
    
    // Initialize with sample activities
    this.createActivity({
      type: "new_farmer",
      description: "New farmer onboarded",
      details: { farmerName: "Organic Greens Farm" },
      timestamp: new Date(),
      relatedType: "farmer"
    });
    
    this.createActivity({
      type: "temperature_alert",
      description: "Temperature alert",
      details: { unitId: "CSU-003", temperature: 5.2, threshold: 4.5 },
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      relatedId: 3,
      relatedType: "storage_unit"
    });
    
    this.createActivity({
      type: "order_placed",
      description: "Large order placed",
      details: { customer: "Restaurant De Kas", amount: 1240 },
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000),
      relatedType: "order"
    });
    
    this.createActivity({
      type: "maintenance",
      description: "Maintenance completed",
      details: { unitId: "CSU-002", technicianName: "Pieter Janssen" },
      timestamp: new Date(Date.now() - 30 * 60 * 60 * 1000),
      relatedId: 2,
      relatedType: "storage_unit"
    });
    
    // Initialize with sample inventory items
    this.createFarmerInventory({
      farmerId: 1,
      storageUnitId: 1,
      productName: "Organic Carrots",
      quantity: 150,
      unit: "kg",
      startDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      endDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000),
      dailyRate: true,
      status: "active",
      notes: "Premium quality organic carrots"
    });
    
    this.createFarmerInventory({
      farmerId: 1,
      storageUnitId: 1,
      productName: "Red Apples",
      quantity: 200,
      unit: "kg",
      startDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
      endDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000),
      dailyRate: true,
      status: "active",
      notes: null
    });
    
    this.createFarmerInventory({
      farmerId: 2,
      storageUnitId: 2,
      productName: "Fresh Eggs",
      quantity: 500,
      unit: "dozen",
      startDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      endDate: new Date(Date.now() + 8 * 24 * 60 * 60 * 1000),
      dailyRate: true,
      status: "active",
      notes: "Free range eggs"
    });
    
    this.createFarmerInventory({
      farmerId: 3,
      storageUnitId: 1,
      productName: "Potatoes",
      quantity: 350,
      unit: "kg",
      startDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
      endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      dailyRate: true,
      status: "active",
      notes: "Multiple varieties"
    });
    
    // Initialize with sample categories
    this.createCategory({
      name: "Vegetables",
      description: "Fresh vegetables from local farmers"
    });
    
    this.createCategory({
      name: "Fruits",
      description: "Seasonal fruits from local orchards"
    });
    
    this.createCategory({
      name: "Dairy",
      description: "Milk, cheese and other dairy products"
    });
    
    this.createCategory({
      name: "Meat",
      description: "Fresh and cured meats"
    });
    
    // Initialize with sample product types
    this.createProductType({
      name: "Carrots",
      category: "Vegetables",
      description: "Orange root vegetable",
      standardUnit: "kg"
    });
    
    this.createProductType({
      name: "Potatoes",
      category: "Vegetables",
      description: "Starchy tuber vegetable",
      standardUnit: "kg"
    });
    
    this.createProductType({
      name: "Apples",
      category: "Fruits",
      description: "Sweet pomaceous fruit",
      standardUnit: "kg"
    });
    
    this.createProductType({
      name: "Milk",
      category: "Dairy",
      description: "Fresh cow's milk",
      standardUnit: "liter"
    });
    
    // Initialize with sample consumer
    this.createConsumer({
      name: "John Smith",
      phone: "+23712345678",
      email: "john.smith@example.com",
      address: "123 Main St, Douala",
      registrationDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
      verificationStatus: "verified",
      lastLogin: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)
    });
    
    // Initialize delivery settings
    this.createDeliverySettings({
      minimumOrderAmount: 2000, // 2000 XAF minimum order
      baseDeliveryFee: 500, // 500 XAF base delivery fee
      perKilometerFee: 50, // 50 XAF per kilometer
      maximumDeliveryRadius: 20 // 20 km maximum delivery radius
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id, 
      role: insertUser.role || "user",
      avatar: insertUser.avatar !== undefined ? insertUser.avatar : null 
    };
    this.users.set(id, user);
    return user;
  }
  
  // Storage Unit methods
  async getStorageUnits(): Promise<StorageUnit[]> {
    return Array.from(this.storageUnits.values());
  }
  
  async getStorageUnit(id: number): Promise<StorageUnit | undefined> {
    return this.storageUnits.get(id);
  }
  
  async getStorageUnitByUnitId(unitId: string): Promise<StorageUnit | undefined> {
    return Array.from(this.storageUnits.values()).find(
      (unit) => unit.unitId === unitId,
    );
  }
  
  async createStorageUnit(insertStorageUnit: InsertStorageUnit): Promise<StorageUnit> {
    const id = this.currentStorageUnitId++;
    const storageUnit: StorageUnit = { 
      ...insertStorageUnit, 
      id,
      status: insertStorageUnit.status || "operational",
      temperature: insertStorageUnit.temperature !== undefined ? insertStorageUnit.temperature : null,
      capacity: insertStorageUnit.capacity || 0,
      solarPanelStatus: insertStorageUnit.solarPanelStatus || "operational",
      batteryLevel: insertStorageUnit.batteryLevel || 0
    };
    this.storageUnits.set(id, storageUnit);
    return storageUnit;
  }
  
  async updateStorageUnit(id: number, storageUnit: Partial<StorageUnit>): Promise<StorageUnit | undefined> {
    const existing = await this.getStorageUnit(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...storageUnit };
    this.storageUnits.set(id, updated);
    
    // Broadcast storage unit update event
    broadcastUpdate("storage_unit_updated", updated);
    
    return updated;
  }
  
  async deleteStorageUnit(id: number): Promise<boolean> {
    return this.storageUnits.delete(id);
  }
  
  // Farmer methods
  async getFarmers(): Promise<Farmer[]> {
    return Array.from(this.farmers.values());
  }
  
  async getFarmer(id: number): Promise<Farmer | undefined> {
    return this.farmers.get(id);
  }
  
  async getFarmerByPhone(phone: string): Promise<Farmer | undefined> {
    return Array.from(this.farmers.values()).find(
      (farmer) => farmer.phone === phone
    );
  }
  
  async createFarmer(insertFarmer: InsertFarmer): Promise<Farmer> {
    const id = this.currentFarmerId++;
    const farmer: Farmer = { 
      ...insertFarmer, 
      id,
      avatar: insertFarmer.avatar !== undefined ? insertFarmer.avatar : null,
      notes: insertFarmer.notes !== undefined ? insertFarmer.notes : null,
      marketplaceOptIn: insertFarmer.marketplaceOptIn !== undefined ? insertFarmer.marketplaceOptIn : false,
      storageAgreement: insertFarmer.storageAgreement !== undefined ? insertFarmer.storageAgreement : false,
      registrationType: insertFarmer.registrationType || "admin",
      verificationStatus: insertFarmer.verificationStatus || "verified",
      temporaryPasscode: insertFarmer.temporaryPasscode || null,
      lastLogin: insertFarmer.lastLogin || null
    };
    this.farmers.set(id, farmer);
    
    // Broadcast farmer creation event
    broadcastUpdate("farmer_created", farmer);
    
    return farmer;
  }
  
  async updateFarmer(id: number, farmer: Partial<Farmer>): Promise<Farmer | undefined> {
    const existing = await this.getFarmer(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...farmer };
    this.farmers.set(id, updated);
    
    // Only broadcast the general farmer update if it's not from verification or login updates
    // Those have their own specialized broadcasts
    if (!farmer.verificationStatus && !farmer.lastLogin) {
      // Broadcast farmer update event
      broadcastUpdate("farmer_updated", updated);
    }
    
    return updated;
  }
  
  async updateFarmerVerification(id: number, verificationStatus: string, temporaryPasscode?: string): Promise<Farmer | undefined> {
    const existing = await this.getFarmer(id);
    if (!existing) return undefined;
    
    const updateData: Partial<Farmer> = {
      verificationStatus,
      ...(temporaryPasscode !== undefined && { temporaryPasscode })
    };
    
    const updated = await this.updateFarmer(id, updateData);
    
    if (updated) {
      // Broadcast farmer verification status update
      broadcastUpdate("farmer_verification_updated", {
        farmerId: updated.id,
        verificationStatus: updated.verificationStatus
      });
    }
    
    return updated;
  }
  
  async updateFarmerLastLogin(id: number): Promise<Farmer | undefined> {
    const existing = await this.getFarmer(id);
    if (!existing) return undefined;
    
    const updated = await this.updateFarmer(id, { lastLogin: new Date() });
    
    if (updated) {
      // Broadcast farmer login event
      broadcastUpdate("farmer_login", {
        farmerId: updated.id,
        name: updated.name,
        timestamp: updated.lastLogin
      });
    }
    
    return updated;
  }
  
  async deleteFarmer(id: number): Promise<boolean> {
    const farmer = this.farmers.get(id);
    if (farmer) {
      // Broadcast farmer deletion event before removing from storage
      broadcastUpdate("farmer_deleted", { farmerId: id, name: farmer.name });
    }
    return this.farmers.delete(id);
  }
  
  async getTopFarmers(limit: number): Promise<Farmer[]> {
    // In a real implementation, this would sort farmers by their sales
    return Array.from(this.farmers.values()).slice(0, limit);
  }

  // Consumer methods
  async getConsumers(): Promise<Consumer[]> {
    return Array.from(this.consumers.values());
  }
  
  async getConsumer(id: number): Promise<Consumer | undefined> {
    return this.consumers.get(id);
  }
  
  async getConsumerByPhone(phone: string): Promise<Consumer | undefined> {
    return Array.from(this.consumers.values()).find(
      (consumer) => consumer.phone === phone
    );
  }
  
  async createConsumer(insertConsumer: InsertConsumer): Promise<Consumer> {
    const id = this.currentConsumerId++;
    const consumer: Consumer = { 
      ...insertConsumer, 
      id,
      email: insertConsumer.email || null,
      address: insertConsumer.address || null,
      location: insertConsumer.location || null,
      temporaryPasscode: insertConsumer.temporaryPasscode || null,
      lastLogin: insertConsumer.lastLogin || null,
      verificationStatus: insertConsumer.verificationStatus || "pending",
      registrationDate: insertConsumer.registrationDate || new Date()
    };
    this.consumers.set(id, consumer);
    
    // Broadcast consumer creation event
    broadcastUpdate("consumer_created", consumer);
    
    return consumer;
  }
  
  async updateConsumer(id: number, consumer: Partial<Consumer>): Promise<Consumer | undefined> {
    const existing = await this.getConsumer(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...consumer };
    this.consumers.set(id, updated);
    
    // Only broadcast general consumer update if it's not from verification or login updates
    if (!consumer.verificationStatus && !consumer.lastLogin) {
      broadcastUpdate("consumer_updated", updated);
    }
    
    return updated;
  }
  
  async updateConsumerVerification(id: number, verificationStatus: string, temporaryPasscode?: string): Promise<Consumer | undefined> {
    const existing = await this.getConsumer(id);
    if (!existing) return undefined;
    
    const updateData: Partial<Consumer> = {
      verificationStatus,
      ...(temporaryPasscode !== undefined && { temporaryPasscode })
    };
    
    const updated = await this.updateConsumer(id, updateData);
    
    if (updated) {
      // Broadcast consumer verification status update
      broadcastUpdate("consumer_verification_updated", {
        consumerId: updated.id,
        verificationStatus: updated.verificationStatus
      });
    }
    
    return updated;
  }
  
  async updateConsumerLastLogin(id: number): Promise<Consumer | undefined> {
    const existing = await this.getConsumer(id);
    if (!existing) return undefined;
    
    const updated = await this.updateConsumer(id, { lastLogin: new Date() });
    
    if (updated) {
      // Broadcast consumer login event
      broadcastUpdate("consumer_login", {
        consumerId: updated.id,
        name: updated.name,
        timestamp: updated.lastLogin
      });
    }
    
    return updated;
  }
  
  async deleteConsumer(id: number): Promise<boolean> {
    const consumer = this.consumers.get(id);
    if (consumer) {
      // Broadcast consumer deletion event before removing from storage
      broadcastUpdate("consumer_deleted", { consumerId: id, name: consumer.name });
    }
    return this.consumers.delete(id);
  }
  
  // Cart Items methods
  async getCartItems(consumerId: number): Promise<CartItem[]> {
    return Array.from(this.cartItems.values()).filter(
      (item) => item.consumerId === consumerId
    );
  }
  
  async getCartItem(id: number): Promise<CartItem | undefined> {
    return this.cartItems.get(id);
  }
  
  async createCartItem(insertCartItem: InsertCartItem): Promise<CartItem> {
    const id = this.currentCartItemId++;
    const cartItem: CartItem = { 
      ...insertCartItem, 
      id,
      quantity: insertCartItem.quantity || 1, // Default to 1 if quantity not provided
      addedAt: new Date()
    };
    this.cartItems.set(id, cartItem);
    
    // Broadcast cart item creation event
    broadcastUpdate("cart_item_added", cartItem);
    
    return cartItem;
  }
  
  async updateCartItemQuantity(id: number, quantity: number): Promise<CartItem | undefined> {
    const existing = await this.getCartItem(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, quantity };
    this.cartItems.set(id, updated);
    
    // Broadcast cart item update event
    broadcastUpdate("cart_item_updated", updated);
    
    return updated;
  }
  
  async deleteCartItem(id: number): Promise<boolean> {
    const cartItem = this.cartItems.get(id);
    if (cartItem) {
      // Broadcast cart item deletion event before removing from storage
      broadcastUpdate("cart_item_deleted", { cartItemId: id, consumerId: cartItem.consumerId });
    }
    return this.cartItems.delete(id);
  }
  
  async clearCart(consumerId: number): Promise<boolean> {
    const cartItems = await this.getCartItems(consumerId);
    
    for (const item of cartItems) {
      await this.deleteCartItem(item.id);
    }
    
    // Broadcast cart cleared event
    broadcastUpdate("cart_cleared", { consumerId });
    
    return true;
  }
  
  // Farmer Inventory methods
  async getFarmerInventory(farmerId: number): Promise<FarmerInventory[]> {
    return Array.from(this.farmerInventories.values()).filter(
      (item) => item.farmerId === farmerId
    );
  }
  
  async getFarmerInventoryItem(id: number): Promise<FarmerInventory | undefined> {
    return this.farmerInventories.get(id);
  }
  
  async createFarmerInventory(insertInventory: InsertFarmerInventory): Promise<FarmerInventory> {
    const id = this.currentFarmerInventoryId++;
    const inventory: FarmerInventory = { 
      ...insertInventory, 
      id,
      status: insertInventory.status || "active",
      notes: insertInventory.notes !== undefined ? insertInventory.notes : null,
      dailyRate: insertInventory.dailyRate !== undefined ? insertInventory.dailyRate : false,
      price: insertInventory.price !== undefined ? insertInventory.price : null,
      listedOnMarketplace: insertInventory.listedOnMarketplace !== undefined ? insertInventory.listedOnMarketplace : null,
      inventoryItemId: insertInventory.inventoryItemId !== undefined ? insertInventory.inventoryItemId : null
    };
    this.farmerInventories.set(id, inventory);
    
    // Create activity for the new inventory item
    this.createActivity({
      type: "storage_added",
      description: `New product added to storage`,
      details: { 
        productName: inventory.productName, 
        quantity: inventory.quantity,
        unit: inventory.unit,
        farmerId: inventory.farmerId,
        storageUnitId: inventory.storageUnitId
      },
      timestamp: new Date(),
      relatedId: inventory.farmerId,
      relatedType: "farmer"
    });
    
    // Broadcast inventory creation event
    broadcastUpdate("inventory_created", inventory);
    
    return inventory;
  }
  
  async updateFarmerInventory(id: number, inventory: Partial<FarmerInventory>): Promise<FarmerInventory | undefined> {
    const existing = await this.getFarmerInventoryItem(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...inventory };
    this.farmerInventories.set(id, updated);
    
    // Create activity for the updated inventory
    this.createActivity({
      type: "storage_updated",
      description: `Storage item updated`,
      details: { 
        productName: updated.productName, 
        quantity: updated.quantity,
        unit: updated.unit,
        status: updated.status
      },
      timestamp: new Date(),
      relatedId: updated.farmerId,
      relatedType: "farmer"
    });
    
    // Broadcast inventory update event
    broadcastUpdate("inventory_updated", updated);
    
    return updated;
  }
  
  async deleteFarmerInventory(id: number): Promise<boolean> {
    const inventory = this.farmerInventories.get(id);
    if (inventory) {
      // Create activity for the deleted inventory
      this.createActivity({
        type: "storage_removed",
        description: `Product removed from storage`,
        details: { 
          productName: inventory.productName, 
          farmerId: inventory.farmerId,
          storageUnitId: inventory.storageUnitId
        },
        timestamp: new Date(),
        relatedId: inventory.farmerId,
        relatedType: "farmer"
      });
      
      // Broadcast inventory deletion event
      broadcastUpdate("inventory_deleted", inventory);
    }
    
    return this.farmerInventories.delete(id);
  }
  
  async getAllFarmerInventories(): Promise<FarmerInventory[]> {
    return Array.from(this.farmerInventories.values());
  }
  
  // Product methods
  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }
  
  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }
  
  async getProductsByFarmer(farmerId: number): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      (product) => product.farmerId === farmerId,
    );
  }

  async getMarketplaceProducts(): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      (product) => product.isListed === true && product.quantityAvailable > 0
    );
  }
  
  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.currentProductId++;
    const product: Product = { 
      ...insertProduct, 
      id,
      image: insertProduct.image !== undefined ? insertProduct.image : null,
      description: insertProduct.description !== undefined ? insertProduct.description : null,
      expiryDate: insertProduct.expiryDate !== undefined ? insertProduct.expiryDate : null,
      isListed: insertProduct.isListed !== undefined ? insertProduct.isListed : false,
      currency: insertProduct.currency || "USD",
      inventoryItemId: insertProduct.inventoryItemId !== undefined ? insertProduct.inventoryItemId : null
    };
    this.products.set(id, product);
    
    // Broadcast product creation event
    broadcastUpdate("product_created", product);
    
    return product;
  }
  
  async updateProduct(id: number, product: Partial<Product>): Promise<Product | undefined> {
    const existing = await this.getProduct(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...product };
    this.products.set(id, updated);
    
    // Broadcast product update event
    broadcastUpdate("product_updated", updated);
    
    return updated;
  }
  
  async deleteProduct(id: number): Promise<boolean> {
    const product = this.products.get(id);
    if (product) {
      // Broadcast product deletion event before removing from storage
      broadcastUpdate("product_deleted", { productId: id, name: product.name, farmerId: product.farmerId });
    }
    return this.products.delete(id);
  }
  
  // Activity methods
  async getActivities(limit?: number): Promise<Activity[]> {
    const activities = Array.from(this.activities.values())
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    
    return limit ? activities.slice(0, limit) : activities;
  }
  
  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = this.currentActivityId++;
    const activity: Activity = { 
      ...insertActivity, 
      id,
      details: insertActivity.details || {},
      timestamp: insertActivity.timestamp || new Date(),
      relatedId: insertActivity.relatedId !== undefined ? insertActivity.relatedId : null,
      relatedType: insertActivity.relatedType !== undefined ? insertActivity.relatedType : null
    };
    this.activities.set(id, activity);
    return activity;
  }
  
  // Order methods
  async getOrders(): Promise<Order[]> {
    return Array.from(this.orders.values());
  }

  async getOrdersByConsumer(consumerId: number): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(
      (order) => order.consumerId === consumerId
    );
  }

  async getOrdersByStatus(status: string): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(
      (order) => order.status === status
    );
  }
  
  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }
  
  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = this.currentOrderId++;
    
    // Create explicit order object with all required fields and their defaults
    const order: Order = {
      id,
      consumerId: insertOrder.consumerId,
      status: insertOrder.status || "pending",
      total: insertOrder.total,
      subtotal: insertOrder.subtotal,
      deliveryAddress: insertOrder.deliveryAddress,
      deliveryFee: insertOrder.deliveryFee || 0,
      orderDate: new Date(),
      deliveryLocation: null, // Default to null if not provided
      paymentMethod: insertOrder.paymentMethod || "mobile_money",
      paymentStatus: insertOrder.paymentStatus || "pending",
      paymentReference: insertOrder.paymentReference || null,
      deliveryNotes: insertOrder.deliveryNotes || null,
      estimatedDeliveryDate: insertOrder.estimatedDeliveryDate || null
    };
    this.orders.set(id, order);
    
    // Create an activity for the new order
    this.createActivity({
      type: "order_created",
      description: `New order #${order.id} created`,
      details: { 
        orderId: order.id, 
        consumerId: order.consumerId,
        total: order.total
      },
      timestamp: new Date(),
      relatedId: order.id,
      relatedType: "order"
    });
    
    // Broadcast order creation event
    broadcastUpdate("order_created", order);
    
    return order;
  }
  
  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const existing = await this.getOrder(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, status };
    this.orders.set(id, updated);
    
    // Create an activity for the order status update
    this.createActivity({
      type: "order_status_updated",
      description: `Order #${updated.id} status updated to ${status}`,
      details: { 
        orderId: updated.id, 
        oldStatus: existing.status,
        newStatus: status
      },
      timestamp: new Date(),
      relatedId: updated.id,
      relatedType: "order"
    });
    
    // Broadcast order status update event
    broadcastUpdate("order_status_updated", updated);
    
    return updated;
  }
  
  async updateOrderPaymentStatus(id: number, paymentStatus: string, paymentReference?: string): Promise<Order | undefined> {
    const existing = await this.getOrder(id);
    if (!existing) return undefined;
    
    const updateData: Partial<Order> = {
      paymentStatus,
      ...(paymentReference !== undefined && { paymentReference })
    };
    
    const updated = { ...existing, ...updateData };
    this.orders.set(id, updated);
    
    // Create an activity for the payment status update
    this.createActivity({
      type: "order_payment_updated",
      description: `Order #${updated.id} payment status updated to ${paymentStatus}`,
      details: { 
        orderId: updated.id, 
        oldStatus: existing.paymentStatus,
        newStatus: paymentStatus,
        ...(paymentReference && { paymentReference })
      },
      timestamp: new Date(),
      relatedId: updated.id,
      relatedType: "order"
    });
    
    // Broadcast order payment status update event
    broadcastUpdate("order_payment_updated", updated);
    
    return updated;
  }
  
  // Order Item methods
  async getOrderItems(orderId: number): Promise<OrderItem[]> {
    return Array.from(this.orderItems.values()).filter(
      (item) => item.orderId === orderId,
    );
  }
  
  async createOrderItem(insertOrderItem: InsertOrderItem): Promise<OrderItem> {
    const id = this.currentOrderItemId++;
    const orderItem: OrderItem = { 
      ...insertOrderItem, 
      id,
      productName: insertOrderItem.productName !== undefined ? insertOrderItem.productName : null,
      unit: insertOrderItem.unit !== undefined ? insertOrderItem.unit : null,
      inventoryItemId: insertOrderItem.inventoryItemId !== undefined ? insertOrderItem.inventoryItemId : null
    };
    this.orderItems.set(id, orderItem);
    
    // Broadcast order item creation event
    broadcastUpdate("order_item_created", orderItem);
    
    return orderItem;
  }
  
  // Storage Booking methods
  async getStorageBookings(): Promise<StorageBooking[]> {
    const bookings = await db.select().from(storageBookings);
    return bookings;
  }
  
  async getStorageBookingsByFarmer(farmerId: number): Promise<StorageBooking[]> {
    const bookings = await db.select()
      .from(storageBookings)
      .where(eq(storageBookings.farmerId, farmerId));
    return bookings;
  }
  
  async getStorageBookingsByStatus(status: string): Promise<StorageBooking[]> {
    const bookings = await db.select()
      .from(storageBookings)
      .where(eq(storageBookings.status, status));
    return bookings;
  }
  
  async getStorageBooking(id: number): Promise<StorageBooking | undefined> {
    const [booking] = await db.select()
      .from(storageBookings)
      .where(eq(storageBookings.id, id));
    return booking;
  }
  
  async createStorageBooking(booking: InsertStorageBooking): Promise<StorageBooking> {
    // Set requestDate and lastUpdated to current timestamp
    const [newBooking] = await db.insert(storageBookings)
      .values({
        ...booking,
        requestDate: new Date(),
        lastUpdated: new Date()
      })
      .returning();
    
    // Create an activity entry for the booking request
    await this.createActivity({
      type: "storage_booking_request",
      description: `Storage booking requested by ${(await this.getFarmer(booking.farmerId))?.name || 'Unknown farmer'}`,
      details: {
        bookingId: newBooking.id,
        farmerId: booking.farmerId,
        productName: booking.productName,
        quantity: booking.quantity,
        unit: booking.unit
      },
      relatedId: newBooking.id,
      relatedType: "storage_booking"
    });
    
    // Broadcast the booking request
    broadcastUpdate("booking_request_created", newBooking);
    
    // Targeted message to the specific farmer
    broadcastUpdate("farmer_booking_created", {
      farmerId: booking.farmerId,
      booking: newBooking
    });
    
    return newBooking;
  }
  
  async updateStorageBooking(id: number, booking: Partial<StorageBooking>): Promise<StorageBooking | undefined> {
    const existingBooking = await this.getStorageBooking(id);
    if (!existingBooking) return undefined;
    
    // Always update the lastUpdated timestamp
    const [updatedBooking] = await db.update(storageBookings)
      .set({
        ...booking,
        lastUpdated: new Date()
      })
      .where(eq(storageBookings.id, id))
      .returning();
    
    // Broadcast the booking update
    broadcastUpdate("booking_request_updated", updatedBooking);
    
    // Targeted message to the specific farmer
    broadcastUpdate("farmer_booking_updated", {
      farmerId: updatedBooking.farmerId,
      booking: updatedBooking
    });
    
    return updatedBooking;
  }
  
  async updateStorageBookingStatus(id: number, status: string, adminNotes?: string): Promise<StorageBooking | undefined> {
    const existingBooking = await this.getStorageBooking(id);
    if (!existingBooking) return undefined;
    
    // Update the booking status and notes
    const [updatedBooking] = await db.update(storageBookings)
      .set({
        status,
        adminNotes: adminNotes !== undefined ? adminNotes : existingBooking.adminNotes,
        lastUpdated: new Date()
      })
      .where(eq(storageBookings.id, id))
      .returning();
    
    // Create an inventory item if booking is approved
    if (status === "approved" && existingBooking.status !== "approved") {
      try {
        // Create a new inventory item from the approved booking
        const inventory = await this.createFarmerInventory({
          farmerId: updatedBooking.farmerId,
          storageUnitId: updatedBooking.storageUnitId,
          productName: updatedBooking.productName,
          quantity: updatedBooking.quantity,
          unit: updatedBooking.unit,
          startDate: updatedBooking.startDate,
          endDate: updatedBooking.endDate,
          dailyRate: true,
          status: "active",
          notes: `Created from booking #${updatedBooking.id}`,
        });
        
        // Link the inventory item to the booking
        await db.update(storageBookings)
          .set({ inventoryItemId: inventory.id })
          .where(eq(storageBookings.id, id));
        
        // Update the booking with the inventory item ID
        updatedBooking.inventoryItemId = inventory.id;
        
        // Create an activity for the approval and inventory creation
        await this.createActivity({
          type: "storage_booking_approved",
          description: `Storage booking #${id} approved and inventory created`,
          details: {
            bookingId: id,
            inventoryId: inventory.id,
            farmerId: updatedBooking.farmerId
          },
          relatedId: id,
          relatedType: "storage_booking"
        });
      } catch (error) {
        console.error("Error creating inventory from approved booking:", error);
      }
    } else if (status === "rejected" && existingBooking.status !== "rejected") {
      // Create an activity for the rejection
      await this.createActivity({
        type: "storage_booking_rejected",
        description: `Storage booking #${id} rejected`,
        details: {
          bookingId: id,
          farmerId: updatedBooking.farmerId,
          reason: adminNotes
        },
        relatedId: id,
        relatedType: "storage_booking"
      });
    } else if (status === "cancelled" && existingBooking.status !== "cancelled") {
      // Create an activity for the cancellation
      await this.createActivity({
        type: "storage_booking_cancelled",
        description: `Storage booking #${id} cancelled`,
        details: {
          bookingId: id,
          farmerId: updatedBooking.farmerId
        },
        relatedId: id,
        relatedType: "storage_booking"
      });
    }
    
    // Broadcast the status change
    broadcastUpdate("booking_status_changed", {
      bookingId: updatedBooking.id,
      oldStatus: existingBooking.status,
      newStatus: updatedBooking.status,
      farmerId: updatedBooking.farmerId
    });
    
    // Targeted message to the specific farmer
    broadcastUpdate("farmer_booking_status_changed", {
      farmerId: updatedBooking.farmerId,
      bookingId: updatedBooking.id,
      status: updatedBooking.status
    });
    
    return updatedBooking;
  }
  
  async deleteStorageBooking(id: number): Promise<boolean> {
    try {
      const booking = await this.getStorageBooking(id);
      if (!booking) return false;
      
      this.storageBookings.delete(id);
      
      // Create activity for deleted booking
      await this.createActivity({
        type: "storage_booking_deleted",
        description: `Storage booking #${id} deleted`,
        details: {
          bookingId: id,
          farmerId: booking.farmerId
        },
        timestamp: new Date(),
        relatedId: booking.farmerId,
        relatedType: "farmer"
      });
      
      return true;
    } catch (error) {
      console.error("Error deleting storage booking:", error);
      return false;
    }
  }
  
  // Analytics methods
  async getStorageUtilization(): Promise<{location: string, capacityPercentage: number}[]> {
    return Array.from(this.storageUnits.values()).map(unit => ({
      location: unit.location,
      capacityPercentage: unit.capacity
    }));
  }
  
  async getMonthlyRevenue(): Promise<{month: string, revenue: number}[]> {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return [
      { month: 'Jan', revenue: 9500 },
      { month: 'Feb', revenue: 10200 },
      { month: 'Mar', revenue: 11800 },
      { month: 'Apr', revenue: 13500 },
      { month: 'May', revenue: 12800 },
      { month: 'Jun', revenue: 14200 },
      { month: 'Jul', revenue: 15600 },
      { month: 'Aug', revenue: 16200 },
      { month: 'Sep', revenue: 15800 },
      { month: 'Oct', revenue: 14389 },
      { month: 'Nov', revenue: 0 },
      { month: 'Dec', revenue: 0 }
    ];
  }
  
  async getFarmerParticipation(): Promise<{optIn: number, optOut: number}> {
    const farmers = Array.from(this.farmers.values());
    const optIn = farmers.filter(farmer => farmer.marketplaceOptIn).length;
    return {
      optIn,
      optOut: farmers.length - optIn
    };
  }
  
  async getMarketplaceAnalytics(): Promise<{
    totalOrders: number;
    pendingOrders: number;
    totalRevenue: number;
    topProducts: {productName: string, quantity: number}[];
  }> {
    const orders = Array.from(this.orders.values());
    const pendingOrders = orders.filter(order => order.status === "pending").length;
    
    // Calculate total revenue from completed orders
    const totalRevenue = orders
      .filter(order => order.status === "completed" && order.paymentStatus === "paid")
      .reduce((sum, order) => sum + order.total, 0);
    
    // Get top products from order items
    const orderItems = Array.from(this.orderItems.values());
    const productCounts: Record<string, number> = {};
    
    orderItems.forEach(item => {
      const productName = item.productName || `Product #${item.productId}`;
      if (productCounts[productName]) {
        productCounts[productName] += item.quantity;
      } else {
        productCounts[productName] = item.quantity;
      }
    });
    
    // Sort products by quantity and get top 5
    const topProducts = Object.entries(productCounts)
      .map(([productName, quantity]) => ({ productName, quantity }))
      .sort((a, b) => b.quantity - a.quantity)
      .slice(0, 5);
    
    return {
      totalOrders: orders.length,
      pendingOrders,
      totalRevenue,
      topProducts
    };
  }
  
  // Delivery Settings methods
  async getDeliverySettings(): Promise<DeliverySetting | undefined> {
    // Since there's only one global delivery setting, we retrieve the first one
    return Array.from(this.deliverySettings.values())[0];
  }
  
  async createDeliverySettings(settings: InsertDeliverySetting): Promise<DeliverySetting> {
    const id = this.currentDeliverySettingId++;
    const deliverySetting: DeliverySetting = {
      ...settings,
      id,
      minimumOrderAmount: settings.minimumOrderAmount || 0,
      baseDeliveryFee: settings.baseDeliveryFee || 0,
      perKilometerFee: settings.perKilometerFee || 0,
      maximumDeliveryRadius: settings.maximumDeliveryRadius || 0,
      updatedAt: new Date()
    };
    
    this.deliverySettings.set(id, deliverySetting);
    
    // Broadcast delivery settings creation event
    broadcastUpdate("delivery_settings_created", deliverySetting);
    
    return deliverySetting;
  }
  
  async updateDeliverySettings(id: number, settings: Partial<DeliverySetting>): Promise<DeliverySetting | undefined> {
    const existing = this.deliverySettings.get(id);
    if (!existing) return undefined;
    
    const updated = {
      ...existing,
      ...settings,
      updatedAt: new Date()
    };
    
    this.deliverySettings.set(id, updated);
    
    // Broadcast delivery settings update event
    broadcastUpdate("delivery_settings_updated", updated);
    
    return updated;
  }
  
  // Category methods
  async getCategories(): Promise<Category[]> {
    const categories = Array.from(this.categories.values());
    
    // Calculate product count for each category
    return categories.map(category => {
      const productCount = Array.from(this.productTypes.values())
        .filter(pt => pt.category === category.name)
        .length;
      
      return {
        ...category,
        productCount
      };
    });
  }
  
  async getCategory(id: number): Promise<Category | undefined> {
    const category = this.categories.get(id);
    if (!category) return undefined;
    
    const productCount = Array.from(this.productTypes.values())
      .filter(pt => pt.category === category.name)
      .length;
    
    return {
      ...category,
      productCount
    };
  }
  
  async getCategoryByName(name: string): Promise<Category | undefined> {
    const category = Array.from(this.categories.values()).find(
      (cat) => cat.name === name
    );
    
    if (!category) return undefined;
    
    const productCount = Array.from(this.productTypes.values())
      .filter(pt => pt.category === category.name)
      .length;
    
    return {
      ...category,
      productCount
    };
  }
  
  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.currentCategoryId++;
    const category: Category = {
      ...insertCategory,
      id,
      createdAt: new Date(),
      description: insertCategory.description || null,
      productCount: 0 // Initially zero product types
    };
    
    this.categories.set(id, category);
    
    // Create activity for the new category
    this.createActivity({
      type: "category_created",
      description: `New product category created: ${category.name}`,
      details: { categoryName: category.name },
      timestamp: new Date(),
      relatedType: "category"
    });
    
    // Broadcast category creation event
    broadcastUpdate("category_created", category);
    
    return category;
  }
  
  async updateCategory(id: number, categoryUpdate: Partial<Category>): Promise<Category | undefined> {
    const existing = await this.getCategory(id);
    if (!existing) return undefined;
    
    // Don't update computed fields
    const { productCount, ...updateFields } = categoryUpdate;
    
    const updated = { ...existing, ...updateFields };
    this.categories.set(id, updated);
    
    // Broadcast category update event
    broadcastUpdate("category_updated", updated);
    
    return updated;
  }
  
  async deleteCategory(id: number): Promise<boolean> {
    const category = await this.getCategory(id);
    if (!category) return false;
    
    // Check if there are product types using this category
    const productTypesUsingCategory = Array.from(this.productTypes.values())
      .filter(pt => pt.category === category.name);
    
    if (productTypesUsingCategory.length > 0) {
      // Cannot delete a category in use
      return false;
    }
    
    // Safe to delete
    const deleted = this.categories.delete(id);
    
    if (deleted) {
      // Broadcast category deletion event
      broadcastUpdate("category_deleted", { categoryId: id, name: category.name });
    }
    
    return deleted;
  }
  
  // Product Type methods
  async getProductTypes(): Promise<ProductType[]> {
    return Array.from(this.productTypes.values());
  }
  
  async getProductTypesByCategory(category: string): Promise<ProductType[]> {
    return Array.from(this.productTypes.values())
      .filter(productType => productType.category === category);
  }
  
  async getProductType(id: number): Promise<ProductType | undefined> {
    return this.productTypes.get(id);
  }
  
  async createProductType(insertProductType: InsertProductType): Promise<ProductType> {
    const id = this.currentProductTypeId++;
    const productType: ProductType = {
      ...insertProductType,
      id,
      description: insertProductType.description || null,
      standardUnit: insertProductType.standardUnit || "kg",
      createdAt: new Date()
    };
    
    this.productTypes.set(id, productType);
    
    // Create activity for the new product type
    this.createActivity({
      type: "product_type_created",
      description: `New product type created: ${productType.name}`,
      details: { 
        productTypeName: productType.name,
        category: productType.category
      },
      timestamp: new Date(),
      relatedType: "product_type"
    });
    
    // Broadcast product type creation event
    broadcastUpdate("product_type_created", productType);
    
    return productType;
  }
  
  async updateProductType(id: number, productTypeUpdate: Partial<ProductType>): Promise<ProductType | undefined> {
    const existing = await this.getProductType(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...productTypeUpdate };
    this.productTypes.set(id, updated);
    
    // Broadcast product type update event
    broadcastUpdate("product_type_updated", updated);
    
    return updated;
  }
  
  async deleteProductType(id: number): Promise<boolean> {
    const productType = await this.getProductType(id);
    if (!productType) return false;
    
    // Check if there are products using this product type
    // This is a simplified check - in a real implementation we would check the database
    // to see if any products are using this product type
    
    const deleted = this.productTypes.delete(id);
    
    if (deleted) {
      // Broadcast product type deletion event
      broadcastUpdate("product_type_deleted", { 
        productTypeId: id, 
        name: productType.name,
        category: productType.category
      });
    }
    
    return deleted;
  }
}

import { DatabaseStorage } from './database-storage';
export const storage = new DatabaseStorage();
