import express, { type Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { z } from "zod";
import Stripe from "stripe";
import cors from "cors";
import { WebSocketServer, WebSocket } from "ws";
import path from "path";
import { 
  insertUserSchema, 
  insertStorageUnitSchema, 
  insertFarmerSchema,
  insertInventorySchema,
  insertProductSchema,
  insertActivitySchema,
  insertOrderSchema,
  insertOrderItemSchema,
  insertStorageBookingSchema,
  FarmerInventory,
  Farmer,
  StorageBooking
} from "@shared/schema";
import { calculateFarmerStorageCosts, calculateInventoryItemCost, formatStorageStatement } from "@shared/billing";
import { formatCurrency } from "@shared/constants";
import MemoryStore from "memorystore";
import { registerAPIs } from './api';
import { sendSuccess, sendError } from './utils/apiResponse';
import config from './config';
import { sendMessageToFarmer, broadcastMessage, broadcastUpdate, getConnectedClientCount, getAuthenticatedFarmerCount } from './utils/websocket';
import registerCategoriesAPI from './api/categories-api';
import registerMobileFarmerAPI from './api/mobile-farmer-api';

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up CORS
  app.use(cors(config.cors));
  
  // Auth middleware
  const isAuthenticated = (req: Request, res: Response, next: Function) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Not authenticated" });
  };
  // Categories and product types API routes are now in categories-api.ts

  // Set up session
  const SessionStore = MemoryStore(session);
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "coldfarms-secret",
      resave: false,
      saveUninitialized: false,
      store: storage.sessionStore, // Use database session store in production
      cookie: {
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
        secure: process.env.NODE_ENV === "production",
        httpOnly: true,
        sameSite: process.env.NODE_ENV === "production" ? 'strict' : 'lax',
      },
      name: 'coldfarms.sid', // Custom name to avoid revealing tech stack
    })
  );

  // Set up passport
  app.use(passport.initialize());
  app.use(passport.session());

  // Configure passport local strategy
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user) {
          return done(null, false, { message: "Invalid username or password" });
        }
        
        // In a real app, you would hash passwords and compare hashes
        if (user.password !== password) {
          return done(null, false, { message: "Invalid username or password" });
        }
        
        return done(null, user);
      } catch (error) {
        return done(error);
      }
    })
  );

  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Auth routes
  app.post("/api/auth/login", passport.authenticate("local"), (req, res) => {
    res.json({ user: req.user });
  });

  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(validatedData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(validatedData);
      
      // Log the user in after registration
      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ message: "Error during login after registration" });
        }
        return res.status(201).json({ user });
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating user" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.logout((err) => {
      if (err) return res.status(500).json({ message: "Error logging out" });
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/current-user", (req, res) => {
    if (!req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    res.json({ user: req.user });
  });

  // Storage Unit routes
  app.get("/api/storage-units", isAuthenticated, async (req, res) => {
    try {
      const storageUnits = await storage.getStorageUnits();
      res.json(storageUnits);
    } catch (error) {
      res.status(500).json({ message: "Error fetching storage units" });
    }
  });
  
  // Get count of storage units for a specific country and city
  app.get("/api/storage-units/count-by-location", isAuthenticated, async (req, res) => {
    try {
      const { country, city } = req.query;
      
      if (!country || !city) {
        return res.status(400).json({ message: "Country and city are required" });
      }
      
      const storageUnits = await storage.getStorageUnits();
      
      // Filter units by location containing the country and city
      // This is a simplified approach - in a real database, we'd have separate country and city fields
      const matchingUnits = storageUnits.filter(unit => {
        const location = unit.location.toLowerCase();
        return location.includes((country as string).toLowerCase()) && 
               location.includes((city as string).toLowerCase());
      });
      
      res.json({ count: matchingUnits.length });
    } catch (error) {
      console.error("Error counting storage units by location:", error);
      res.status(500).json({ message: "Error counting storage units by location" });
    }
  });

  app.get("/api/storage-units/:id", isAuthenticated, async (req, res) => {
    try {
      const storageUnit = await storage.getStorageUnit(Number(req.params.id));
      if (!storageUnit) {
        return res.status(404).json({ message: "Storage unit not found" });
      }
      res.json(storageUnit);
    } catch (error) {
      res.status(500).json({ message: "Error fetching storage unit" });
    }
  });
  
  // Get farmers using a specific storage unit
  app.get("/api/storage-units/:id/farmers", isAuthenticated, async (req, res) => {
    try {
      const storageUnitId = Number(req.params.id);
      
      // Get all inventory items for this storage unit
      const allInventoryItems = await storage.getAllFarmerInventories();
      
      // Filter to only include items from this storage unit
      const relevantInventoryItems = allInventoryItems.filter((item: FarmerInventory) => 
        item.storageUnitId === storageUnitId
      );
      
      // Extract unique farmer IDs
      const farmerIdsSet = new Set<number>();
      relevantInventoryItems.forEach((item: FarmerInventory) => {
        farmerIdsSet.add(item.farmerId);
      });
      const farmerIds = Array.from(farmerIdsSet);
      
      // Get farmer details for each ID
      const farmers = await Promise.all(
        farmerIds.map(async (farmerId) => await storage.getFarmer(farmerId))
      );
      
      // Filter out any undefined results (in case a farmer was deleted)
      const validFarmers = farmers.filter((farmer): farmer is Farmer => farmer !== undefined);
      
      res.json(validFarmers);
    } catch (error) {
      console.error("Error fetching farmers for storage unit:", error);
      res.status(500).json({ message: "Error fetching farmers for storage unit" });
    }
  });
  
  // Get inventory items in a specific storage unit
  app.get("/api/storage-units/:id/inventory", isAuthenticated, async (req, res) => {
    try {
      const storageUnitId = Number(req.params.id);
      
      // Get all inventory items for this storage unit
      const allInventoryItems = await storage.getAllFarmerInventories();
      
      // Filter to only include items from this storage unit
      const inventoryItems = allInventoryItems.filter((item: FarmerInventory) => 
        item.storageUnitId === storageUnitId
      );
      
      // Get farmer details for each inventory item
      const inventoryWithFarmerDetails = await Promise.all(
        inventoryItems.map(async (item: FarmerInventory) => {
          const farmer = await storage.getFarmer(item.farmerId);
          return {
            ...item,
            farmerName: farmer ? farmer.name : 'Unknown Farmer'
          };
        })
      );
      
      res.json(inventoryWithFarmerDetails);
    } catch (error) {
      console.error("Error fetching inventory for storage unit:", error);
      res.status(500).json({ message: "Error fetching inventory for storage unit" });
    }
  });
  
  // Get inventory summary for a storage unit (products and quantities)
  app.get("/api/storage-units/:id/inventory-summary", isAuthenticated, async (req, res) => {
    try {
      const storageUnitId = Number(req.params.id);
      
      // Get all inventory items for this storage unit
      const allInventoryItems = await storage.getAllFarmerInventories();
      
      // Filter to only include items from this storage unit
      const inventoryItems = allInventoryItems.filter((item: FarmerInventory) => 
        item.storageUnitId === storageUnitId
      );
      
      // Group by product name and sum quantities
      interface SummaryItem {
        productName: string;
        totalQuantity: number;
        unit: string;
        farmerCount: Set<number>;
      }
      
      interface SummaryMap {
        [key: string]: SummaryItem;
      }
      
      const summary = inventoryItems.reduce<SummaryMap>((acc, item: FarmerInventory) => {
        const key = item.productName;
        if (!acc[key]) {
          acc[key] = {
            productName: item.productName,
            totalQuantity: 0,
            unit: item.unit, // Assuming all items of same product use same unit
            farmerCount: new Set<number>()
          };
        }
        
        acc[key].totalQuantity += item.quantity;
        acc[key].farmerCount.add(item.farmerId);
        
        return acc;
      }, {});
      
      // Convert to array and format
      const formattedSummary = Object.values(summary).map((item: SummaryItem) => ({
        productName: item.productName,
        totalQuantity: item.totalQuantity,
        unit: item.unit,
        farmerCount: item.farmerCount.size
      }));
      
      res.json(formattedSummary);
    } catch (error) {
      console.error("Error fetching inventory summary for storage unit:", error);
      res.status(500).json({ message: "Error fetching inventory summary for storage unit" });
    }
  });

  app.post("/api/storage-units", isAuthenticated, async (req, res) => {
    try {
      console.log("Received storage unit data:", JSON.stringify(req.body, null, 2));
      
      // Preprocess the data before validation - convert string dates to actual Date objects
      const preprocessedData = {
        ...req.body,
        // Make sure we're properly converting dates
        lastMaintenance: req.body.lastMaintenance ? new Date(req.body.lastMaintenance) : null,
        nextMaintenance: req.body.nextMaintenance ? new Date(req.body.nextMaintenance) : null,
      };
      
      console.log("Preprocessed data:", JSON.stringify(preprocessedData, null, 2));
      
      // Use parse directly - transformations in schema will handle type conversions
      const validatedData = insertStorageUnitSchema.parse(preprocessedData);
      
      const storageUnit = await storage.createStorageUnit(validatedData);
      
      // Create activity log
      await storage.createActivity({
        type: "new_storage_unit",
        description: "New storage unit added",
        details: { unitId: storageUnit.unitId, location: storageUnit.location },
        timestamp: new Date(),
        relatedId: storageUnit.id,
        relatedType: "storage_unit"
      });
      
      console.log("Created storage unit:", JSON.stringify(storageUnit, null, 2));
      res.status(201).json(storageUnit);
    } catch (error) {
      console.error("Error creating storage unit:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      res.status(500).json({ message: `Error creating storage unit: ${errorMessage}` });
    }
  });

  app.put("/api/storage-units/:id", isAuthenticated, async (req, res) => {
    try {
      const id = Number(req.params.id);
      
      // Preprocess the data before updating - convert string dates to actual Date objects
      const preprocessedData = {
        ...req.body,
        // Make sure we're properly converting dates
        lastMaintenance: req.body.lastMaintenance ? new Date(req.body.lastMaintenance) : null,
        nextMaintenance: req.body.nextMaintenance ? new Date(req.body.nextMaintenance) : null,
      };
      
      const updatedUnit = await storage.updateStorageUnit(id, preprocessedData);
      if (!updatedUnit) {
        return res.status(404).json({ message: "Storage unit not found" });
      }
      
      // Create activity log
      await storage.createActivity({
        type: "update_storage_unit",
        description: "Storage unit updated",
        details: { unitId: updatedUnit.unitId, location: updatedUnit.location },
        timestamp: new Date(),
        relatedId: updatedUnit.id,
        relatedType: "storage_unit"
      });
      
      res.json(updatedUnit);
    } catch (error) {
      console.error("Error updating storage unit:", error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      res.status(500).json({ message: `Error updating storage unit: ${errorMessage}` });
    }
  });

  app.delete("/api/storage-units/:id", isAuthenticated, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const storageUnit = await storage.getStorageUnit(id);
      if (!storageUnit) {
        return res.status(404).json({ message: "Storage unit not found" });
      }
      
      const deleted = await storage.deleteStorageUnit(id);
      if (!deleted) {
        return res.status(500).json({ message: "Failed to delete storage unit" });
      }
      
      // Create activity log
      await storage.createActivity({
        type: "delete_storage_unit",
        description: "Storage unit deleted",
        details: { unitId: storageUnit.unitId, location: storageUnit.location },
        timestamp: new Date(),
        relatedType: "storage_unit"
      });
      
      res.json({ message: "Storage unit deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Error deleting storage unit" });
    }
  });

  // Farmer routes
  app.get("/api/farmers", isAuthenticated, async (req, res) => {
    try {
      const farmers = await storage.getFarmers();
      res.json(farmers);
    } catch (error) {
      res.status(500).json({ message: "Error fetching farmers" });
    }
  });

  app.get("/api/farmers/top", isAuthenticated, async (req, res) => {
    try {
      const limit = Number(req.query.limit) || 4;
      const topFarmers = await storage.getTopFarmers(limit);
      res.json(topFarmers);
    } catch (error) {
      res.status(500).json({ message: "Error fetching top farmers" });
    }
  });

  app.get("/api/farmers/:id", isAuthenticated, async (req, res) => {
    try {
      const farmer = await storage.getFarmer(Number(req.params.id));
      if (!farmer) {
        return res.status(404).json({ message: "Farmer not found" });
      }
      res.json(farmer);
    } catch (error) {
      res.status(500).json({ message: "Error fetching farmer" });
    }
  });

  app.post("/api/farmers", isAuthenticated, async (req, res) => {
    try {
      console.log("Received farmer data:", JSON.stringify(req.body, null, 2));

      // Preprocess the data
      const preprocessedData = {
        ...req.body,
        joinDate: req.body.joinDate ? new Date(req.body.joinDate) : new Date(),
        registrationType: "admin",
        verificationStatus: "verified",
        temporaryPasscode: Math.floor(1000 + Math.random() * 9000).toString(), // 4-digit code
      };
      
      console.log("Preprocessed data:", JSON.stringify(preprocessedData, null, 2));
      
      // Validate
      const validatedData = insertFarmerSchema.parse(preprocessedData);
      
      const farmer = await storage.createFarmer(validatedData);
      
      // Create activity log
      await storage.createActivity({
        type: "new_farmer",
        description: "New farmer onboarded",
        details: { 
          farmerName: farmer.name, 
          region: farmer.region,
          temporaryPasscode: farmer.temporaryPasscode 
        },
        timestamp: new Date(),
        relatedId: farmer.id,
        relatedType: "farmer"
      });
      
      console.log("Created farmer:", JSON.stringify(farmer, null, 2));
      res.status(201).json(farmer);
    } catch (error) {
      console.error("Error creating farmer:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      res.status(500).json({ message: `Error creating farmer: ${errorMessage}` });
    }
  });

  app.put("/api/farmers/:id", isAuthenticated, async (req, res) => {
    try {
      const id = Number(req.params.id);
      
      // Preprocess the data before validation - convert string dates to actual Date objects
      const preprocessedData = {
        ...req.body,
        joinDate: req.body.joinDate ? new Date(req.body.joinDate) : new Date(),
      };
      
      const updatedFarmer = await storage.updateFarmer(id, preprocessedData);
      if (!updatedFarmer) {
        return res.status(404).json({ message: "Farmer not found" });
      }
      
      // Create activity log if marketplace opt-in changed
      if (req.body.marketplaceOptIn !== undefined) {
        await storage.createActivity({
          type: "farmer_marketplace_update",
          description: req.body.marketplaceOptIn ? "Farmer opted in to marketplace" : "Farmer opted out of marketplace",
          details: { farmerName: updatedFarmer.name },
          timestamp: new Date(),
          relatedId: updatedFarmer.id,
          relatedType: "farmer"
        });
      }
      
      res.json(updatedFarmer);
    } catch (error) {
      console.error("Error updating farmer:", error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      res.status(500).json({ message: `Error updating farmer: ${errorMessage}` });
    }
  });

  app.delete("/api/farmers/:id", isAuthenticated, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const farmer = await storage.getFarmer(id);
      if (!farmer) {
        return res.status(404).json({ message: "Farmer not found" });
      }
      
      const deleted = await storage.deleteFarmer(id);
      if (!deleted) {
        return res.status(500).json({ message: "Failed to delete farmer" });
      }
      
      // Create activity log
      await storage.createActivity({
        type: "delete_farmer",
        description: "Farmer deleted",
        details: { farmerName: farmer.name },
        timestamp: new Date(),
        relatedType: "farmer"
      });
      
      res.json({ message: "Farmer deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Error deleting farmer" });
    }
  });

  // Endpoint to approve self-registered farmers
  app.post("/api/farmers/:id/approve", isAuthenticated, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const farmer = await storage.getFarmer(id);
      
      if (!farmer) {
        return res.status(404).json({ message: "Farmer not found" });
      }
      
      // Update verification status
      const updatedFarmer = await storage.updateFarmer(id, {
        verificationStatus: "verified"
      });
      
      // Create activity log
      await storage.createActivity({
        type: "farmer_verified",
        description: "Self-registered farmer approved",
        details: { farmerName: farmer.name },
        timestamp: new Date(),
        relatedId: farmer.id,
        relatedType: "farmer"
      });
      
      res.json(updatedFarmer);
    } catch (error) {
      console.error("Error approving farmer:", error);
      res.status(500).json({ message: "Error approving farmer" });
    }
  });

  // Farmer Inventory routes
  app.get("/api/farmers/:farmerId/inventory", isAuthenticated, async (req, res) => {
    try {
      const farmerId = Number(req.params.farmerId);
      const inventory = await storage.getFarmerInventory(farmerId);
      res.json(inventory);
    } catch (error) {
      res.status(500).json({ message: "Error fetching farmer inventory" });
    }
  });
  
  // Get all unique product categories from farmer inventory
  app.get("/api/inventory/categories", isAuthenticated, async (req, res) => {
    try {
      const allInventory = await storage.getAllFarmerInventories();
      // Extract unique categories from inventory item names
      const categoriesSet = new Set<string>();
      allInventory.forEach(item => {
        // For simplicity, assuming the first word is the category
        // In a real app, this would be a proper category field
        const categoryName = item.productName.split(" ")[0].trim();
        categoriesSet.add(categoryName);
      });
      const categories = Array.from(categoriesSet);
      
      res.json(categories);
    } catch (error) {
      console.error("Error fetching inventory categories:", error);
      res.status(500).json({ message: "Error fetching inventory categories" });
    }
  });
  
  // Get all unique product names by category from farmer inventory
  app.get("/api/inventory/products-by-category", isAuthenticated, async (req, res) => {
    try {
      const { category } = req.query;
      
      if (!category) {
        return res.status(400).json({ message: "Category parameter is required" });
      }
      
      const allInventory = await storage.getAllFarmerInventories();
      // Filter inventory items that start with the specified category
      const productNamesSet = new Set<string>();
      allInventory
        .filter(item => item.productName.toLowerCase().startsWith(category.toString().toLowerCase()))
        .forEach(item => productNamesSet.add(item.productName));
      const productNames = Array.from(productNamesSet);
      
      res.json(productNames);
    } catch (error) {
      console.error("Error fetching products by category:", error);
      res.status(500).json({ message: "Error fetching products by category" });
    }
  });
  
  // Get all farmers that have a specific product name in inventory
  app.get("/api/inventory/farmers-by-product", isAuthenticated, async (req, res) => {
    try {
      const { productName } = req.query;
      
      if (!productName) {
        return res.status(400).json({ message: "Product name parameter is required" });
      }
      
      const allInventory = await storage.getAllFarmerInventories();
      // Filter inventory items by product name
      const inventoryItems = allInventory.filter(
        item => item.productName.toLowerCase() === productName.toString().toLowerCase()
      );
      
      // Get unique farmer IDs
      const farmerIdsSet = new Set<number>();
      inventoryItems.forEach(item => farmerIdsSet.add(item.farmerId));
      const farmerIds = Array.from(farmerIdsSet);
      
      // Get farmer details for each farmer ID
      const farmers = await Promise.all(
        farmerIds.map(async (farmerId) => {
          const farmer = await storage.getFarmer(farmerId);
          if (!farmer) return null;
          
          // Get inventory items for this farmer and product
          const farmerInventoryItems = inventoryItems.filter(item => item.farmerId === farmerId);
          
          // Calculate total quantity for this farmer and product
          const totalQuantity = farmerInventoryItems.reduce((sum, item) => sum + item.quantity, 0);
          
          return {
            ...farmer,
            inventoryItems: farmerInventoryItems,
            totalQuantity: totalQuantity,
            unit: farmerInventoryItems[0]?.unit || 'kg'
          };
        })
      );
      
      // Filter out null values (in case a farmer wasn't found)
      const validFarmers = farmers.filter(farmer => farmer !== null);
      
      res.json(validFarmers);
    } catch (error) {
      console.error("Error fetching farmers by product:", error);
      res.status(500).json({ message: "Error fetching farmers by product" });
    }
  });
  
  // Add inventory item for a specific farmer
  app.post("/api/farmers/:farmerId/inventory", isAuthenticated, async (req, res) => {
    try {
      const farmerId = Number(req.params.farmerId);
      console.log("Received inventory data for farmer", farmerId, ":", JSON.stringify(req.body, null, 2));
      
      // Preprocess the data before validation - convert string dates to actual Date objects
      const preprocessedData = {
        ...req.body,
        farmerId, // Ensure the correct farmerId from the URL is used
        startDate: req.body.startDate ? new Date(req.body.startDate) : new Date(),
        endDate: req.body.endDate ? new Date(req.body.endDate) : null,
      };
      
      console.log("Preprocessed data:", JSON.stringify(preprocessedData, null, 2));
      
      // Use parse directly - transformations in schema will handle type conversions
      const validatedData = insertInventorySchema.parse(preprocessedData);
      
      const inventoryItem = await storage.createFarmerInventory(validatedData);
      
      // Create activity log
      await storage.createActivity({
        type: "new_inventory_item",
        description: "New inventory item added",
        details: { 
          farmerId,
          productName: inventoryItem.productName,
          quantity: inventoryItem.quantity,
          unit: inventoryItem.unit
        },
        timestamp: new Date(),
        relatedId: inventoryItem.id,
        relatedType: "farmer_inventory"
      });
      
      console.log("Created inventory item:", JSON.stringify(inventoryItem, null, 2));
      res.status(200).json(inventoryItem);
    } catch (error) {
      console.error("Error creating inventory item:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      res.status(500).json({ message: `Error creating inventory item: ${errorMessage}` });
    }
  });
  
  app.get("/api/inventory/:id", isAuthenticated, async (req, res) => {
    try {
      const inventoryItem = await storage.getFarmerInventoryItem(Number(req.params.id));
      if (!inventoryItem) {
        return res.status(404).json({ message: "Inventory item not found" });
      }
      res.json(inventoryItem);
    } catch (error) {
      res.status(500).json({ message: "Error fetching inventory item" });
    }
  });
  
  app.post("/api/inventory", isAuthenticated, async (req, res) => {
    try {
      console.log("Received inventory data:", JSON.stringify(req.body, null, 2));
      
      // Preprocess the data before validation - convert string dates to actual Date objects
      const preprocessedData = {
        ...req.body,
        startDate: req.body.startDate ? new Date(req.body.startDate) : new Date(),
        endDate: req.body.endDate ? new Date(req.body.endDate) : null,
      };
      
      console.log("Preprocessed data:", JSON.stringify(preprocessedData, null, 2));
      
      // Use parse directly - transformations in schema will handle type conversions
      const validatedData = insertInventorySchema.parse(preprocessedData);
      
      const inventoryItem = await storage.createFarmerInventory(validatedData);
      
      console.log("Created inventory item:", JSON.stringify(inventoryItem, null, 2));
      res.status(201).json(inventoryItem);
    } catch (error) {
      console.error("Error creating inventory item:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      res.status(500).json({ message: `Error creating inventory item: ${errorMessage}` });
    }
  });
  
  // Update inventory item for a specific farmer
  app.patch("/api/farmers/:farmerId/inventory/:id", isAuthenticated, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const farmerId = Number(req.params.farmerId);
      
      // Verify the inventory item belongs to the specified farmer
      const inventoryItem = await storage.getFarmerInventoryItem(id);
      if (!inventoryItem || inventoryItem.farmerId !== farmerId) {
        return res.status(404).json({ message: "Inventory item not found for this farmer" });
      }
      
      // Preprocess the data before updating - convert string dates to actual Date objects
      const preprocessedData = {
        ...req.body,
        startDate: req.body.startDate ? new Date(req.body.startDate) : undefined,
        endDate: req.body.endDate ? new Date(req.body.endDate) : null,
      };
      
      const updatedItem = await storage.updateFarmerInventory(id, preprocessedData);
      if (!updatedItem) {
        return res.status(404).json({ message: "Inventory item not found" });
      }
      
      res.json(updatedItem);
    } catch (error) {
      console.error("Error updating inventory item:", error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      res.status(500).json({ message: `Error updating inventory item: ${errorMessage}` });
    }
  });
  
  app.put("/api/inventory/:id", isAuthenticated, async (req, res) => {
    try {
      const id = Number(req.params.id);
      
      // Preprocess the data before updating - convert string dates to actual Date objects
      const preprocessedData = {
        ...req.body,
        startDate: req.body.startDate ? new Date(req.body.startDate) : undefined,
        endDate: req.body.endDate ? new Date(req.body.endDate) : null,
      };
      
      const updatedItem = await storage.updateFarmerInventory(id, preprocessedData);
      if (!updatedItem) {
        return res.status(404).json({ message: "Inventory item not found" });
      }
      
      res.json(updatedItem);
    } catch (error) {
      console.error("Error updating inventory item:", error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      res.status(500).json({ message: `Error updating inventory item: ${errorMessage}` });
    }
  });
  
  // Delete inventory item for a specific farmer
  app.delete("/api/farmers/:farmerId/inventory/:id", isAuthenticated, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const farmerId = Number(req.params.farmerId);
      
      // Verify the inventory item belongs to the specified farmer
      const inventoryItem = await storage.getFarmerInventoryItem(id);
      if (!inventoryItem || inventoryItem.farmerId !== farmerId) {
        return res.status(404).json({ message: "Inventory item not found for this farmer" });
      }
      
      const deleted = await storage.deleteFarmerInventory(id);
      if (!deleted) {
        return res.status(500).json({ message: "Failed to delete inventory item" });
      }
      
      // Create activity log
      await storage.createActivity({
        type: "deleted_inventory_item",
        description: "Inventory item removed",
        details: { 
          farmerId,
          productName: inventoryItem.productName
        },
        timestamp: new Date(),
        relatedId: farmerId,
        relatedType: "farmer"
      });
      
      res.json({ message: "Inventory item deleted successfully" });
    } catch (error) {
      console.error("Error deleting inventory item:", error);
      res.status(500).json({ message: "Error deleting inventory item" });
    }
  });
  
  app.delete("/api/inventory/:id", isAuthenticated, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const inventoryItem = await storage.getFarmerInventoryItem(id);
      if (!inventoryItem) {
        return res.status(404).json({ message: "Inventory item not found" });
      }
      
      const deleted = await storage.deleteFarmerInventory(id);
      if (!deleted) {
        return res.status(500).json({ message: "Failed to delete inventory item" });
      }
      
      res.json({ message: "Inventory item deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Error deleting inventory item" });
    }
  });

  // Product routes
  app.get("/api/products", isAuthenticated, async (req, res) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Error fetching products" });
    }
  });

  // Inventory Categories API endpoint using new category system
  app.get("/api/inventory/categories", isAuthenticated, async (req, res) => {
    try {
      // Get categories from our static list
      const response = await fetch(`http://localhost:${process.env.PORT || 5000}/api/categories`);
      const categories = await response.json();
      
      // Return just the category names
      const categoryNames = categories.map((category: any) => category.name);
      
      res.json(categoryNames);
    } catch (error) {
      console.error("Error fetching inventory categories:", error);
      res.status(500).json({ message: "Error fetching inventory categories" });
    }
  });

  // Products by Category API endpoint using new category system
  app.get("/api/inventory/products-by-category", isAuthenticated, async (req, res) => {
    try {
      const category = req.query.category as string;
      if (!category) {
        return res.status(400).json({ message: "Category parameter is required" });
      }

      // Get product types by category from our static list
      const response = await fetch(`http://localhost:${process.env.PORT || 5000}/api/product-types`);
      const allProductTypes = await response.json();
      
      // Filter by category and extract names
      const filteredProducts = allProductTypes
        .filter((productType: any) => productType.category === category)
        .map((productType: any) => productType.name);
      
      res.json(filteredProducts);
    } catch (error) {
      console.error("Error fetching products by category:", error);
      res.status(500).json({ message: "Error fetching products by category" });
    }
  });

  // Farmers by Product API endpoint
  app.get("/api/inventory/farmers-by-product", isAuthenticated, async (req, res) => {
    try {
      const productName = req.query.productName as string;
      if (!productName) {
        return res.status(400).json({ message: "Product name parameter is required" });
      }

      const allInventory = await storage.getAllFarmerInventories();
      const inventoryItems = allInventory.filter(item => 
        item.productName.toLowerCase() === productName.toLowerCase()
      );

      // Group by farmer and sum quantities
      const farmerInventoryMap = new Map();
      for (const item of inventoryItems) {
        const farmer = await storage.getFarmer(item.farmerId);
        if (!farmer) continue;

        const farmerId = item.farmerId;
        if (!farmerInventoryMap.has(farmerId)) {
          farmerInventoryMap.set(farmerId, {
            id: farmerId,
            name: farmer.name,
            totalQuantity: item.quantity,
            unit: item.unit
          });
        } else {
          const existingEntry = farmerInventoryMap.get(farmerId);
          existingEntry.totalQuantity += item.quantity;
        }
      }

      res.json(Array.from(farmerInventoryMap.values()));
    } catch (error) {
      res.status(500).json({ message: "Error fetching farmers by product" });
    }
  });

  app.get("/api/products/:id", isAuthenticated, async (req, res) => {
    try {
      const product = await storage.getProduct(Number(req.params.id));
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ message: "Error fetching product" });
    }
  });

  app.get("/api/farmers/:id/products", isAuthenticated, async (req, res) => {
    try {
      const farmerId = Number(req.params.id);
      const products = await storage.getProductsByFarmer(farmerId);
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Error fetching farmer products" });
    }
  });

  app.post("/api/products", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(validatedData);
      
      // Create activity log
      await storage.createActivity({
        type: "new_product",
        description: "New product added to marketplace",
        details: { productName: product.name, farmerName: (await storage.getFarmer(product.farmerId))?.name },
        timestamp: new Date(),
        relatedId: product.id,
        relatedType: "product"
      });
      
      res.status(201).json(product);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating product" });
    }
  });

  app.put("/api/products/:id", isAuthenticated, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const updatedProduct = await storage.updateProduct(id, req.body);
      if (!updatedProduct) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(updatedProduct);
    } catch (error) {
      res.status(500).json({ message: "Error updating product" });
    }
  });

  app.delete("/api/products/:id", isAuthenticated, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const product = await storage.getProduct(id);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      const deleted = await storage.deleteProduct(id);
      if (!deleted) {
        return res.status(500).json({ message: "Failed to delete product" });
      }
      
      res.json({ message: "Product deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Error deleting product" });
    }
  });

  // Activity routes
  app.get("/api/activities", isAuthenticated, async (req, res) => {
    try {
      const limit = req.query.limit ? Number(req.query.limit) : undefined;
      const activities = await storage.getActivities(limit);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Error fetching activities" });
    }
  });

  // Analytics routes
  app.get("/api/analytics/storage-utilization", isAuthenticated, async (req, res) => {
    try {
      const data = await storage.getStorageUtilization();
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: "Error fetching storage utilization data" });
    }
  });

  app.get("/api/analytics/monthly-revenue", isAuthenticated, async (req, res) => {
    try {
      const data = await storage.getMonthlyRevenue();
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: "Error fetching monthly revenue data" });
    }
  });

  app.get("/api/analytics/farmer-participation", isAuthenticated, async (req, res) => {
    try {
      const data = await storage.getFarmerParticipation();
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: "Error fetching farmer participation data" });
    }
  });

  // Stats for dashboard
  app.get("/api/stats/dashboard", isAuthenticated, async (req, res) => {
    try {
      const storageUnits = await storage.getStorageUnits();
      const farmers = await storage.getFarmers();
      const products = await storage.getProducts();
      
      // Get storage revenue from actual farmer inventory calculations
      let storageRevenue = 0;
      try {
        // Calculate all farmers' storage costs to get total revenue
        const allFarmers = await storage.getFarmers();
        let totalRevenue = 0;
        
        for (const farmer of allFarmers) {
          const inventoryItems = await storage.getFarmerInventory(farmer.id);
          const storageCosts = calculateFarmerStorageCosts(farmer.id, inventoryItems);
          totalRevenue += storageCosts.totalCost;
        }
        
        storageRevenue = totalRevenue;
      } catch (error) {
        console.error("Error calculating storage revenue:", error);
      }
      
      // Add marketplace revenue (from finance overview)
      const marketplaceRevenue = 500000; // This should eventually come from actual orders
      
      const totalStorageUnits = storageUnits.length;
      const activeFarmers = farmers.length;
      const marketplaceProducts = products.length;
      const monthlyRevenue = storageRevenue + marketplaceRevenue;
      
      res.json({
        totalStorageUnits,
        activeFarmers,
        marketplaceProducts,
        monthlyRevenue
      });
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Error fetching dashboard stats" });
    }
  });

  // Orders API
  app.get("/api/orders", async (req, res) => {
    try {
      const { status, dateRange, search } = req.query;
      
      let orders = await storage.getOrders();
      
      // Apply filters
      if (status && status !== 'all') {
        orders = orders.filter(order => order.status === status);
      }
      
      if (dateRange && dateRange !== 'all') {
        const now = new Date();
        const startDate = new Date();
        
        switch(dateRange) {
          case 'today':
            startDate.setHours(0, 0, 0, 0);
            break;
          case 'last7days':
            startDate.setDate(now.getDate() - 7);
            break;
          case 'last30days':
            startDate.setDate(now.getDate() - 30);
            break;
          case 'thisMonth':
            startDate.setDate(1);
            startDate.setHours(0, 0, 0, 0);
            break;
          case 'lastMonth':
            startDate.setMonth(now.getMonth() - 1);
            startDate.setDate(1);
            startDate.setHours(0, 0, 0, 0);
            const endOfLastMonth = new Date(now.getFullYear(), now.getMonth(), 0);
            orders = orders.filter(order => {
              const orderDate = new Date(order.orderDate);
              return orderDate >= startDate && orderDate <= endOfLastMonth;
            });
            res.json(orders);
            return;
        }
        
        orders = orders.filter(order => new Date(order.orderDate) >= startDate);
      }
      
      if (search) {
        const searchLower = String(search).toLowerCase();
        orders = orders.filter(order => 
          order.customerName.toLowerCase().includes(searchLower) ||
          order.customerEmail.toLowerCase().includes(searchLower) ||
          order.deliveryAddress.toLowerCase().includes(searchLower) ||
          String(order.id).includes(searchLower)
        );
      }
      
      // Sort orders by date (newest first)
      orders.sort((a, b) => new Date(b.orderDate).getTime() - new Date(a.orderDate).getTime());
      
      res.json(orders);
    } catch (error) {
      console.error("Error fetching orders:", error);
      res.status(500).json({ error: "Failed to fetch orders" });
    }
  });
  
  app.get("/api/orders/:id", async (req, res) => {
    try {
      const orderId = parseInt(req.params.id);
      if (isNaN(orderId)) {
        return res.status(400).json({ error: "Invalid order ID" });
      }
      
      const order = await storage.getOrder(orderId);
      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }
      
      res.json(order);
    } catch (error) {
      console.error("Error fetching order:", error);
      res.status(500).json({ error: "Failed to fetch order" });
    }
  });
  
  app.get("/api/orders/:id/items", async (req, res) => {
    try {
      const orderId = parseInt(req.params.id);
      if (isNaN(orderId)) {
        return res.status(400).json({ error: "Invalid order ID" });
      }
      
      const orderItems = await storage.getOrderItems(orderId);
      res.json(orderItems);
    } catch (error) {
      console.error("Error fetching order items:", error);
      res.status(500).json({ error: "Failed to fetch order items" });
    }
  });
  
  app.post("/api/orders", async (req, res) => {
    try {
      const orderData = insertOrderSchema.parse(req.body);
      const newOrder = await storage.createOrder(orderData);
      
      // Create activity for order
      await storage.createActivity({
        type: "order_placed",
        description: `New order #${newOrder.id} placed by ${newOrder.customerName}`,
        details: { orderId: newOrder.id },
        timestamp: new Date(),
        relatedId: newOrder.id,
        relatedType: "order"
      });
      
      res.status(201).json(newOrder);
    } catch (error) {
      console.error("Error creating order:", error);
      res.status(400).json({ error: "Failed to create order" });
    }
  });
  
  app.post("/api/orders/:id/items", async (req, res) => {
    try {
      const orderId = parseInt(req.params.id);
      if (isNaN(orderId)) {
        return res.status(400).json({ error: "Invalid order ID" });
      }
      
      const order = await storage.getOrder(orderId);
      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }
      
      const itemData = insertOrderItemSchema.parse({
        ...req.body,
        orderId
      });
      
      const newItem = await storage.createOrderItem(itemData);
      res.status(201).json(newItem);
    } catch (error) {
      console.error("Error adding order item:", error);
      res.status(400).json({ error: "Failed to add order item" });
    }
  });
  
  app.patch("/api/orders/:id/status", async (req, res) => {
    try {
      const orderId = parseInt(req.params.id);
      if (isNaN(orderId)) {
        return res.status(400).json({ error: "Invalid order ID" });
      }
      
      const { status } = req.body;
      if (!status) {
        return res.status(400).json({ error: "Status is required" });
      }
      
      // Validate status
      if (!["pending", "processing", "shipped", "delivered", "completed", "cancelled"].includes(status)) {
        return res.status(400).json({ error: "Invalid status" });
      }
      
      const updatedOrder = await storage.updateOrderStatus(orderId, status);
      if (!updatedOrder) {
        return res.status(404).json({ error: "Order not found" });
      }
      
      // Create activity for status change
      await storage.createActivity({
        type: "order_status_updated",
        description: `Order #${orderId} status updated to ${status}`,
        details: { orderId, status },
        timestamp: new Date(),
        relatedId: orderId,
        relatedType: "order"
      });
      
      res.json(updatedOrder);
    } catch (error) {
      console.error("Error updating order status:", error);
      res.status(500).json({ error: "Failed to update order status" });
    }
  });

  // Initialize Stripe
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

  // Stripe Payment Routes
  app.post('/api/create-payment-intent', isAuthenticated, async (req, res) => {
    try {
      const { amount, currency = 'usd' } = req.body;
      
      // Create a PaymentIntent with the order amount and currency
      const paymentIntent = await stripe.paymentIntents.create({
        amount: amount * 100, // Amount in cents
        currency: currency.toLowerCase(),
        automatic_payment_methods: {
          enabled: true,
        },
      });

      // Send publishable key and PaymentIntent details to client
      res.json({
        clientSecret: paymentIntent.client_secret,
      });
    } catch (error: any) {
      console.error('Error creating payment intent:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Fetch list of invoices
  app.get('/api/invoices', isAuthenticated, async (req, res) => {
    try {
      // In production, these would come from the database
      // Using static mock data for demonstration
      const invoices = [
        {
          id: 1,
          invoiceNumber: "INV-2023-001",
          date: new Date("2023-01-15"),
          dueDate: new Date("2023-02-15"),
          customer: "Green Valley Farms",
          amount: 1250.00,
          status: "paid",
        },
        {
          id: 2,
          invoiceNumber: "INV-2023-002",
          date: new Date("2023-02-01"),
          dueDate: new Date("2023-03-01"),
          customer: "Organic Harvest Co.",
          amount: 980.50,
          status: "paid",
        },
        {
          id: 3,
          invoiceNumber: "INV-2023-003",
          date: new Date("2023-02-15"),
          dueDate: new Date("2023-03-15"),
          customer: "Sunshine Foods Ltd.",
          amount: 1600.25,
          status: "paid",
        },
        {
          id: 4,
          invoiceNumber: "INV-2023-004",
          date: new Date("2023-03-05"),
          dueDate: new Date("2023-04-05"),
          customer: "Nature's Best Produce",
          amount: 2100.75,
          status: "pending",
        },
        {
          id: 5,
          invoiceNumber: "INV-2023-005",
          date: new Date("2023-03-20"),
          dueDate: new Date("2023-04-20"),
          customer: "Fresh Fields Farms",
          amount: 750.30,
          status: "overdue",
        },
        {
          id: 6,
          invoiceNumber: "INV-2023-006",
          date: new Date("2023-04-01"),
          dueDate: new Date("2023-05-01"),
          customer: "Green Valley Farms",
          amount: 1350.00,
          status: "pending",
        },
        {
          id: 7,
          invoiceNumber: "INV-2023-007",
          date: new Date("2023-04-15"),
          dueDate: new Date("2023-05-15"),
          customer: "Organic Harvest Co.",
          amount: 1100.50,
          status: "draft",
        },
      ];
      
      res.json(invoices);
    } catch (error: any) {
      console.error('Error fetching invoices:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Fetch list of payment transactions
  app.get('/api/payment-transactions', isAuthenticated, async (req, res) => {
    try {
      // In production, these would come from the database or Stripe API
      // Using static mock data for demonstration
      const payments = [
        {
          id: 1,
          transactionId: "TRX12345",
          date: new Date("2023-04-15"),
          description: "Storage fees payment",
          amount: 1250.00,
          method: "credit_card",
          status: "completed",
        },
        {
          id: 2,
          transactionId: "TRX12346",
          date: new Date("2023-04-01"),
          description: "Marketplace commission",
          amount: 450.75,
          method: "bank_transfer",
          status: "completed",
        },
        {
          id: 3,
          transactionId: "TRX12347",
          date: new Date("2023-03-15"),
          description: "Storage fees payment",
          amount: 1250.00,
          method: "credit_card",
          status: "completed",
        },
        {
          id: 4,
          transactionId: "TRX12348",
          date: new Date("2023-03-10"),
          description: "Marketplace commission",
          amount: 325.50,
          method: "bank_transfer",
          status: "completed",
        },
        {
          id: 5,
          transactionId: "TRX12349",
          date: new Date("2023-02-15"),
          description: "Storage fees payment",
          amount: 1250.00,
          method: "credit_card",
          status: "completed",
        },
      ];
      
      res.json(payments);
    } catch (error: any) {
      console.error('Error fetching payment transactions:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Get upcoming payments
  app.get('/api/upcoming-payments', isAuthenticated, async (req, res) => {
    try {
      // In production, these would be calculated based on subscription information
      const upcomingPayments = [
        {
          id: 1,
          description: "Storage fees - May 2023",
          dueDate: new Date("2023-05-15"),
          amount: 1250.00,
          status: "pending",
        },
        {
          id: 2,
          description: "Marketplace fees - May 2023",
          dueDate: new Date("2023-05-05"),
          amount: 480.25,
          status: "pending",
        },
      ];
      
      res.json(upcomingPayments);
    } catch (error: any) {
      console.error('Error fetching upcoming payments:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Get payment stats
  app.get('/api/payment-stats', isAuthenticated, async (req, res) => {
    try {
      // In production, these would be calculated from actual payment data
      const stats = {
        thisMonth: 3275.50,
        upcoming: 1730.25,
        successRate: 99.2,
        totalYTD: 32750.00
      };
      
      res.json(stats);
    } catch (error: any) {
      console.error('Error fetching payment stats:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Storage Billing Routes
  app.get("/api/finance/storage-costs/:farmerId", isAuthenticated, async (req, res) => {
    try {
      const farmerId = Number(req.params.farmerId);
      
      // Get farmer details to ensure they exist
      const farmer = await storage.getFarmer(farmerId);
      if (!farmer) {
        return res.status(404).json({ message: "Farmer not found" });
      }
      
      // Get all inventory items for this farmer
      const inventoryItems = await storage.getFarmerInventory(farmerId);
      
      // Calculate storage costs
      const storageCosts = calculateFarmerStorageCosts(farmerId, inventoryItems);
      
      res.json(storageCosts);
    } catch (error) {
      console.error("Error calculating storage costs:", error);
      res.status(500).json({ message: "Error calculating storage costs" });
    }
  });
  
  // Generate storage statement for a farmer
  app.get("/api/finance/storage-statement/:farmerId", isAuthenticated, async (req, res) => {
    try {
      const farmerId = Number(req.params.farmerId);
      
      // Get farmer details to ensure they exist
      const farmer = await storage.getFarmer(farmerId);
      if (!farmer) {
        return res.status(404).json({ message: "Farmer not found" });
      }
      
      // Get all inventory items for this farmer
      const inventoryItems = await storage.getFarmerInventory(farmerId);
      
      // Calculate storage costs
      const storageCosts = calculateFarmerStorageCosts(farmerId, inventoryItems);
      
      // Generate formatted statement
      const statement = formatStorageStatement(storageCosts);
      
      res.json({ statement, farmer, storageCosts });
    } catch (error) {
      console.error("Error generating storage statement:", error);
      res.status(500).json({ message: "Error generating storage statement" });
    }
  });
  
  // Get storage costs for all farmers (admin overview)
  app.get("/api/finance/storage-costs", isAuthenticated, async (req, res) => {
    try {
      // Get all farmers
      const farmers = await storage.getFarmers();
      
      // Calculate storage costs for each farmer
      const farmersWithCosts = await Promise.all(
        farmers.map(async (farmer) => {
          const inventoryItems = await storage.getFarmerInventory(farmer.id);
          const storageCosts = calculateFarmerStorageCosts(farmer.id, inventoryItems);
          
          return {
            farmerId: farmer.id,
            farmerName: farmer.name,
            totalCost: storageCosts.totalCost,
            formattedCost: storageCosts.formattedCost,
            itemCount: storageCosts.itemCount,
            totalWeight: storageCosts.totalWeight
          };
        })
      );
      
      // Sort by cost (highest first)
      farmersWithCosts.sort((a, b) => b.totalCost - a.totalCost);
      
      // Calculate total revenue from storage
      const totalRevenue = farmersWithCosts.reduce((sum, farmer) => sum + farmer.totalCost, 0);
      
      res.json({
        farmers: farmersWithCosts,
        totalRevenue,
        formattedTotalRevenue: formatCurrency(totalRevenue)
      });
    } catch (error) {
      console.error("Error calculating all storage costs:", error);
      res.status(500).json({ message: "Error calculating all storage costs" });
    }
  });

  // WebSocket test page
  app.get('/ws-test', (req, res) => {
    res.sendFile(path.resolve('./websocket-test.html'));
  });
  
  // Enhanced WebSocket test tool route
  app.get('/ws-test-tool', (req, res) => {
    res.sendFile(path.resolve('./public/ws-test-tool.html'));
  });
  
  // WebSocket connection stats API
  app.get('/api/ws-stats', (req, res) => {
    res.json({
      connectedClients: getConnectedClientCount(),
      authenticatedFarmers: getAuthenticatedFarmerCount()
    });
  });

  // API route to test WebSocket broadcasts
  app.post('/api/test-broadcast', async (req, res) => {
    try {
      const { type, data } = req.body;
      
      if (!type || !data) {
        return res.status(400).json({ message: 'Type and data are required' });
      }
      
      broadcastUpdate(type, data);
      
      res.json({ 
        message: 'Broadcast sent successfully', 
        type, 
        data,
        connectedClients: getConnectedClientCount(),
        authenticatedFarmers: getAuthenticatedFarmerCount()
      });
    } catch (error) {
      console.error('Error broadcasting message:', error);
      res.status(500).json({ message: 'Error broadcasting message' });
    }
  });
  
  // Storage Booking API (Admin)
  app.get("/api/storage-bookings", isAuthenticated, async (req, res) => {
    try {
      const { status } = req.query;
      
      let bookings: StorageBooking[];
      if (status) {
        bookings = await storage.getStorageBookingsByStatus(status as string);
      } else {
        bookings = await storage.getStorageBookings();
      }
      
      // Enhance bookings with storage unit and farmer details
      const enhancedBookings = await Promise.all(bookings.map(async booking => {
        const [storageUnit, farmer] = await Promise.all([
          storage.getStorageUnit(booking.storageUnitId),
          storage.getFarmer(booking.farmerId)
        ]);
        
        return {
          ...booking,
          storageUnitName: storageUnit?.location || 'Unknown',
          farmerName: farmer?.name || 'Unknown'
        };
      }));
      
      res.json(enhancedBookings);
    } catch (error) {
      console.error("Error fetching storage bookings:", error);
      res.status(500).json({ message: "Error fetching storage bookings" });
    }
  });
  
  app.get("/api/storage-bookings/:id", isAuthenticated, async (req, res) => {
    try {
      const bookingId = Number(req.params.id);
      const booking = await storage.getStorageBooking(bookingId);
      
      if (!booking) {
        return res.status(404).json({ message: "Storage booking not found" });
      }
      
      // Get storage unit and farmer details
      const [storageUnit, farmer, inventoryItem] = await Promise.all([
        storage.getStorageUnit(booking.storageUnitId),
        storage.getFarmer(booking.farmerId),
        booking.inventoryItemId ? storage.getFarmerInventoryItem(booking.inventoryItemId) : null
      ]);
      
      // Calculate daily and total cost based on quantity and daily rate (10 XAF per kg per day)
      const durationDays = booking.endDate ? 
        Math.ceil((booking.endDate.getTime() - booking.startDate.getTime()) / (1000 * 60 * 60 * 24)) : 
        30; // Default to 30 days if no end date
        
      const dailyRate = 10; // XAF per kg per day
      const dailyCost = booking.quantity * dailyRate;
      const totalCost = dailyCost * durationDays;
      
      const enhancedBooking = {
        ...booking,
        storageUnit,
        farmer,
        inventoryItem,
        costs: {
          dailyRate,
          dailyCost,
          durationDays,
          totalCost
        }
      };
      
      res.json(enhancedBooking);
    } catch (error) {
      console.error("Error fetching storage booking:", error);
      res.status(500).json({ message: "Error fetching storage booking" });
    }
  });
  
  app.post("/api/storage-bookings", isAuthenticated, async (req, res) => {
    try {
      // Validate request data
      const validatedData = insertStorageBookingSchema.parse({
        ...req.body,
        startDate: new Date(req.body.startDate),
        endDate: req.body.endDate ? new Date(req.body.endDate) : null,
        requestDate: new Date()
      });
      
      // Create the booking
      const booking = await storage.createStorageBooking(validatedData);
      
      // Return the created booking
      res.status(201).json({
        booking,
        message: "Storage booking request created successfully"
      });
    } catch (error) {
      console.error("Error creating storage booking:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating storage booking" });
    }
  });
  
  app.patch("/api/storage-bookings/:id/status", isAuthenticated, async (req, res) => {
    try {
      const bookingId = Number(req.params.id);
      const { status, adminNotes } = req.body;
      
      if (!status) {
        return res.status(400).json({ message: "Status is required" });
      }
      
      // Validate status
      if (!["pending", "approved", "rejected", "active", "completed", "cancelled"].includes(status)) {
        return res.status(400).json({ message: "Invalid status value" });
      }
      
      // Update booking status
      const updatedBooking = await storage.updateStorageBookingStatus(bookingId, status, adminNotes);
      
      if (!updatedBooking) {
        return res.status(404).json({ message: "Storage booking not found" });
      }
      
      // Create appropriate activity log
      let activityDescription = `Storage booking status updated to ${status}`;
      if (status === "approved") {
        activityDescription = "Storage booking approved";
      } else if (status === "rejected") {
        activityDescription = "Storage booking rejected";
      }
      
      await storage.createActivity({
        type: "booking_status_update",
        description: activityDescription,
        details: { 
          bookingId, 
          status, 
          adminNotes
        },
        timestamp: new Date(),
        relatedId: bookingId,
        relatedType: "storage_booking"
      });
      
      res.json({
        booking: updatedBooking,
        message: `Storage booking ${status} successfully`
      });
    } catch (error) {
      console.error("Error updating storage booking status:", error);
      res.status(500).json({ message: "Error updating storage booking status" });
    }
  });
  
  app.delete("/api/storage-bookings/:id", isAuthenticated, async (req, res) => {
    try {
      const bookingId = Number(req.params.id);
      
      // Delete the booking
      const success = await storage.deleteStorageBooking(bookingId);
      
      if (!success) {
        return res.status(404).json({ message: "Storage booking not found" });
      }
      
      res.json({ message: "Storage booking deleted successfully" });
    } catch (error) {
      console.error("Error deleting storage booking:", error);
      res.status(500).json({ message: "Error deleting storage booking" });
    }
  });
  
  // Register mobile API endpoints for farmer and consumer apps
  registerAPIs(app);
  
  // Register Categories API
  registerCategoriesAPI(app);
  registerMobileFarmerAPI(app);

  const httpServer = createServer(app);
  
  // Setup WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  wss.on("connection", (ws) => {
    console.log("New client connected");
    
    ws.on("message", (messageData) => {
      try {
        const message = JSON.parse(messageData.toString());
        console.log("Received message:", message);
        
        if (message.type === "auth") {
          (ws as any).farmerId = message.farmerId;
        }
      } catch (error) {
        console.error("Error processing message:", error);
      }
    });
  });
  
  // Make WSS available globally
  (global as any).wss = wss;

  return httpServer;
}
