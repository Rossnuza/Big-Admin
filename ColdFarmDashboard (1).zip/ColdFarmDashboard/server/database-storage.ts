import { 
  users, type User, type InsertUser,
  storageUnits, type StorageUnit, type InsertStorageUnit,
  farmers, type Farmer, type InsertFarmer,
  farmerInventory, type FarmerInventory, type InsertFarmerInventory,
  products, type Product, type InsertProduct,
  activities, type Activity, type InsertActivity,
  orders, type Order, type InsertOrder,
  orderItems, type OrderItem, type InsertOrderItem,
  storageBookings, type StorageBooking, type InsertStorageBooking,
  categories, type Category, type InsertCategory,
  productTypes, type ProductType, type InsertProductType
} from "@shared/schema";
import { db } from "./db";
import { IStorage } from "./storage";
import { eq, desc, and, lte, gte, sql, count, sum } from "drizzle-orm";
import { broadcastUpdate } from "./utils/websocket";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export class DatabaseStorage implements IStorage {
  sessionStore: any; // Will be initialized with PostgresSessionStore

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true,
      tableName: 'session'
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  // Storage Units
  async getStorageUnits(): Promise<StorageUnit[]> {
    return db.select().from(storageUnits);
  }
  
  async getStorageUnit(id: number): Promise<StorageUnit | undefined> {
    const [unit] = await db.select().from(storageUnits).where(eq(storageUnits.id, id));
    return unit;
  }
  
  async getStorageUnitByUnitId(unitId: string): Promise<StorageUnit | undefined> {
    const [unit] = await db.select().from(storageUnits).where(eq(storageUnits.unitId, unitId));
    return unit;
  }
  
  async createStorageUnit(insertStorageUnit: InsertStorageUnit): Promise<StorageUnit> {
    const [unit] = await db.insert(storageUnits).values(insertStorageUnit).returning();
    return unit;
  }
  
  async updateStorageUnit(id: number, storageUnit: Partial<StorageUnit>): Promise<StorageUnit | undefined> {
    const [updated] = await db
      .update(storageUnits)
      .set(storageUnit)
      .where(eq(storageUnits.id, id))
      .returning();
    return updated;
  }
  
  async deleteStorageUnit(id: number): Promise<boolean> {
    try {
      await db.delete(storageUnits).where(eq(storageUnits.id, id));
      return true;
    } catch (error) {
      console.error("Error deleting storage unit:", error);
      return false;
    }
  }
  
  // Farmers
  async getFarmers(): Promise<Farmer[]> {
    return db.select().from(farmers);
  }
  
  async getFarmer(id: number): Promise<Farmer | undefined> {
    const [farmer] = await db.select().from(farmers).where(eq(farmers.id, id));
    return farmer;
  }
  
  async getFarmerByPhone(phone: string): Promise<Farmer | undefined> {
    const [farmer] = await db.select().from(farmers).where(eq(farmers.phone, phone));
    return farmer;
  }
  
  async createFarmer(insertFarmer: InsertFarmer): Promise<Farmer> {
    const [farmer] = await db.insert(farmers).values(insertFarmer).returning();
    
    // Create activity for new farmer
    await this.createActivity({
      type: "new_farmer",
      description: "New farmer onboarded",
      details: { farmerName: farmer.name },
      timestamp: new Date(),
      relatedId: farmer.id,
      relatedType: "farmer"
    });
    
    return farmer;
  }
  
  async updateFarmer(id: number, farmer: Partial<Farmer>): Promise<Farmer | undefined> {
    // Handle date fields that might be passed as strings
    const preparedData = {
      ...farmer,
      lastLogin: farmer.lastLogin instanceof Date ? farmer.lastLogin : 
                 farmer.lastLogin ? new Date(farmer.lastLogin) : undefined,
      joinDate: farmer.joinDate instanceof Date ? farmer.joinDate : 
                farmer.joinDate ? new Date(farmer.joinDate) : undefined,
    };
    
    const [updated] = await db
      .update(farmers)
      .set(preparedData)
      .where(eq(farmers.id, id))
      .returning();
    return updated;
  }
  
  async updateFarmerVerification(id: number, verificationStatus: string, temporaryPasscode?: string): Promise<Farmer | undefined> {
    const updateData: Partial<Farmer> = {
      verificationStatus,
      ...(temporaryPasscode !== undefined && { temporaryPasscode })
    };
    
    return this.updateFarmer(id, updateData);
  }
  
  async updateFarmerLastLogin(id: number): Promise<Farmer | undefined> {
    return this.updateFarmer(id, { lastLogin: new Date() });
  }
  
  async deleteFarmer(id: number): Promise<boolean> {
    try {
      await db.delete(farmers).where(eq(farmers.id, id));
      return true;
    } catch (error) {
      console.error("Error deleting farmer:", error);
      return false;
    }
  }
  
  async getTopFarmers(limit: number): Promise<Farmer[]> {
    // Get farmers with the most inventory items as a proxy for "top farmers"
    const farmersWithCounts = await db
      .select({
        farmer: farmers,
        inventoryCount: count(farmerInventory.id)
      })
      .from(farmers)
      .leftJoin(
        farmerInventory,
        eq(farmers.id, farmerInventory.farmerId)
      )
      .groupBy(farmers.id)
      .orderBy(desc(count(farmerInventory.id)))
      .limit(limit);
    
    return farmersWithCounts.map(row => row.farmer);
  }
  
  // Farmer Inventory
  async getFarmerInventory(farmerId: number): Promise<FarmerInventory[]> {
    return db
      .select()
      .from(farmerInventory)
      .where(eq(farmerInventory.farmerId, farmerId));
  }
  
  async getFarmerInventoryItem(id: number): Promise<FarmerInventory | undefined> {
    const [item] = await db
      .select()
      .from(farmerInventory)
      .where(eq(farmerInventory.id, id));
    return item;
  }
  
  async createFarmerInventory(insertInventory: InsertFarmerInventory): Promise<FarmerInventory> {
    const [inventory] = await db
      .insert(farmerInventory)
      .values(insertInventory)
      .returning();
    
    // Create activity for the new inventory item
    await this.createActivity({
      type: "storage_added",
      description: `New product added to storage`,
      details: { 
        productName: inventory.productName, 
        quantity: inventory.quantity,
        unit: inventory.unit,
        farmerId: inventory.farmerId,
        storageUnitId: inventory.storageUnitId
      },
      timestamp: new Date(),
      relatedId: inventory.farmerId,
      relatedType: "farmer"
    });
    
    return inventory;
  }
  
  async updateFarmerInventory(id: number, inventory: Partial<FarmerInventory>): Promise<FarmerInventory | undefined> {
    const [updated] = await db
      .update(farmerInventory)
      .set(inventory)
      .where(eq(farmerInventory.id, id))
      .returning();
    return updated;
  }
  
  async deleteFarmerInventory(id: number): Promise<boolean> {
    try {
      await db.delete(farmerInventory).where(eq(farmerInventory.id, id));
      return true;
    } catch (error) {
      console.error("Error deleting farmer inventory:", error);
      return false;
    }
  }
  
  async getAllFarmerInventories(): Promise<FarmerInventory[]> {
    return db.select().from(farmerInventory);
  }
  
  // Products
  async getProducts(): Promise<Product[]> {
    return db.select().from(products);
  }
  
  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }
  
  async getProductsByFarmer(farmerId: number): Promise<Product[]> {
    return db
      .select()
      .from(products)
      .where(eq(products.farmerId, farmerId));
  }
  
  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const [product] = await db.insert(products).values(insertProduct).returning();
    
    // Create activity for new product
    await this.createActivity({
      type: "product_added",
      description: `New product added to marketplace`,
      details: { 
        productName: product.name, 
        category: product.category,
        farmerId: product.farmerId,
      },
      timestamp: new Date(),
      relatedId: product.farmerId,
      relatedType: "farmer"
    });
    
    return product;
  }
  
  async updateProduct(id: number, product: Partial<Product>): Promise<Product | undefined> {
    const [updated] = await db
      .update(products)
      .set(product)
      .where(eq(products.id, id))
      .returning();
    return updated;
  }
  
  async deleteProduct(id: number): Promise<boolean> {
    try {
      await db.delete(products).where(eq(products.id, id));
      return true;
    } catch (error) {
      console.error("Error deleting product:", error);
      return false;
    }
  }
  
  // Activities
  async getActivities(limit?: number): Promise<Activity[]> {
    const query = db
      .select()
      .from(activities)
      .orderBy(desc(activities.timestamp));
    
    if (limit) {
      query.limit(limit);
    }
    
    return query;
  }
  
  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const [activity] = await db.insert(activities).values(insertActivity).returning();
    return activity;
  }
  
  // Orders
  async getOrders(): Promise<Order[]> {
    // Only select columns that exist in the database
    return db.select({
      id: orders.id,
      customerName: orders.customerName,
      customerEmail: orders.customerEmail,
      total: orders.total,
      status: orders.status,
      orderDate: orders.orderDate,
      deliveryAddress: orders.deliveryAddress,
      paymentMethod: orders.paymentMethod
    }).from(orders).orderBy(desc(orders.orderDate));
  }
  
  async getOrder(id: number): Promise<Order | undefined> {
    // Only select columns that exist in the database
    const [order] = await db.select({
      id: orders.id,
      customerName: orders.customerName,
      customerEmail: orders.customerEmail,
      total: orders.total,
      status: orders.status,
      orderDate: orders.orderDate,
      deliveryAddress: orders.deliveryAddress,
      paymentMethod: orders.paymentMethod
    }).from(orders).where(eq(orders.id, id));
    return order;
  }
  
  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    // Extract only the fields that exist in the database
    const orderData = {
      customerName: insertOrder.customerName,
      customerEmail: insertOrder.customerEmail,
      total: insertOrder.total,
      status: insertOrder.status || 'pending',
      deliveryAddress: insertOrder.deliveryAddress,
      paymentMethod: insertOrder.paymentMethod || 'mobile_money'
    };
    
    const [order] = await db.insert(orders).values(orderData).returning({
      id: orders.id,
      customerName: orders.customerName,
      customerEmail: orders.customerEmail,
      total: orders.total,
      status: orders.status,
      orderDate: orders.orderDate,
      deliveryAddress: orders.deliveryAddress,
      paymentMethod: orders.paymentMethod
    });
    
    // Create activity for new order
    await this.createActivity({
      type: "order_placed",
      description: `New order placed`,
      details: { 
        customerName: order.customerName, 
        total: order.total,
        orderDate: order.orderDate,
      },
      timestamp: new Date(),
      relatedId: order.id,
      relatedType: "order"
    });
    
    return order;
  }
  
  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const [updated] = await db
      .update(orders)
      .set({ status })
      .where(eq(orders.id, id))
      .returning({
        id: orders.id,
        customerName: orders.customerName,
        customerEmail: orders.customerEmail,
        total: orders.total,
        status: orders.status,
        orderDate: orders.orderDate,
        deliveryAddress: orders.deliveryAddress,
        paymentMethod: orders.paymentMethod
      });
    
    // Create activity for order status update
    if (updated) {
      await this.createActivity({
        type: "order_status_updated",
        description: `Order status updated to ${status}`,
        details: { 
          orderId: id, 
          status: status,
        },
        timestamp: new Date(),
        relatedId: id,
        relatedType: "order"
      });
    }
    
    return updated;
  }
  
  // Order Items
  async getOrderItems(orderId: number): Promise<OrderItem[]> {
    return db
      .select()
      .from(orderItems)
      .where(eq(orderItems.orderId, orderId));
  }
  
  async createOrderItem(insertOrderItem: InsertOrderItem): Promise<OrderItem> {
    const [orderItem] = await db.insert(orderItems).values(insertOrderItem).returning();
    return orderItem;
  }
  
  // Storage Bookings
  async getStorageBookings(): Promise<StorageBooking[]> {
    return db.select().from(storageBookings).orderBy(desc(storageBookings.requestDate));
  }
  
  async getStorageBookingsByFarmer(farmerId: number): Promise<StorageBooking[]> {
    return db
      .select()
      .from(storageBookings)
      .where(eq(storageBookings.farmerId, farmerId))
      .orderBy(desc(storageBookings.requestDate));
  }
  
  async getStorageBookingsByStatus(status: string): Promise<StorageBooking[]> {
    return db
      .select()
      .from(storageBookings)
      .where(eq(storageBookings.status, status))
      .orderBy(desc(storageBookings.requestDate));
  }
  
  async getStorageBooking(id: number): Promise<StorageBooking | undefined> {
    const [booking] = await db
      .select()
      .from(storageBookings)
      .where(eq(storageBookings.id, id));
    return booking;
  }
  
  async createStorageBooking(insertBooking: InsertStorageBooking): Promise<StorageBooking> {
    // Add current timestamps if not provided
    const bookingData = {
      ...insertBooking,
      lastUpdated: new Date()
    };
    
    const [booking] = await db
      .insert(storageBookings)
      .values(bookingData)
      .returning();
      
    // Broadcast the booking request
    broadcastUpdate("booking_request_created", booking);
    
    // Targeted message to the specific farmer
    broadcastUpdate("farmer_booking_created", {
      farmerId: booking.farmerId,
      booking
    });
    
    // Create activity for the new booking request
    await this.createActivity({
      type: "storage_booking_request",
      description: `Storage booking requested by ${(await this.getFarmer(booking.farmerId))?.name || 'Unknown farmer'}`,
      details: {
        bookingId: booking.id,
        farmerId: booking.farmerId,
        productName: booking.productName,
        quantity: booking.quantity,
        unit: booking.unit
      },
      timestamp: new Date(),
      relatedId: booking.id,
      relatedType: "storage_booking"
    });
    
    return booking;
  }
  
  async updateStorageBooking(id: number, booking: Partial<StorageBooking>): Promise<StorageBooking | undefined> {
    // Always update the lastUpdated timestamp
    const updateData = {
      ...booking,
      lastUpdated: new Date()
    };
    
    const [updated] = await db
      .update(storageBookings)
      .set(updateData)
      .where(eq(storageBookings.id, id))
      .returning();
      
    if (updated) {
      // Broadcast booking update
      broadcastUpdate("booking_request_updated", updated);
      
      // Targeted message to the specific farmer
      broadcastUpdate("farmer_booking_updated", {
        farmerId: updated.farmerId,
        booking: updated
      });
    }
    
    return updated;
  }
  
  async updateStorageBookingStatus(id: number, status: string, adminNotes?: string): Promise<StorageBooking | undefined> {
    // Get the current booking to check if status is changing
    const currentBooking = await this.getStorageBooking(id);
    if (!currentBooking) return undefined;
    
    // Prepare update data
    const updateData: Partial<StorageBooking> = {
      status,
      lastUpdated: new Date()
    };
    
    // Update adminNotes if provided
    if (adminNotes !== undefined) {
      updateData.adminNotes = adminNotes;
    }
    
    // Update the booking status
    const [updated] = await db
      .update(storageBookings)
      .set(updateData)
      .where(eq(storageBookings.id, id))
      .returning();
    
    if (!updated) return undefined;
    
    // Broadcast the status change
    broadcastUpdate("booking_status_changed", {
      bookingId: updated.id,
      oldStatus: currentBooking.status,
      newStatus: updated.status,
      farmerId: updated.farmerId
    });
    
    // Targeted message to the specific farmer
    broadcastUpdate("farmer_booking_status_changed", {
      farmerId: updated.farmerId,
      bookingId: updated.id,
      status: updated.status
    });
    
    // If status changed to approved, create an inventory item
    if (status === "approved" && currentBooking.status !== "approved") {
      try {
        // Create a new inventory item from the approved booking
        const inventory = await this.createFarmerInventory({
          farmerId: updated.farmerId,
          storageUnitId: updated.storageUnitId,
          productName: updated.productName,
          quantity: updated.quantity,
          unit: updated.unit,
          startDate: updated.startDate,
          endDate: updated.endDate,
          dailyRate: true,
          status: "active",
          notes: `Created from booking #${updated.id}`
        });
        
        // Link the inventory item to the booking
        const [updatedWithInventory] = await db
          .update(storageBookings)
          .set({ inventoryItemId: inventory.id })
          .where(eq(storageBookings.id, id))
          .returning();
        
        // Create activity for the approval
        await this.createActivity({
          type: "storage_booking_approved",
          description: `Storage booking #${id} approved and inventory created`,
          details: {
            bookingId: id,
            inventoryId: inventory.id,
            farmerId: updated.farmerId
          },
          relatedId: id,
          relatedType: "storage_booking"
        });
        
        return updatedWithInventory;
      } catch (error) {
        console.error("Error creating inventory from approved booking:", error);
        return updated;
      }
    } else if (status === "rejected" && currentBooking.status !== "rejected") {
      // Create activity for the rejection
      await this.createActivity({
        type: "storage_booking_rejected",
        description: `Storage booking #${id} rejected`,
        details: {
          bookingId: id,
          farmerId: updated.farmerId,
          reason: adminNotes
        },
        relatedId: id,
        relatedType: "storage_booking"
      });
    } else if (status === "cancelled" && currentBooking.status !== "cancelled") {
      // Create activity for the cancellation
      await this.createActivity({
        type: "storage_booking_cancelled",
        description: `Storage booking #${id} cancelled`,
        details: {
          bookingId: id,
          farmerId: updated.farmerId
        },
        relatedId: id,
        relatedType: "storage_booking"
      });
    }
    
    return updated;
  }
  
  async deleteStorageBooking(id: number): Promise<boolean> {
    try {
      // Get the booking first to create activity log after deletion
      const booking = await this.getStorageBooking(id);
      if (!booking) return false;
      
      await db.delete(storageBookings).where(eq(storageBookings.id, id));
      
      // Broadcast deletion
      broadcastUpdate("booking_deleted", {
        bookingId: id,
        farmerId: booking.farmerId,
        status: booking.status
      });
      
      // Targeted message to the specific farmer
      broadcastUpdate("farmer_booking_deleted", {
        farmerId: booking.farmerId,
        bookingId: id
      });
      
      // Create activity for deleted booking
      await this.createActivity({
        type: "storage_booking_deleted",
        description: `Storage booking #${id} deleted`,
        details: {
          bookingId: id,
          farmerId: booking.farmerId
        },
        relatedId: booking.farmerId,
        relatedType: "farmer"
      });
      
      return true;
    } catch (error) {
      console.error("Error deleting storage booking:", error);
      return false;
    }
  }
  
  // Analytics
  async getStorageUtilization(): Promise<{location: string, capacityPercentage: number}[]> {
    const storageUnitsWithUtilization = await db
      .select({
        location: storageUnits.location,
        capacity: storageUnits.capacity,
        maxCapacity: storageUnits.maxCapacity
      })
      .from(storageUnits);
    
    return storageUnitsWithUtilization.map(unit => ({
      location: unit.location,
      capacityPercentage: Math.round((unit.capacity / unit.maxCapacity) * 100)
    }));
  }
  
  async getMonthlyRevenue(): Promise<{month: string, revenue: number}[]> {
    // This is a placeholder. In a real implementation, we would query the orders table
    // and aggregate by month.
    // For now, we'll return some sample data to match what our frontend expects
    
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth(); // 0-11
    
    const monthlyData: { month: string, revenue: number }[] = [];
    const baseRevenue = 9500;
    const growthFactor = 500;
    
    // Return data for the last 6 months
    for (let i = 0; i < 6; i++) {
      const monthIndex = (currentMonth - 5 + i + 12) % 12; // Ensure we wrap around to previous year
      monthlyData.push({
        month: months[monthIndex],
        revenue: baseRevenue + (i * growthFactor)
      });
    }
    
    return monthlyData;
  }
  
  async getFarmerParticipation(): Promise<{optIn: number, optOut: number}> {
    const optInCount = await db
      .select({ count: count() })
      .from(farmers)
      .where(eq(farmers.marketplaceOptIn, true));
    
    const optOutCount = await db
      .select({ count: count() })
      .from(farmers)
      .where(eq(farmers.marketplaceOptIn, false));
    
    return {
      optIn: optInCount[0].count,
      optOut: optOutCount[0].count
    };
  }
  
  // Category methods
  async getCategories(): Promise<Category[]> {
    const cats = await db.select().from(categories);
    
    // Calculate product count for each category
    const catsWithCount = await Promise.all(cats.map(async (category) => {
      const [result] = await db
        .select({ count: count() })
        .from(productTypes)
        .where(eq(productTypes.category, category.name));
      
      return {
        ...category,
        productCount: result.count
      };
    }));
    
    return catsWithCount;
  }
  
  async getCategory(id: number): Promise<Category | undefined> {
    const [category] = await db
      .select()
      .from(categories)
      .where(eq(categories.id, id));
    
    if (!category) return undefined;
    
    // Calculate product count
    const [result] = await db
      .select({ count: count() })
      .from(productTypes)
      .where(eq(productTypes.category, category.name));
    
    return {
      ...category,
      productCount: result.count
    };
  }
  
  async getCategoryByName(name: string): Promise<Category | undefined> {
    const [category] = await db
      .select()
      .from(categories)
      .where(eq(categories.name, name));
    
    if (!category) return undefined;
    
    // Calculate product count
    const [result] = await db
      .select({ count: count() })
      .from(productTypes)
      .where(eq(productTypes.category, category.name));
    
    return {
      ...category,
      productCount: result.count
    };
  }
  
  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const [category] = await db
      .insert(categories)
      .values({
        ...insertCategory,
        createdAt: new Date()
      })
      .returning();
    
    // Create activity for the new category
    await this.createActivity({
      type: "category_created",
      description: `New product category created: ${category.name}`,
      details: { categoryName: category.name },
      timestamp: new Date(),
      relatedType: "category"
    });
    
    // Broadcast category creation event
    broadcastUpdate("category_created", {
      ...category,
      productCount: 0
    });
    
    return {
      ...category,
      productCount: 0
    };
  }
  
  async updateCategory(id: number, categoryUpdate: Partial<Category>): Promise<Category | undefined> {
    // Don't update computed fields
    const { productCount, ...updateFields } = categoryUpdate;
    
    const [updated] = await db
      .update(categories)
      .set(updateFields)
      .where(eq(categories.id, id))
      .returning();
    
    if (!updated) return undefined;
    
    // Calculate product count
    const [result] = await db
      .select({ count: count() })
      .from(productTypes)
      .where(eq(productTypes.category, updated.name));
    
    const updatedWithCount = {
      ...updated,
      productCount: result.count
    };
    
    // Broadcast category update event
    broadcastUpdate("category_updated", updatedWithCount);
    
    return updatedWithCount;
  }
  
  async deleteCategory(id: number): Promise<boolean> {
    // Check if there are product types using this category
    const [category] = await db
      .select()
      .from(categories)
      .where(eq(categories.id, id));
    
    if (!category) return false;
    
    const [result] = await db
      .select({ count: count() })
      .from(productTypes)
      .where(eq(productTypes.category, category.name));
    
    if (result.count > 0) {
      // Cannot delete a category in use
      return false;
    }
    
    // Safe to delete
    try {
      await db
        .delete(categories)
        .where(eq(categories.id, id));
      
      // Broadcast category deletion event
      broadcastUpdate("category_deleted", { 
        categoryId: id, 
        name: category.name 
      });
      
      return true;
    } catch (error) {
      console.error("Error deleting category:", error);
      return false;
    }
  }
  
  // Product Type methods
  async getProductTypes(): Promise<ProductType[]> {
    return db.select().from(productTypes);
  }
  
  async getProductTypesByCategory(category: string): Promise<ProductType[]> {
    return db
      .select()
      .from(productTypes)
      .where(eq(productTypes.category, category));
  }
  
  async getProductType(id: number): Promise<ProductType | undefined> {
    const [productType] = await db
      .select()
      .from(productTypes)
      .where(eq(productTypes.id, id));
    
    return productType;
  }
  
  async createProductType(insertProductType: InsertProductType): Promise<ProductType> {
    const [productType] = await db
      .insert(productTypes)
      .values({
        ...insertProductType,
        createdAt: new Date()
      })
      .returning();
    
    // Create activity for the new product type
    await this.createActivity({
      type: "product_type_created",
      description: `New product type created: ${productType.name}`,
      details: { 
        productTypeName: productType.name,
        category: productType.category
      },
      timestamp: new Date(),
      relatedType: "product_type"
    });
    
    // Broadcast product type creation event
    broadcastUpdate("product_type_created", productType);
    
    return productType;
  }
  
  async updateProductType(id: number, productTypeUpdate: Partial<ProductType>): Promise<ProductType | undefined> {
    const [updated] = await db
      .update(productTypes)
      .set(productTypeUpdate)
      .where(eq(productTypes.id, id))
      .returning();
    
    if (updated) {
      // Broadcast product type update event
      broadcastUpdate("product_type_updated", updated);
    }
    
    return updated;
  }
  
  async deleteProductType(id: number): Promise<boolean> {
    // Check if this product type exists
    const [productType] = await db
      .select()
      .from(productTypes)
      .where(eq(productTypes.id, id));
    
    if (!productType) return false;
    
    try {
      await db
        .delete(productTypes)
        .where(eq(productTypes.id, id));
      
      // Broadcast product type deletion event
      broadcastUpdate("product_type_deleted", { 
        productTypeId: id, 
        name: productType.name,
        category: productType.category
      });
      
      return true;
    } catch (error) {
      console.error("Error deleting product type:", error);
      return false;
    }
  }
}