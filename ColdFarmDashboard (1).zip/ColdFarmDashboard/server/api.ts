import { Express } from 'express';
import { storage } from './storage';
import { sendMessageToFarmer, broadcastMessage, getConnectedClientCount, getAuthenticatedFarmerCount } from './utils/websocket';
import { registerAPIs as registerMobileAPIs } from './api/index';
import registerMobileFarmerAPI from './api/mobile-farmer-api';
import registerCategoriesAPI from './api/categories-api';
import registerVerificationAdminAPI from './api/verification-admin-api';
import consumerAuthRouter from './api/consumer-auth-api';
import marketplaceRouter from './api/marketplace-api';
import cartRouter from './api/cart-api';
import orderRouter from './api/order-api';
import deliveryRouter from './api/delivery-api';

export function registerAPIs(app: Express) {
  // Register all mobile API endpoints in their dedicated files
  registerMobileAPIs(app);
  
  // Register mobile farmer API endpoints
  registerMobileFarmerAPI(app);
  
  // Register categories API endpoints
  registerCategoriesAPI(app);
  
  // Register verification admin API endpoints
  registerVerificationAdminAPI(app);
  
  // Register marketplace mobile app API endpoints
  app.use('/api/mobile/consumer', consumerAuthRouter);
  app.use('/api/mobile/marketplace', marketplaceRouter);
  app.use('/api/mobile/cart', cartRouter);
  app.use('/api/mobile/orders', orderRouter);
  app.use('/api/mobile/delivery', deliveryRouter);
  
  // WebSocket testing and utility endpoints
  
  // Send message to specific farmer
  app.post("/api/ws/send-to-farmer", async (req, res) => {
    try {
      const { farmerId, message } = req.body;
      
      if (!farmerId || !message) {
        return res.status(400).json({ message: "farmerId and message are required" });
      }
      
      const sent = sendMessageToFarmer(Number(farmerId), {
        type: "notification",
        content: message,
        timestamp: new Date()
      });
      
      if (sent) {
        res.json({ message: "Message sent successfully" });
      } else {
        res.status(404).json({ message: "Farmer not connected or not found" });
      }
    } catch (error) {
      console.error("Error sending WebSocket message:", error);
      res.status(500).json({ message: "Error sending message" });
    }
  });
  
  // Broadcast message to all connected clients
  app.post("/api/ws/broadcast", async (req, res) => {
    try {
      const { message } = req.body;
      
      if (!message) {
        return res.status(400).json({ message: "message is required" });
      }
      
      const count = broadcastMessage({
        type: "broadcast",
        content: message,
        timestamp: new Date()
      });
      
      res.json({ message: `Broadcast sent to ${count} clients` });
    } catch (error) {
      console.error("Error broadcasting WebSocket message:", error);
      res.status(500).json({ message: "Error broadcasting message" });
    }
  });
  
  // Get WebSocket connection status
  app.get("/api/ws/status", async (req, res) => {
    try {
      const totalConnections = getConnectedClientCount();
      const authenticatedFarmers = getAuthenticatedFarmerCount();
      
      res.json({
        totalConnections,
        authenticatedFarmers,
        timestamp: new Date()
      });
    } catch (error) {
      console.error("Error getting WebSocket status:", error);
      res.status(500).json({ message: "Error getting WebSocket status" });
    }
  });
}