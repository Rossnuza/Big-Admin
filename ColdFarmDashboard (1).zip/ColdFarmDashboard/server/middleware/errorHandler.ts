/**
 * Global error handling middleware
 */
import { Request, Response, NextFunction } from 'express';
import { ZodError } from 'zod';
import { sendError } from '../utils/apiResponse';
import logger from '../utils/logger';

// Custom error class for API errors
export class ApiError extends Error {
  statusCode: number;
  code?: string;
  details?: any;

  constructor(message: string, statusCode = 500, code?: string, details?: any) {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
    this.name = 'ApiError';
  }
}

// Global error handling middleware
export function errorHandler(
  err: Error,
  req: Request,
  res: Response,
  _next: NextFunction
) {
  // Log the error
  import('../utils/logger').then(logger => {
    logger.error(`${req.method} ${req.path} - Error:`, err);
  });

  // Handle different types of errors
  if (err instanceof ApiError) {
    // Our custom API errors
    return sendError(
      res,
      err.message,
      err.statusCode,
      err.code,
      err.details
    );
  }

  if (err instanceof ZodError) {
    // Validation errors from Zod
    return sendError(
      res,
      'Validation error',
      400,
      'VALIDATION_ERROR',
      err.errors
    );
  }

  // Default error handling
  const statusCode = 'statusCode' in err ? (err as any).statusCode : 500;
  const message = err.message || 'Internal Server Error';
  
  sendError(
    res,
    message,
    statusCode,
    'statusCode' in err ? (err as any).code : 'INTERNAL_SERVER_ERROR'
  );
}

export default errorHandler;