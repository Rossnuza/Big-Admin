import { WebSocket } from 'ws';

/**
 * Send a message to a specific farmer via WebSocket
 * @param farmerId The ID of the farmer to send the message to
 * @param message The message to send (will be converted to JSON)
 * @returns True if message was sent to at least one client, false otherwise
 */
export function sendMessageToFarmer(farmerId: number, message: any): boolean {
  if (!(global as any).wss) {
    console.error('WebSocket server not initialized');
    return false;
  }

  const wss = (global as any).wss;
  let messageSent = false;

  wss.clients.forEach((client: WebSocket) => {
    if (client.readyState === WebSocket.OPEN && (client as any).farmerId === farmerId) {
      client.send(JSON.stringify(message));
      messageSent = true;
    }
  });

  return messageSent;
}

/**
 * Send a message to all connected WebSocket clients
 * @param message The message to send (will be converted to JSON)
 * @returns The number of clients the message was sent to
 */
export function broadcastMessage(message: any): number {
  if (!(global as any).wss) {
    console.error('WebSocket server not initialized');
    return 0;
  }

  const wss = (global as any).wss;
  let count = 0;

  wss.clients.forEach((client: WebSocket) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(message));
      count++;
    }
  });

  return count;
}

/**
 * Get the count of connected WebSocket clients
 * @returns The number of clients connected
 */
export function getConnectedClientCount(): number {
  if (!(global as any).wss) {
    return 0;
  }

  return (global as any).wss.clients.size;
}

/**
 * Get the count of authenticated farmers
 * @returns The number of authenticated farmers
 */
export function getAuthenticatedFarmerCount(): number {
  if (!(global as any).wss) {
    return 0;
  }

  const wss = (global as any).wss;
  const farmerIds = new Set();

  wss.clients.forEach((client: WebSocket) => {
    if (client.readyState === WebSocket.OPEN && (client as any).farmerId) {
      farmerIds.add((client as any).farmerId);
    }
  });

  return farmerIds.size;
}

/**
 * Helper function to broadcast changes with targeted delivery
 * @param type The type of update (farmer_*, admin_*, or other for broadcast)
 * @param data The data to send
 */
export function broadcastUpdate(type: string, data: any) {
  console.log(`🔴 Broadcasting: ${type}`, JSON.stringify(data));
  
  const wss = (global as any).wss;
  if (!wss) return;
  
  const message = JSON.stringify({
    type,
    data,
    timestamp: new Date().toISOString()
  });
  
  wss.clients.forEach((client: any) => {
    // Send to specific farmer or to admin
    if (type.startsWith("farmer_") && client.farmerId === data.farmerId) {
      client.send(message);
    } else if (type.startsWith("admin_")) {
      // Send admin updates to admins
      if (!client.farmerId) {
        client.send(message);
      }
    } else {
      // Broadcast to everyone
      client.send(message);
    }
  });
  
  console.log(`Broadcasted ${type} update`);
}