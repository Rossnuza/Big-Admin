import { Vonage } from "@vonage/server-sdk";

// Initialize Vonage client with your API credentials
const vonageApiKey = process.env.VONAGE_API_KEY;
const vonageApiSecret = process.env.VONAGE_API_SECRET;

// Check if the required environment variables are set
if (!vonageApiKey || !vonageApiSecret) {
  console.warn("Vonage API credentials are missing. SMS functionality will not work properly.");
}

// Create Vonage client instance if credentials are available
const vonage = vonageApiKey && vonageApiSecret 
  ? new Vonage({ apiKey: vonageApiKey, apiSecret: vonageApiSecret })
  : null;

/**
 * Generate a random numeric verification code
 * @param length Length of the verification code (default: 6)
 * @returns A random numeric code
 */
export function generateVerificationCode(length = 6): string {
  let code = '';
  for (let i = 0; i < length; i++) {
    code += Math.floor(Math.random() * 10).toString();
  }
  return code;
}

/**
 * Send an SMS message
 * @param to Recipient phone number (international format, e.g., +14155550100)
 * @param text Message text
 * @returns Promise that resolves when the message is sent
 */
export async function sendSMS(to: string, text: string): Promise<any> {
  // Clean the phone number - ensure it starts with +
  const formattedNumber = to.startsWith('+') ? to : `+${to}`;
  
  // Check if Vonage client is available
  if (!vonage) {
    // In development, just log the message
    if (process.env.NODE_ENV === 'development') {
      console.log(`[DEVELOPMENT SMS] To: ${formattedNumber}, Message: ${text}`);
      return Promise.resolve({ 
        simulated: true, 
        to: formattedNumber, 
        message: text 
      });
    } else {
      throw new Error("Vonage API credentials are not configured");
    }
  }

  // Send SMS using Vonage API
  return new Promise((resolve, reject) => {
    vonage.sms.send({
      from: "Coldfarms",  // This can be configured based on your Vonage account
      to: formattedNumber,
      text: text
    })
    .then(response => {
      const { messages } = response;
      
      if (messages && messages.length > 0) {
        if (messages[0].status === '0') {
          console.log(`Message sent successfully to ${formattedNumber}`);
          resolve(response);
        } else {
          console.error(`Message failed with error: ${messages[0]['error-text']}`);
          reject(new Error(`Failed to send SMS: ${messages[0]['error-text']}`));
        }
      } else {
        console.error('Unknown error occurred while sending SMS');
        reject(new Error('Unknown error occurred while sending SMS'));
      }
    })
    .catch(err => {
      console.error('Error sending SMS:', err);
      reject(err);
    });
  });
}

/**
 * Verify a phone number using Vonage Verify API
 * Note: This is a placeholder for a more complete implementation
 * that would include handling verify check as well
 */
export async function startVerification(phoneNumber: string): Promise<any> {
  if (!vonage) {
    if (process.env.NODE_ENV === 'development') {
      const code = generateVerificationCode();
      console.log(`[DEVELOPMENT VERIFY] To: ${phoneNumber}, Code: ${code}`);
      return Promise.resolve({ 
        simulated: true, 
        to: phoneNumber, 
        verificationCode: code 
      });
    } else {
      throw new Error("Vonage API credentials are not configured");
    }
  }
  
  // This is a placeholder - in a real implementation, you'd use Vonage's Verify API
  // This would require additional setup in your Vonage account
  return Promise.resolve({
    message: "Verification not implemented in this version"
  });
}