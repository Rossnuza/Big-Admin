/**
 * Logger utility for standardized logging across the application
 */

// Define log levels
type LogLevel = 'debug' | 'info' | 'warn' | 'error';

// Custom log function to standardize logs with timestamps and formatting
export function logger(level: LogLevel, message: string, meta?: any) {
  const timestamp = new Date().toISOString();
  let formattedMessage = `[${timestamp}] [${level.toUpperCase()}] ${message}`;
  
  // Only include stack trace for errors in development
  if (meta) {
    if (level === 'error' && meta.stack && process.env.NODE_ENV !== 'production') {
      formattedMessage += `\n${meta.stack}`;
    } else {
      // Stringify non-error metadata (trims long outputs)
      const metaString = JSON.stringify(meta);
      if (metaString.length > 200) {
        formattedMessage += ` ${metaString.substring(0, 197)}...`;
      } else {
        formattedMessage += ` ${metaString}`;
      }
    }
  }
  
  // Select appropriate console method based on level
  switch (level) {
    case 'debug':
      if (process.env.NODE_ENV !== 'production') {
        console.debug(formattedMessage);
      }
      break;
    case 'info':
      console.info(formattedMessage);
      break;
    case 'warn':
      console.warn(formattedMessage);
      break;
    case 'error':
      console.error(formattedMessage);
      break;
  }
}

// Shorthand methods
export const debug = (message: string, meta?: any) => logger('debug', message, meta);
export const info = (message: string, meta?: any) => logger('info', message, meta);
export const warn = (message: string, meta?: any) => logger('warn', message, meta);
export const error = (message: string, meta?: any) => logger('error', message, meta);

export default {
  debug,
  info,
  warn,
  error
};