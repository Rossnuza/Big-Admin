/**
 * Standardized API response format utility
 */
import { Response } from 'express';

/**
 * Interface for standardized success responses
 */
interface SuccessResponse<T> {
  success: true;
  data: T;
  message?: string;
}

/**
 * Interface for standardized error responses
 */
interface ErrorResponse {
  success: false;
  error: {
    message: string;
    code?: string;
    details?: any;
  };
}

/**
 * Generic API response type
 */
export type ApiResponse<T> = SuccessResponse<T> | ErrorResponse;

/**
 * Send a success response
 * 
 * @param res Express response object
 * @param data The data to send
 * @param message Optional success message
 * @param statusCode HTTP status code (default: 200)
 */
export function sendSuccess<T>(
  res: Response,
  data: T,
  message?: string,
  statusCode = 200
): void {
  const response: SuccessResponse<T> = {
    success: true,
    data,
    ...(message && { message }),
  };
  
  res.status(statusCode).json(response);
}

/**
 * Send an error response
 * 
 * @param res Express response object
 * @param message Error message
 * @param statusCode HTTP status code (default: 500)
 * @param code Optional error code
 * @param details Optional error details
 */
export function sendError(
  res: Response,
  message: string,
  statusCode = 500,
  code?: string,
  details?: any
): void {
  const response: ErrorResponse = {
    success: false,
    error: {
      message,
      ...(code && { code }),
      ...(details && { details }),
    },
  };
  
  res.status(statusCode).json(response);
}

export default {
  sendSuccess,
  sendError,
};