import { Request, Response, Router } from "express";
import { storage } from "../storage";

const router = Router();

// Get all marketplace products (only listed and available products)
router.get("/products", async (req: Request, res: Response) => {
  try {
    const products = await storage.getMarketplaceProducts();
    
    // Map to include category info with each product
    const enhancedProducts = await Promise.all(products.map(async (product) => {
      const farmer = await storage.getFarmer(product.farmerId);
      return {
        ...product,
        farmerName: farmer?.name || 'Unknown'
      };
    }));
    
    return res.status(200).json(enhancedProducts);
  } catch (error) {
    console.error("Get marketplace products error:", error);
    return res.status(500).json({ error: "Failed to retrieve marketplace products" });
  }
});

// Get products by category
router.get("/products/category/:categoryName", async (req: Request, res: Response) => {
  try {
    const { categoryName } = req.params;
    
    // First get the category
    const category = await storage.getCategoryByName(categoryName);
    
    if (!category) {
      return res.status(404).json({ error: "Category not found" });
    }
    
    // Get product types in this category
    const productTypes = await storage.getProductTypesByCategory(categoryName);
    
    // Get all marketplace products
    const allProducts = await storage.getMarketplaceProducts();
    
    // Filter products that match the category's product types
    const productTypeNames = productTypes.map(pt => pt.name);
    const categoryProducts = allProducts.filter(product => 
      productTypeNames.includes(product.productType)
    );
    
    // Enhance with farmer info
    const enhancedProducts = await Promise.all(categoryProducts.map(async (product) => {
      const farmer = await storage.getFarmer(product.farmerId);
      return {
        ...product,
        farmerName: farmer?.name || 'Unknown'
      };
    }));
    
    return res.status(200).json(enhancedProducts);
  } catch (error) {
    console.error("Get products by category error:", error);
    return res.status(500).json({ error: "Failed to retrieve products by category" });
  }
});

// Get all categories with product counts
router.get("/categories", async (req: Request, res: Response) => {
  try {
    const categories = await storage.getCategories();
    
    // Get counts of marketplace products in each category
    const categoriesWithCounts = await Promise.all(categories.map(async (category) => {
      // Get product types in this category
      const productTypes = await storage.getProductTypesByCategory(category.name);
      const productTypeNames = productTypes.map(pt => pt.name);
      
      // Get all marketplace products
      const allProducts = await storage.getMarketplaceProducts();
      
      // Count products matching this category's product types
      const marketplaceProductCount = allProducts.filter(product => 
        productTypeNames.includes(product.productType)
      ).length;
      
      return {
        ...category,
        marketplaceProductCount
      };
    }));
    
    return res.status(200).json(categoriesWithCounts);
  } catch (error) {
    console.error("Get categories error:", error);
    return res.status(500).json({ error: "Failed to retrieve categories" });
  }
});

// Get product details by ID
router.get("/products/:id", async (req: Request, res: Response) => {
  try {
    const productId = parseInt(req.params.id);
    
    if (isNaN(productId)) {
      return res.status(400).json({ error: "Invalid product ID" });
    }
    
    const product = await storage.getProduct(productId);
    
    if (!product) {
      return res.status(404).json({ error: "Product not found" });
    }
    
    // Check if product is listed on marketplace
    if (!product.isListed || product.quantityAvailable <= 0) {
      return res.status(404).json({ error: "Product not available in the marketplace" });
    }
    
    // Get farmer info
    const farmer = await storage.getFarmer(product.farmerId);
    
    // Get product type info
    const productTypes = await storage.getProductTypes();
    const productType = productTypes.find(pt => pt.name === product.productType);
    
    // Get category name from product type
    const categoryName = productType?.category || null;
    
    // Return enhanced product details
    return res.status(200).json({
      ...product,
      farmerName: farmer?.name || 'Unknown',
      farmerRegion: farmer?.region || null,
      category: categoryName,
      unit: productType?.standardUnit || 'kg'
    });
  } catch (error) {
    console.error("Get product details error:", error);
    return res.status(500).json({ error: "Failed to retrieve product details" });
  }
});

// Search products
router.get("/products/search/:query", async (req: Request, res: Response) => {
  try {
    const { query } = req.params;
    
    // Get all marketplace products
    const allProducts = await storage.getMarketplaceProducts();
    
    // Filter products by name or description containing the query (case insensitive)
    const searchResults = allProducts.filter(product => {
      const searchLower = query.toLowerCase();
      const nameLower = product.name.toLowerCase();
      const descriptionLower = product.description ? product.description.toLowerCase() : '';
      const productTypeLower = product.productType.toLowerCase();
      
      return nameLower.includes(searchLower) || 
             descriptionLower.includes(searchLower) ||
             productTypeLower.includes(searchLower);
    });
    
    // Enhance with farmer info
    const enhancedResults = await Promise.all(searchResults.map(async (product) => {
      const farmer = await storage.getFarmer(product.farmerId);
      return {
        ...product,
        farmerName: farmer?.name || 'Unknown'
      };
    }));
    
    return res.status(200).json(enhancedResults);
  } catch (error) {
    console.error("Search products error:", error);
    return res.status(500).json({ error: "Failed to search products" });
  }
});

// Get featured products (sample implementation - can be customized)
router.get("/featured", async (req: Request, res: Response) => {
  try {
    // Get all marketplace products
    const allProducts = await storage.getMarketplaceProducts();
    
    // Limit to 4 featured products (can implement a featured flag in future)
    const featuredProducts = allProducts.slice(0, 4);
    
    // Enhance with farmer info
    const enhancedProducts = await Promise.all(featuredProducts.map(async (product) => {
      const farmer = await storage.getFarmer(product.farmerId);
      return {
        ...product,
        farmerName: farmer?.name || 'Unknown'
      };
    }));
    
    return res.status(200).json(enhancedProducts);
  } catch (error) {
    console.error("Get featured products error:", error);
    return res.status(500).json({ error: "Failed to retrieve featured products" });
  }
});

export default router;