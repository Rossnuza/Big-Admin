import { Request, Response, Router } from "express";
import { storage } from "../storage";
import { z } from "zod";

const router = Router();

// Get delivery settings
router.get("/settings", async (req: Request, res: Response) => {
  try {
    const deliverySettings = await storage.getDeliverySettings();
    
    if (!deliverySettings) {
      return res.status(404).json({ error: "Delivery settings not found" });
    }
    
    return res.status(200).json(deliverySettings);
  } catch (error) {
    console.error("Get delivery settings error:", error);
    return res.status(500).json({ error: "Failed to retrieve delivery settings" });
  }
});

// Calculate delivery fee
router.post("/calculate-fee", async (req: Request, res: Response) => {
  try {
    // Validate request body
    const calculateSchema = z.object({
      deliveryDistance: z.number().nonnegative(),
      orderSubtotal: z.number().nonnegative()
    });
    
    const validatedData = calculateSchema.parse(req.body);
    
    // Get delivery settings
    const deliverySettings = await storage.getDeliverySettings();
    
    if (!deliverySettings) {
      return res.status(404).json({ error: "Delivery settings not found" });
    }
    
    // Check if distance is within delivery radius
    if (validatedData.deliveryDistance > deliverySettings.maximumDeliveryRadius) {
      return res.status(400).json({
        error: "Delivery distance exceeds maximum radius",
        maximumRadius: deliverySettings.maximumDeliveryRadius
      });
    }
    
    // Check if order meets minimum amount
    if (validatedData.orderSubtotal < deliverySettings.minimumOrderAmount) {
      return res.status(400).json({
        error: "Order does not meet minimum amount",
        minimumOrderAmount: deliverySettings.minimumOrderAmount,
        currentOrderAmount: validatedData.orderSubtotal
      });
    }
    
    // Calculate delivery fee
    const distanceFee = validatedData.deliveryDistance * deliverySettings.perKilometerFee;
    const totalDeliveryFee = deliverySettings.baseDeliveryFee + distanceFee;
    
    return res.status(200).json({
      deliveryFee: totalDeliveryFee,
      baseDeliveryFee: deliverySettings.baseDeliveryFee,
      distanceFee,
      minimumOrderAmount: deliverySettings.minimumOrderAmount,
      maximumRadius: deliverySettings.maximumDeliveryRadius
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors });
    }
    console.error("Calculate delivery fee error:", error);
    return res.status(500).json({ error: "Failed to calculate delivery fee" });
  }
});

// Estimate delivery time
router.post("/estimate-time", async (req: Request, res: Response) => {
  try {
    // Validate request body
    const estimateSchema = z.object({
      deliveryDistance: z.number().nonnegative()
    });
    
    const validatedData = estimateSchema.parse(req.body);
    
    // Get delivery settings
    const deliverySettings = await storage.getDeliverySettings();
    
    if (!deliverySettings) {
      return res.status(404).json({ error: "Delivery settings not found" });
    }
    
    // Check if distance is within delivery radius
    if (validatedData.deliveryDistance > deliverySettings.maximumDeliveryRadius) {
      return res.status(400).json({
        error: "Delivery distance exceeds maximum radius",
        maximumRadius: deliverySettings.maximumDeliveryRadius
      });
    }
    
    // Calculate estimated delivery time
    // Base time: 30 minutes + 5 minutes per kilometer
    const basePreparationTime = 30; // minutes
    const timePerKilometer = 5; // minutes
    
    const estimatedMinutes = basePreparationTime + (validatedData.deliveryDistance * timePerKilometer);
    
    // Return estimate in different formats
    const now = new Date();
    const estimatedDeliveryTime = new Date(now.getTime() + estimatedMinutes * 60000);
    
    return res.status(200).json({
      estimatedMinutes,
      estimatedDeliveryTime,
      currentTime: now,
      formattedEstimate: `${Math.floor(estimatedMinutes / 60)} hr ${estimatedMinutes % 60} min`
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors });
    }
    console.error("Estimate delivery time error:", error);
    return res.status(500).json({ error: "Failed to estimate delivery time" });
  }
});

export default router;