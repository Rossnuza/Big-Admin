import { Request, Response, Router } from "express";
import { storage } from "../storage";
import { z } from "zod";
import { InsertOrder, InsertOrderItem } from "@shared/schema";

const router = Router();

// Get orders for a consumer
router.get("/:consumerId", async (req: Request, res: Response) => {
  try {
    const consumerId = parseInt(req.params.consumerId);
    
    if (isNaN(consumerId)) {
      return res.status(400).json({ error: "Invalid consumer ID" });
    }
    
    // Check if consumer exists
    const consumer = await storage.getConsumer(consumerId);
    if (!consumer) {
      return res.status(404).json({ error: "Consumer not found" });
    }
    
    // Get orders for this consumer
    const orders = await storage.getOrdersByConsumer(consumerId);
    
    // Enhance orders with additional details
    const enhancedOrders = await Promise.all(orders.map(async (order) => {
      // Get order items
      const orderItems = await storage.getOrderItems(order.id);
      
      // Get total items count
      const totalItems = orderItems.reduce((sum, item) => sum + item.quantity, 0);
      
      return {
        ...order,
        itemCount: orderItems.length,
        totalItems,
        orderDate: order.createdAt
      };
    }));
    
    return res.status(200).json(enhancedOrders);
  } catch (error) {
    console.error("Get orders error:", error);
    return res.status(500).json({ error: "Failed to retrieve orders" });
  }
});

// Get order details
router.get("/details/:orderId", async (req: Request, res: Response) => {
  try {
    const orderId = parseInt(req.params.orderId);
    
    if (isNaN(orderId)) {
      return res.status(400).json({ error: "Invalid order ID" });
    }
    
    // Get order
    const order = await storage.getOrder(orderId);
    if (!order) {
      return res.status(404).json({ error: "Order not found" });
    }
    
    // Get order items
    const orderItems = await storage.getOrderItems(orderId);
    
    // Enhance order items with product details
    const enhancedOrderItems = await Promise.all(orderItems.map(async (item) => {
      const product = await storage.getProduct(item.productId);
      
      // Get product type for unit information
      const productTypes = await storage.getProductTypes();
      const productType = productTypes.find(pt => pt.name === product?.productType);
      
      return {
        ...item,
        productDetails: product ? {
          name: product.name,
          price: product.price,
          image: product.image,
          unit: productType?.standardUnit || 'kg'
        } : null
      };
    }));
    
    // Get consumer details
    const consumer = await storage.getConsumer(order.consumerId);
    
    // Calculate order totals
    const subtotal = orderItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
    
    return res.status(200).json({
      order: {
        ...order,
        consumer: consumer ? {
          name: consumer.name,
          phone: consumer.phone,
          address: consumer.address,
          location: consumer.location
        } : null,
        items: enhancedOrderItems,
        subtotal,
        total: subtotal + order.deliveryFee,
        itemCount: orderItems.length
      }
    });
  } catch (error) {
    console.error("Get order details error:", error);
    return res.status(500).json({ error: "Failed to retrieve order details" });
  }
});

// Schema for creating a new order
const createOrderSchema = z.object({
  consumerId: z.number().int().positive(),
  deliveryAddress: z.string().min(1, "Delivery address is required"),
  deliveryLocation: z.any().optional(),
  paymentMethod: z.string().min(1, "Payment method is required"),
  notes: z.string().optional().nullable()
});

// Create a new order
router.post("/create", async (req: Request, res: Response) => {
  try {
    // Validate request body
    const validatedData = createOrderSchema.parse(req.body);
    
    // Check if consumer exists
    const consumer = await storage.getConsumer(validatedData.consumerId);
    if (!consumer) {
      return res.status(404).json({ error: "Consumer not found" });
    }
    
    // Get cart items
    const cartItems = await storage.getCartItems(validatedData.consumerId);
    if (cartItems.length === 0) {
      return res.status(400).json({ error: "Cart is empty" });
    }
    
    // Calculate order subtotal and check product availability
    let subtotal = 0;
    const unavailableProducts = [];
    
    for (const item of cartItems) {
      const product = await storage.getProduct(item.productId);
      
      if (!product) {
        unavailableProducts.push({ cartItemId: item.id, reason: "Product not found" });
        continue;
      }
      
      if (!product.isListed || product.quantityAvailable <= 0) {
        unavailableProducts.push({ 
          cartItemId: item.id, 
          productName: product.name, 
          reason: "Product is no longer available" 
        });
        continue;
      }
      
      if (item.quantity > product.quantityAvailable) {
        unavailableProducts.push({ 
          cartItemId: item.id, 
          productName: product.name, 
          reason: "Requested quantity exceeds available quantity",
          requested: item.quantity,
          available: product.quantityAvailable
        });
        continue;
      }
      
      subtotal += product.price * item.quantity;
    }
    
    // If there are unavailable products, return error
    if (unavailableProducts.length > 0) {
      return res.status(400).json({ 
        error: "Some products in your cart are no longer available",
        unavailableProducts
      });
    }
    
    // Get delivery settings
    const deliverySettings = await storage.getDeliverySettings();
    
    // Check minimum order amount
    if (subtotal < (deliverySettings?.minimumOrderAmount || 0)) {
      return res.status(400).json({ 
        error: "Order subtotal does not meet minimum order amount",
        currentSubtotal: subtotal,
        minimumOrderAmount: deliverySettings?.minimumOrderAmount || 0
      });
    }
    
    // Calculate delivery fee (simplified)
    const deliveryFee = deliverySettings?.baseDeliveryFee || 0;
    
    // Create order
    const order = await storage.createOrder({
      consumerId: validatedData.consumerId,
      status: "pending",
      paymentStatus: "pending",
      paymentMethod: validatedData.paymentMethod,
      deliveryAddress: validatedData.deliveryAddress,
      deliveryLocation: validatedData.deliveryLocation,
      deliveryFee,
      notes: validatedData.notes,
      createdAt: new Date()
    });
    
    // Create order items from cart items
    for (const item of cartItems) {
      const product = await storage.getProduct(item.productId);
      
      if (product) {
        // Create order item
        await storage.createOrderItem({
          orderId: order.id,
          productId: item.productId,
          quantity: item.quantity,
          price: product.price,
          name: product.name
        });
        
        // Update product quantity
        await storage.updateProduct(product.id, {
          quantityAvailable: product.quantityAvailable - item.quantity
        });
      }
    }
    
    // Clear cart after order creation
    await storage.clearCart(validatedData.consumerId);
    
    // Create activity for order placed
    await storage.createActivity({
      type: "order_placed",
      description: `${consumer.name} placed a new order`,
      details: { 
        orderId: order.id,
        consumerId: validatedData.consumerId,
        totalAmount: subtotal + deliveryFee
      },
      timestamp: new Date(),
      relatedId: order.id,
      relatedType: "order"
    });
    
    return res.status(201).json({
      message: "Order created successfully",
      order: {
        ...order,
        subtotal,
        total: subtotal + deliveryFee
      }
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors });
    }
    console.error("Create order error:", error);
    return res.status(500).json({ error: "Failed to create order" });
  }
});

// Update order payment status
router.post("/:orderId/payment", async (req: Request, res: Response) => {
  try {
    const orderId = parseInt(req.params.orderId);
    
    if (isNaN(orderId)) {
      return res.status(400).json({ error: "Invalid order ID" });
    }
    
    // Validate request body
    const updateSchema = z.object({
      paymentStatus: z.enum(["pending", "paid", "failed", "refunded"]),
      transactionId: z.string().optional(),
      paymentDetails: z.any().optional()
    });
    
    const validatedData = updateSchema.parse(req.body);
    
    // Get order
    const order = await storage.getOrder(orderId);
    if (!order) {
      return res.status(404).json({ error: "Order not found" });
    }
    
    // Update order payment status
    const updatedOrder = await storage.updateOrderPaymentStatus(
      orderId, 
      validatedData.paymentStatus,
      validatedData.transactionId,
      validatedData.paymentDetails
    );
    
    // Create activity for payment status update
    await storage.createActivity({
      type: "payment_status_updated",
      description: `Order #${orderId} payment status updated to ${validatedData.paymentStatus}`,
      details: { 
        orderId,
        paymentStatus: validatedData.paymentStatus,
        transactionId: validatedData.transactionId
      },
      timestamp: new Date(),
      relatedId: orderId,
      relatedType: "order"
    });
    
    // If payment is completed and status was pending, update order status to processing
    if (validatedData.paymentStatus === "paid" && order.status === "pending") {
      await storage.updateOrderStatus(orderId, "processing");
    }
    
    return res.status(200).json({
      message: "Order payment status updated successfully",
      order: updatedOrder
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors });
    }
    console.error("Update order payment status error:", error);
    return res.status(500).json({ error: "Failed to update order payment status" });
  }
});

// Cancel order
router.post("/:orderId/cancel", async (req: Request, res: Response) => {
  try {
    const orderId = parseInt(req.params.orderId);
    
    if (isNaN(orderId)) {
      return res.status(400).json({ error: "Invalid order ID" });
    }
    
    // Get order
    const order = await storage.getOrder(orderId);
    if (!order) {
      return res.status(404).json({ error: "Order not found" });
    }
    
    // Check if order can be cancelled (only pending orders can be cancelled)
    if (order.status !== "pending") {
      return res.status(400).json({ 
        error: "Cannot cancel order",
        reason: "Only pending orders can be cancelled",
        currentStatus: order.status
      });
    }
    
    // Update order status to cancelled
    const updatedOrder = await storage.updateOrderStatus(orderId, "cancelled");
    
    // Get order items
    const orderItems = await storage.getOrderItems(orderId);
    
    // Restore product quantities
    for (const item of orderItems) {
      const product = await storage.getProduct(item.productId);
      
      if (product) {
        await storage.updateProduct(product.id, {
          quantityAvailable: product.quantityAvailable + item.quantity
        });
      }
    }
    
    // Create activity for order cancellation
    await storage.createActivity({
      type: "order_cancelled",
      description: `Order #${orderId} was cancelled`,
      details: { 
        orderId,
        consumerId: order.consumerId
      },
      timestamp: new Date(),
      relatedId: orderId,
      relatedType: "order"
    });
    
    return res.status(200).json({
      message: "Order cancelled successfully",
      order: updatedOrder
    });
  } catch (error) {
    console.error("Cancel order error:", error);
    return res.status(500).json({ error: "Failed to cancel order" });
  }
});

export default router;