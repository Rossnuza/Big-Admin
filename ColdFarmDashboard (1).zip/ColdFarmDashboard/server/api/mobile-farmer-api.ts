import { Express, Request, Response } from 'express';
import { storage } from '../storage';
import { broadcastMessage } from '../utils/websocket';
import * as logger from '../utils/logger';

export default function registerMobileFarmerAPI(app: Express) {
  // --------------------------------
  // Authentication & User Management
  // --------------------------------
  
  // Farmer self-registration
  app.post("/api/mobile/farmer/register", async (req: Request, res: Response) => {
    try {
      const { name, phone, email, region, contactPerson } = req.body;
      
      // Input validation
      if (!name || !phone || !region) {
        return res.status(400).json({ message: "Name, phone, and region are required" });
      }
      
      // Check if farmer with this phone already exists
      const existingFarmer = await storage.getFarmerByPhone(phone);
      
      if (existingFarmer) {
        return res.status(409).json({ message: "A farmer with this phone number already exists" });
      }
      
      // Create new farmer record
      const newFarmer = await storage.createFarmer({
        name,
        phone,
        email: email || '',
        region,
        contactPerson: contactPerson || name,
        joinDate: new Date(),
        registrationType: "self",
        verificationStatus: "pending",
        temporaryPasscode: "1234", // Use a fixed code for MVP
        marketplaceOptIn: false,
        storageAgreement: false,
        lastLogin: undefined
      });
      
      // Create activity log
      await storage.createActivity({
        type: "farmer_self_registered",
        description: "New farmer registered through mobile app",
        details: { farmerName: name, phone },
        timestamp: new Date(),
        relatedId: newFarmer.id,
        relatedType: "farmer"
      });
      
      // Broadcast registration event to admin panel
      broadcastMessage({
        type: "farmer_registered",
        farmerId: newFarmer.id,
        farmerName: newFarmer.name,
        farmerPhone: newFarmer.phone,
        farmerRegion: newFarmer.region,
        timestamp: new Date()
      });
      
      // Return limited farmer info (security best practice)
      res.status(201).json({ 
        message: "Registration successful. Your account is pending approval.",
        user: {
          id: newFarmer.id,
          name: newFarmer.name,
          phone: newFarmer.phone,
          region: newFarmer.region,
          verificationStatus: newFarmer.verificationStatus
        }
      });
      
    } catch (error) {
      console.error("Farmer registration error:", error);
      res.status(500).json({ message: "Registration failed" });
    }
  });

  // Send verification code endpoint
  app.post('/api/mobile/farmer/send-code', async (req: Request, res: Response) => {
    try {
      const { phone } = req.body;
      
      if (!phone) {
        return res.status(400).json({ message: "Phone number is required" });
      }
      
      // Check if farmer exists
      const farmer = await storage.getFarmerByPhone(phone);
      if (!farmer) {
        return res.status(404).json({ message: "Farmer not found" });
      }
      
      // Use Vonage service to send verification code
      const { VonageService } = await import('../utils/vonage-service');
      
      const result = await VonageService.sendVerificationCode(phone, farmer.id);
      
      if (!result.success) {
        return res.status(500).json({ 
          message: "Failed to send verification code", 
          error: result.message 
        });
      }
      
      // Store request ID in temporary passcode field for verification
      await storage.updateFarmerVerification(
        farmer.id, 
        farmer.verificationStatus,
        result.requestId
      );
      
      res.json({ 
        message: "Verification code sent",
        requestId: result.requestId
      });
    } catch (error) {
      console.error("Error sending code:", error);
      res.status(500).json({ message: "Error sending verification code" });
    }
  });

  // Verify phone number exists before login attempt
  app.post('/api/mobile/farmer/check-phone', async (req: Request, res: Response) => {
    try {
      const { phone } = req.body;
      
      if (!phone) {
        return res.status(400).json({ message: "Phone number is required" });
      }
      
      // Check if farmer exists
      const farmer = await storage.getFarmerByPhone(phone);
      if (!farmer) {
        return res.status(404).json({ message: "Farmer not found" });
      }
      
      // Return success without exposing sensitive farmer data
      res.json({ 
        exists: true, 
        verificationStatus: farmer.verificationStatus 
      });
      
    } catch (error) {
      console.error("Error checking phone:", error);
      res.status(500).json({ message: "Error checking phone number" });
    }
  });

  // Farmer login with verification code
  app.post("/api/mobile/farmer/login", async (req: Request, res: Response) => {
    try {
      const { phone, passcode, requestId } = req.body;
      
      if (!phone || !passcode) {
        return res.status(400).json({ message: "Phone number and passcode are required" });
      }
      
      // Find farmer by phone
      const farmer = await storage.getFarmerByPhone(phone);
      
      if (!farmer) {
        return res.status(404).json({ message: "Farmer not found" });
      }
      
      // Check if we need to validate with Vonage or if we're in development mode
      let isCodeValid = false;
      
      // Development fallback for testing without Vonage
      if (process.env.NODE_ENV === 'development' && passcode === "1234") {
        isCodeValid = true;
      } 
      // Production verification using Vonage
      else if (requestId) {
        // Verify the code with Vonage
        const { VonageService } = await import('../utils/vonage-service');
        const verifyResult = await VonageService.verifyCode(requestId, passcode);
        isCodeValid = verifyResult.success;
        
        if (!isCodeValid) {
          return res.status(401).json({ 
            message: "Invalid verification code", 
            error: verifyResult.message 
          });
        }
      } 
      // Using temporary passcode (stored in farmer record)
      else if (farmer.temporaryPasscode === passcode) {
        isCodeValid = true;
      }
      else {
        return res.status(401).json({ message: "Invalid verification code" });
      }
      
      // Check verification status
      if (farmer.verificationStatus !== "verified") {
        return res.status(403).json({ 
          message: "Your account is pending approval by an administrator",
          verificationStatus: farmer.verificationStatus
        });
      }
      
      // Update last login time
      await storage.updateFarmerLastLogin(farmer.id);
      
      // Broadcast login event to admin panel
      broadcastMessage({
        type: "farmer_login",
        farmerId: farmer.id,
        farmerName: farmer.name,
        timestamp: new Date()
      });
      
      // Return limited farmer info (security best practice)
      res.json({ 
        message: "Login successful", 
        farmer: {
          id: farmer.id,
          name: farmer.name,
          phone: farmer.phone,
          region: farmer.region,
          email: farmer.email || "",
          verificationStatus: farmer.verificationStatus,
          marketplaceOptIn: farmer.marketplaceOptIn,
          storageAgreement: farmer.storageAgreement
        }
      });
      
    } catch (error) {
      console.error("Farmer login error:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  // --------------------------------
  // Content & Data Endpoints
  // --------------------------------
  
  // Get all categories for mobile app
  app.get('/api/mobile/farmer/categories', async (req: Request, res: Response) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Error fetching categories" });
    }
  });

  // Get product types by category for mobile app
  app.get('/api/mobile/farmer/product-types-by-category/:categoryName', async (req: Request, res: Response) => {
    try {
      const categoryName = req.params.categoryName;
      if (!categoryName) {
        return res.status(400).json({ message: "Category name is required" });
      }
      
      const productTypes = await storage.getProductTypesByCategory(categoryName);
      
      if (productTypes.length === 0) {
        console.log(`No product types found for category: ${categoryName}`);
      }
      
      res.json(productTypes);
    } catch (error) {
      console.error(`Error fetching product types for category ${req.params.categoryName}:`, error);
      res.status(500).json({ message: "Error fetching product types" });
    }
  });

  // Get all product types for mobile app
  app.get('/api/mobile/farmer/product-types', async (req: Request, res: Response) => {
    try {
      const productTypes = await storage.getProductTypes();
      res.json(productTypes);
    } catch (error) {
      console.error("Error fetching product types:", error);
      res.status(500).json({ message: "Error fetching product types" });
    }
  });
}