import { Request, Response, Router } from "express";
import { storage } from "../storage";
import { InsertConsumer } from "@shared/schema";
import { z } from "zod";
import { generateVerificationCode, sendSMS } from "../utils/vonage-service";

const router = Router();

// Schema for consumer registration
const registerConsumerSchema = z.object({
  name: z.string().min(1, "Name is required"),
  phone: z.string().min(7, "Valid phone number is required"),
  email: z.string().email().optional().nullable(),
  address: z.string().optional().nullable(),
  location: z.any().optional().nullable()
});

// Schema for verification
const verifyConsumerSchema = z.object({
  phone: z.string().min(7, "Valid phone number is required"),
  passcode: z.string().min(4, "Passcode is required")
});

// Schema for login
const loginConsumerSchema = z.object({
  phone: z.string().min(7, "Valid phone number is required"),
  passcode: z.string().min(4, "Passcode is required")
});

// Register a new consumer and send verification code
router.post("/register", async (req: Request, res: Response) => {
  try {
    // Validate request body
    const validatedData = registerConsumerSchema.parse(req.body);
    
    // Check if consumer already exists with this phone
    const existingConsumer = await storage.getConsumerByPhone(validatedData.phone);
    
    if (existingConsumer) {
      return res.status(400).json({ error: "Phone number already registered" });
    }
    
    // Generate verification code
    const verificationCode = generateVerificationCode();
    
    // Create a new consumer
    const newConsumer = await storage.createConsumer({
      ...validatedData,
      temporaryPasscode: verificationCode,
      verificationStatus: "pending",
      registrationDate: new Date()
    });
    
    // Send SMS with verification code
    try {
      await sendSMS(
        validatedData.phone,
        `Your Coldfarms Market verification code is: ${verificationCode}`
      );
      
      // Create activity log
      await storage.createActivity({
        type: "consumer_registered",
        description: `New consumer registered: ${newConsumer.name}`,
        details: { 
          consumerId: newConsumer.id,
          phone: newConsumer.phone
        },
        timestamp: new Date(),
        relatedId: newConsumer.id,
        relatedType: "consumer"
      });
      
      // Return success response (don't expose the verification code)
      return res.status(201).json({
        message: "Registration successful, verification code sent",
        consumerId: newConsumer.id,
        name: newConsumer.name
      });
    } catch (error) {
      console.error("SMS sending error:", error);
      return res.status(500).json({ 
        error: "Verification code generated but could not send SMS",
        consumerId: newConsumer.id,
        verificationCode: process.env.NODE_ENV === "development" ? verificationCode : undefined
      });
    }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors });
    }
    console.error("Consumer registration error:", error);
    return res.status(500).json({ error: "Failed to register consumer" });
  }
});

// Verify consumer with verification code
router.post("/verify", async (req: Request, res: Response) => {
  try {
    // Validate request body
    const validatedData = verifyConsumerSchema.parse(req.body);
    
    // Find consumer by phone
    const consumer = await storage.getConsumerByPhone(validatedData.phone);
    
    if (!consumer) {
      return res.status(404).json({ error: "Consumer not found" });
    }
    
    // Check if passcode matches
    if (consumer.temporaryPasscode !== validatedData.passcode) {
      return res.status(401).json({ error: "Invalid verification code" });
    }
    
    // Update consumer verification status
    const updatedConsumer = await storage.updateConsumerVerification(
      consumer.id, 
      "verified"
    );
    
    // Create activity for verification
    await storage.createActivity({
      type: "consumer_verified",
      description: `Consumer ${consumer.name} verified their account`,
      details: { 
        consumerId: consumer.id,
        phone: consumer.phone
      },
      timestamp: new Date(),
      relatedId: consumer.id,
      relatedType: "consumer"
    });
    
    // Return success without sensitive data
    return res.status(200).json({
      message: "Verification successful",
      consumerId: updatedConsumer?.id,
      name: updatedConsumer?.name,
      verified: true
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors });
    }
    console.error("Consumer verification error:", error);
    return res.status(500).json({ error: "Failed to verify consumer" });
  }
});

// Login consumer
router.post("/login", async (req: Request, res: Response) => {
  try {
    // Validate request body
    const validatedData = loginConsumerSchema.parse(req.body);
    
    // Find consumer by phone
    const consumer = await storage.getConsumerByPhone(validatedData.phone);
    
    if (!consumer) {
      return res.status(404).json({ error: "Consumer not found" });
    }
    
    // Check verification status
    if (consumer.verificationStatus !== "verified") {
      return res.status(401).json({ 
        error: "Account not verified",
        status: "unverified" 
      });
    }
    
    // Check if passcode matches
    if (consumer.temporaryPasscode !== validatedData.passcode) {
      return res.status(401).json({ error: "Invalid passcode" });
    }
    
    // Update last login time
    const updatedConsumer = await storage.updateConsumerLastLogin(consumer.id);
    
    // Create activity for login
    await storage.createActivity({
      type: "consumer_login",
      description: `Consumer ${consumer.name} logged in`,
      details: { 
        consumerId: consumer.id,
        phone: consumer.phone
      },
      timestamp: new Date(),
      relatedId: consumer.id,
      relatedType: "consumer"
    });
    
    // Return consumer data without sensitive fields
    return res.status(200).json({
      consumerId: updatedConsumer?.id,
      name: updatedConsumer?.name,
      phone: updatedConsumer?.phone,
      email: updatedConsumer?.email,
      address: updatedConsumer?.address,
      location: updatedConsumer?.location
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors });
    }
    console.error("Consumer login error:", error);
    return res.status(500).json({ error: "Failed to login consumer" });
  }
});

// Resend verification code
router.post("/resend-code", async (req: Request, res: Response) => {
  try {
    const { phone } = req.body;
    
    if (!phone) {
      return res.status(400).json({ error: "Phone number is required" });
    }
    
    // Find consumer by phone
    const consumer = await storage.getConsumerByPhone(phone);
    
    if (!consumer) {
      return res.status(404).json({ error: "Consumer not found" });
    }
    
    // Generate a new verification code
    const verificationCode = generateVerificationCode();
    
    // Update consumer's verification code
    await storage.updateConsumerVerification(
      consumer.id, 
      "pending", 
      verificationCode
    );
    
    // Send SMS with verification code
    try {
      await sendSMS(
        phone,
        `Your Coldfarms Market verification code is: ${verificationCode}`
      );
      
      return res.status(200).json({
        message: "Verification code sent"
      });
    } catch (error) {
      console.error("SMS sending error:", error);
      return res.status(500).json({ 
        error: "Could not send verification code SMS",
        verificationCode: process.env.NODE_ENV === "development" ? verificationCode : undefined
      });
    }
  } catch (error) {
    console.error("Resend verification code error:", error);
    return res.status(500).json({ error: "Failed to resend verification code" });
  }
});

// Get consumer profile
router.get("/profile/:id", async (req: Request, res: Response) => {
  try {
    const consumerId = parseInt(req.params.id);
    
    if (isNaN(consumerId)) {
      return res.status(400).json({ error: "Invalid consumer ID" });
    }
    
    const consumer = await storage.getConsumer(consumerId);
    
    if (!consumer) {
      return res.status(404).json({ error: "Consumer not found" });
    }
    
    // Return consumer data without sensitive fields
    return res.status(200).json({
      id: consumer.id,
      name: consumer.name,
      phone: consumer.phone,
      email: consumer.email,
      address: consumer.address,
      location: consumer.location,
      registrationDate: consumer.registrationDate
    });
  } catch (error) {
    console.error("Get consumer profile error:", error);
    return res.status(500).json({ error: "Failed to retrieve consumer profile" });
  }
});

// Update consumer profile
router.put("/profile/:id", async (req: Request, res: Response) => {
  try {
    const consumerId = parseInt(req.params.id);
    
    if (isNaN(consumerId)) {
      return res.status(400).json({ error: "Invalid consumer ID" });
    }
    
    const consumer = await storage.getConsumer(consumerId);
    
    if (!consumer) {
      return res.status(404).json({ error: "Consumer not found" });
    }
    
    // Validate request body - allow only these fields to be updated
    const updateSchema = z.object({
      name: z.string().optional(),
      email: z.string().email().optional().nullable(),
      address: z.string().optional().nullable(),
      location: z.any().optional().nullable()
    });
    
    const validatedData = updateSchema.parse(req.body);
    
    // Update consumer
    const updatedConsumer = await storage.updateConsumer(consumerId, validatedData);
    
    // Return updated consumer without sensitive fields
    return res.status(200).json({
      id: updatedConsumer?.id,
      name: updatedConsumer?.name,
      phone: updatedConsumer?.phone,
      email: updatedConsumer?.email,
      address: updatedConsumer?.address,
      location: updatedConsumer?.location
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors });
    }
    console.error("Update consumer profile error:", error);
    return res.status(500).json({ error: "Failed to update consumer profile" });
  }
});

export default router;