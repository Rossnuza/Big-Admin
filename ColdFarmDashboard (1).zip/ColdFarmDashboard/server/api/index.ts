import { Express } from 'express';
import farmerApiRouter from './farmer-api';
import themeApiRouter from './theme-api';

export function registerAPIs(app: Express) {
  // Register the farmer API under /api/mobile/farmer prefix
  app.use('/api/mobile/farmer', farmerApiRouter);
  
  // Register the theme API
  app.use('/api/theme', themeApiRouter);
  
  // Additional mobile APIs can be registered here as the platform grows
  // app.use('/api/mobile/consumer', consumerApiRouter);
}