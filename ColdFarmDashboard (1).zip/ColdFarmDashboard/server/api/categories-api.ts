import { Express } from "express";
import { storage } from "../storage";
import { insertCategorySchema, insertProductTypeSchema } from "@shared/schema";

export default function registerCategoriesAPI(app: Express) {
  // Get all categories
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Error fetching categories" });
    }
  });
  
  // Get single category by ID
  app.get("/api/categories/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const category = await storage.getCategory(id);
      
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      res.json(category);
    } catch (error) {
      console.error(`Error fetching category with id ${req.params.id}:`, error);
      res.status(500).json({ message: "Error fetching category" });
    }
  });
  
  // Create new category
  app.post("/api/categories", async (req, res) => {
    // Ensure the user is authenticated
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      // Validate request body against schema
      const result = insertCategorySchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid category data", 
          errors: result.error.errors 
        });
      }
      
      // Check if a category with the same name already exists
      const existingCategory = await storage.getCategoryByName(result.data.name);
      if (existingCategory) {
        return res.status(409).json({ message: "Category with this name already exists" });
      }
      
      // Create new category
      const newCategory = await storage.createCategory(result.data);
      res.status(201).json(newCategory);
    } catch (error) {
      console.error("Error creating category:", error);
      res.status(500).json({ message: "Error creating category" });
    }
  });
  
  // Update category
  app.patch("/api/categories/:id", async (req, res) => {
    // Ensure the user is authenticated
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const id = parseInt(req.params.id);
      const category = await storage.getCategory(id);
      
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      // If trying to update the name, check if it already exists
      if (req.body.name && req.body.name !== category.name) {
        const existingCategory = await storage.getCategoryByName(req.body.name);
        if (existingCategory && existingCategory.id !== id) {
          return res.status(409).json({ message: "Category with this name already exists" });
        }
      }
      
      // Update category
      const updatedCategory = await storage.updateCategory(id, req.body);
      res.json(updatedCategory);
    } catch (error) {
      console.error(`Error updating category with id ${req.params.id}:`, error);
      res.status(500).json({ message: "Error updating category" });
    }
  });
  
  // Delete category
  app.delete("/api/categories/:id", async (req, res) => {
    // Ensure the user is authenticated
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const id = parseInt(req.params.id);
      const category = await storage.getCategory(id);
      
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      // Try to delete - this will fail if the category is in use by product types
      const deleted = await storage.deleteCategory(id);
      
      if (!deleted) {
        return res.status(409).json({ message: "Cannot delete category because it is in use by product types" });
      }
      
      res.status(200).json({ message: "Category deleted successfully" });
    } catch (error) {
      console.error(`Error deleting category with id ${req.params.id}:`, error);
      res.status(500).json({ message: "Error deleting category" });
    }
  });
  
  // Get all product types
  app.get("/api/product-types", async (req, res) => {
    try {
      const productTypes = await storage.getProductTypes();
      res.json(productTypes);
    } catch (error) {
      console.error("Error fetching product types:", error);
      res.status(500).json({ message: "Error fetching product types" });
    }
  });
  
  // Get product types for a specific category
  app.get("/api/categories/:categoryName/product-types", async (req, res) => {
    try {
      const categoryName = req.params.categoryName;
      const productTypes = await storage.getProductTypesByCategory(categoryName);
      res.json(productTypes);
    } catch (error) {
      console.error(`Error fetching product types for category ${req.params.categoryName}:`, error);
      res.status(500).json({ message: "Error fetching product types" });
    }
  });
  
  // Get single product type by ID
  app.get("/api/product-types/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const productType = await storage.getProductType(id);
      
      if (!productType) {
        return res.status(404).json({ message: "Product type not found" });
      }
      
      res.json(productType);
    } catch (error) {
      console.error(`Error fetching product type with id ${req.params.id}:`, error);
      res.status(500).json({ message: "Error fetching product type" });
    }
  });
  
  // Create new product type
  app.post("/api/product-types", async (req, res) => {
    // Ensure the user is authenticated
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      // Validate request body against schema
      const result = insertProductTypeSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid product type data", 
          errors: result.error.errors 
        });
      }
      
      // Check if the specified category exists
      const category = await storage.getCategoryByName(result.data.category);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      // Create new product type
      const newProductType = await storage.createProductType(result.data);
      res.status(201).json(newProductType);
    } catch (error) {
      console.error("Error creating product type:", error);
      res.status(500).json({ message: "Error creating product type" });
    }
  });
  
  // Update product type
  app.patch("/api/product-types/:id", async (req, res) => {
    // Ensure the user is authenticated
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const id = parseInt(req.params.id);
      const productType = await storage.getProductType(id);
      
      if (!productType) {
        return res.status(404).json({ message: "Product type not found" });
      }
      
      // If category is being updated, check if it exists
      if (req.body.category && req.body.category !== productType.category) {
        const category = await storage.getCategoryByName(req.body.category);
        if (!category) {
          return res.status(404).json({ message: "Category not found" });
        }
      }
      
      // Update product type
      const updatedProductType = await storage.updateProductType(id, req.body);
      res.json(updatedProductType);
    } catch (error) {
      console.error(`Error updating product type with id ${req.params.id}:`, error);
      res.status(500).json({ message: "Error updating product type" });
    }
  });
  
  // Delete product type
  app.delete("/api/product-types/:id", async (req, res) => {
    // Ensure the user is authenticated
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const id = parseInt(req.params.id);
      const productType = await storage.getProductType(id);
      
      if (!productType) {
        return res.status(404).json({ message: "Product type not found" });
      }
      
      // In a real implementation, we would check if any products are using this product type
      // before deleting it
      
      const deleted = await storage.deleteProductType(id);
      
      if (!deleted) {
        return res.status(409).json({ message: "Cannot delete product type because it is in use" });
      }
      
      res.status(200).json({ message: "Product type deleted successfully" });
    } catch (error) {
      console.error(`Error deleting product type with id ${req.params.id}:`, error);
      res.status(500).json({ message: "Error deleting product type" });
    }
  });
}