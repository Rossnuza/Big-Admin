import { Express, Request, Response, NextFunction, Router } from 'express';
import { storage } from '../storage';
import { calculateFarmerStorageCosts, formatStorageStatement } from '@shared/billing';
import { formatCurrency } from '@shared/constants';
import { insertInventorySchema, insertFarmerSchema, Farmer, insertStorageBookingSchema, ProductType, Category } from '@shared/schema';
import { z } from 'zod';

// Extend Express Request type to include farmer property
interface FarmerRequest extends Request {
  farmer?: Farmer;
}

// Create a router for farmer API endpoints
const farmerApiRouter = Router();

export default farmerApiRouter;

// Middleware to ensure the authenticated user is only accessing their own farmer data
const ensureFarmerOwnership = async (req: FarmerRequest, res: Response, next: NextFunction) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  
  // Farmer ID from the URL params or query
  const farmerId = Number(req.params.farmerId || req.query.farmerId);
  
  if (isNaN(farmerId)) {
    return res.status(400).json({ message: "Invalid farmer ID" });
  }
  
  // Validate the current user has access to this farmer's data
  // In the full implementation, you'll need to add a userId to the farmer model 
  // or have a separate farmers_users mapping table
  
  // For now, we're just checking if the farmer exists
  const farmer = await storage.getFarmer(farmerId);
  if (!farmer) {
    return res.status(404).json({ message: "Farmer not found" });
  }
  
  // Store the verified farmer in the request for future use
  req.farmer = farmer;
  next();
};

// Get farmer profile
farmerApiRouter.get('/profile/:farmerId', ensureFarmerOwnership, async (req: FarmerRequest, res: Response) => {
  try {
    res.json(req.farmer);
  } catch (error) {
    console.error("Error fetching farmer profile:", error);
    res.status(500).json({ message: "Error fetching farmer profile" });
  }
});

// Update farmer profile
farmerApiRouter.patch('/profile/:farmerId', ensureFarmerOwnership, async (req: FarmerRequest, res: Response) => {
  try {
    const farmerId = Number(req.params.farmerId);
    const updateData = req.body;
    
    // Validate update data with a simpler approach
    // Skip schema validation for partial updates
    const validatedData = updateData;
    
    const updatedFarmer = await storage.updateFarmer(farmerId, validatedData);
    if (!updatedFarmer) {
      return res.status(404).json({ message: "Farmer not found" });
    }
    
    res.json(updatedFarmer);
  } catch (error) {
    console.error("Error updating farmer profile:", error);
    res.status(500).json({ message: "Error updating farmer profile" });
  }
});

// Get farmer inventory items
farmerApiRouter.get('/inventory/:farmerId', ensureFarmerOwnership, async (req: FarmerRequest, res: Response) => {
  try {
    const farmerId = Number(req.params.farmerId);
    const inventoryItems = await storage.getFarmerInventory(farmerId);
    res.json(inventoryItems);
  } catch (error) {
    console.error("Error fetching farmer inventory:", error);
    res.status(500).json({ message: "Error fetching farmer inventory" });
  }
});

// Add inventory item
farmerApiRouter.post('/inventory/:farmerId', ensureFarmerOwnership, async (req: FarmerRequest, res: Response) => {
  try {
    const farmerId = Number(req.params.farmerId);
    
    // Preprocess the data before validation - convert string dates to actual Date objects
    const preprocessedData = {
      ...req.body,
      farmerId, // Ensure the correct farmerId from the URL is used
      startDate: req.body.startDate ? new Date(req.body.startDate) : new Date(),
      endDate: req.body.endDate ? new Date(req.body.endDate) : null,
    };
    
    // Use parse directly - transformations in schema will handle type conversions
    const validatedData = insertInventorySchema.parse(preprocessedData);
    
    const inventoryItem = await storage.createFarmerInventory(validatedData);
    
    // Create activity log
    await storage.createActivity({
      type: "new_inventory_item",
      description: "New inventory item added",
      details: { 
        farmerId,
        productName: inventoryItem.productName,
        quantity: inventoryItem.quantity,
        unit: inventoryItem.unit
      },
      timestamp: new Date(),
      relatedId: inventoryItem.id,
      relatedType: "farmer_inventory"
    });
    
    res.status(201).json(inventoryItem);
  } catch (error) {
    console.error("Error adding inventory item:", error);
    res.status(500).json({ message: "Error adding inventory item" });
  }
});

// Update inventory item (e.g., opt-in to marketplace)
farmerApiRouter.patch('/inventory/:farmerId/:itemId', ensureFarmerOwnership, async (req: FarmerRequest, res: Response) => {
  try {
    const itemId = Number(req.params.itemId);
    const updateData = req.body;
    
    // Validate the inventory item belongs to this farmer
    const item = await storage.getFarmerInventoryItem(itemId);
    if (!item || item.farmerId !== Number(req.params.farmerId)) {
      return res.status(404).json({ message: "Inventory item not found" });
    }
    
    const updatedItem = await storage.updateFarmerInventory(itemId, updateData);
    if (!updatedItem) {
      return res.status(404).json({ message: "Inventory item not found" });
    }
    
    res.json(updatedItem);
  } catch (error) {
    console.error("Error updating inventory item:", error);
    res.status(500).json({ message: "Error updating inventory item" });
  }
});

// Get farmer storage costs
farmerApiRouter.get('/storage-costs/:farmerId', ensureFarmerOwnership, async (req: FarmerRequest, res: Response) => {
  try {
    const farmerId = Number(req.params.farmerId);
    const inventoryItems = await storage.getFarmerInventory(farmerId);
    const storageCosts = calculateFarmerStorageCosts(farmerId, inventoryItems);
    res.json(storageCosts);
  } catch (error) {
    console.error("Error calculating storage costs:", error);
    res.status(500).json({ message: "Error calculating storage costs" });
  }
});

// Get formatted storage statement
farmerApiRouter.get('/storage-statement/:farmerId', ensureFarmerOwnership, async (req: FarmerRequest, res: Response) => {
  try {
    const farmerId = Number(req.params.farmerId);
    const inventoryItems = await storage.getFarmerInventory(farmerId);
    const storageCosts = calculateFarmerStorageCosts(farmerId, inventoryItems);
    const statement = formatStorageStatement(storageCosts);
    res.json({ statement, storageCosts });
  } catch (error) {
    console.error("Error generating storage statement:", error);
    res.status(500).json({ message: "Error generating storage statement" });
  }
});

// Get storage units for booking
farmerApiRouter.get('/storage-units', async (req: Request, res: Response) => {
  try {
    const storageUnits = await storage.getStorageUnits();
    
    // Format for the farmers app - adding utilization percentage
    const formattedUnits = await Promise.all(storageUnits.map(async unit => {
      // Calculate used capacity from inventory items
      const inventoryItems = await storage.getAllFarmerInventories();
      const unitItems = inventoryItems.filter(item => item.storageUnitId === unit.id);
      
      // Calculate total weight in the unit
      const usedCapacity = unitItems.reduce((sum, item) => {
        // Convert to kg if needed
        const weightInKg = item.unit.toLowerCase() === 'ton' ? 
          item.quantity * 1000 : item.quantity;
        return sum + weightInKg;
      }, 0);
      
      return {
        ...unit,
        usedCapacity,
        availableCapacity: unit.capacity - usedCapacity,
        utilizationPercentage: Math.round((usedCapacity / unit.capacity) * 100)
      };
    }));
    
    res.json(formattedUnits);
  } catch (error) {
    console.error("Error fetching storage units:", error);
    res.status(500).json({ message: "Error fetching storage units" });
  }
});

// Get farmer sales data
farmerApiRouter.get('/sales/:farmerId', ensureFarmerOwnership, async (req: FarmerRequest, res: Response) => {
  try {
    const farmerId = Number(req.params.farmerId);
    
    // Get all orders
    const orders = await storage.getOrders();
    
    // Filter order items for this farmer
    const allOrderItems = await Promise.all(
      orders.map(order => storage.getOrderItems(order.id))
    );
    
    // Flatten the array of order items
    const orderItems = allOrderItems.flat();
    
    // Get farmer's inventory items
    const inventoryItems = await storage.getFarmerInventory(farmerId);
    
    // Match order items to inventory items for this farmer
    const farmerSales = orderItems.filter(item => {
      // Check based on product ID and farmer ID mapping
      // This is a simplified approach - in the real implementation we would 
      // have a direct mapping between order items and inventory items
      const matchingInventory = inventoryItems.find(
        inv => inv.id === (item as any).inventoryItemId
      );
      return !!matchingInventory;
    });
    
    // Enhance sales data with order information
    const enhancedSales = await Promise.all(
      farmerSales.map(async sale => {
        const order = orders.find(o => o.id === sale.orderId);
        const inventoryItem = inventoryItems.find(i => i.id === (sale as any).inventoryItemId);
        
        // Extract product information
        const product = await storage.getProduct(sale.productId);
        
        return {
          saleId: sale.id,
          orderId: sale.orderId,
          orderDate: order?.orderDate,
          orderStatus: order?.status,
          customerName: order?.customerName,
          productName: inventoryItem?.productName || product?.name || "Unknown Product",
          quantity: sale.quantity,
          unit: product?.unit || "unit",
          price: sale.price,
          totalAmount: sale.quantity * sale.price,
          formattedTotalAmount: formatCurrency(sale.quantity * sale.price)
        };
      })
    );
    
    // Calculate sales summary
    const totalSales = enhancedSales.reduce((sum, sale) => sum + (sale.totalAmount || 0), 0);
    const pendingSales = enhancedSales
      .filter(sale => ['pending', 'processing'].includes(sale.orderStatus || ''))
      .reduce((sum, sale) => sum + (sale.totalAmount || 0), 0);
    const completedSales = enhancedSales
      .filter(sale => ['completed', 'delivered'].includes(sale.orderStatus || ''))
      .reduce((sum, sale) => sum + (sale.totalAmount || 0), 0);
    
    res.json({
      sales: enhancedSales,
      summary: {
        totalSales,
        pendingSales,
        completedSales,
        formattedTotalSales: formatCurrency(totalSales),
        formattedPendingSales: formatCurrency(pendingSales),
        formattedCompletedSales: formatCurrency(completedSales)
      }
    });
  } catch (error) {
    console.error("Error fetching farmer sales:", error);
    res.status(500).json({ message: "Error fetching farmer sales" });
  }
});

// Book a storage slot
farmerApiRouter.post('/book-storage/:farmerId', ensureFarmerOwnership, async (req: FarmerRequest, res: Response) => {
  try {
    const farmerId = Number(req.params.farmerId);
    const { storageUnitId, productName, quantity, unit, startDate, endDate, notes } = req.body;
    
    // Validate storage unit exists and has capacity
    const storageUnit = await storage.getStorageUnit(Number(storageUnitId));
    if (!storageUnit) {
      return res.status(404).json({ message: "Storage unit not found" });
    }
    
    // Check if storage unit is operational
    if (storageUnit.status !== 'operational') {
      return res.status(400).json({ 
        message: `Storage unit is currently ${storageUnit.status} and not available for booking` 
      });
    }
    
    // Create a storage booking request
    const bookingData = {
      farmerId,
      storageUnitId: Number(storageUnitId),
      productName,
      quantity: Number(quantity),
      unit,
      startDate: startDate ? new Date(startDate) : new Date(),
      endDate: endDate ? new Date(endDate) : null,
      status: "pending",
      farmerNotes: notes || null
    };
    
    const validatedData = insertStorageBookingSchema.parse(bookingData);
    const booking = await storage.createStorageBooking(validatedData);
    
    res.status(201).json({ 
      booking,
      message: "Storage booking request submitted successfully"
    });
  } catch (error) {
    console.error("Error booking storage:", error);
    res.status(500).json({ message: "Error booking storage" });
  }
});

// Get dashboard stats for a farmer
farmerApiRouter.get('/dashboard/:farmerId', ensureFarmerOwnership, async (req: FarmerRequest, res: Response) => {
  try {
    const farmerId = Number(req.params.farmerId);
    
    // Get inventory items
    const inventoryItems = await storage.getFarmerInventory(farmerId);
    
    // Calculate storage costs
    const storageCosts = calculateFarmerStorageCosts(farmerId, inventoryItems);
    
    // Count active inventory items
    const activeItems = inventoryItems.filter(item => 
      item.status !== 'sold' && item.status !== 'expired'
    );
    
    // Count marketplace items
    const marketplaceItems = inventoryItems.filter(item => 
      item.listedOnMarketplace === true && item.status !== 'sold'
    );
    
    // Calculate inventory weight statistics
    const totalWeight = inventoryItems.reduce((sum, item) => {
      // Convert to kg if needed
      const weightInKg = item.unit.toLowerCase() === 'ton' ? 
        item.quantity * 1000 : item.quantity;
      return sum + weightInKg;
    }, 0);
    
    // Calculate expiring soon (items expiring in the next 7 days)
    const today = new Date();
    const sevenDaysLater = new Date();
    sevenDaysLater.setDate(today.getDate() + 7);
    
    const expiringSoon = inventoryItems.filter(item => {
      if (!item.endDate) return false;
      const endDate = new Date(item.endDate);
      return endDate >= today && endDate <= sevenDaysLater;
    });
    
    // Get sales data
    // This would typically be more complex, but for MVP we'll calculate a simple total
    let totalSales = 0;
    try {
      // Get all orders
      const orders = await storage.getOrders();
      
      // Get all order items and filter for this farmer's items
      for (const order of orders) {
        const orderItems = await storage.getOrderItems(order.id);
        
        for (const item of orderItems) {
          // Check if this item is from one of the farmer's inventory
          // Type assertion needed for property access
          const inventoryItemId = (item as any).inventoryItemId;
          const matchingInventory = inventoryItemId 
            ? inventoryItems.find(inv => inv.id === inventoryItemId)
            : null;
            
          if (matchingInventory) {
            totalSales += item.price * item.quantity;
          }
        }
      }
    } catch (error) {
      console.error("Error calculating sales:", error);
      // Continue with other calculations
    }
    
    res.json({
      activeInventoryCount: activeItems.length,
      marketplaceItemCount: marketplaceItems.length,
      totalStorageCost: storageCosts.totalCost,
      formattedStorageCost: storageCosts.formattedCost,
      totalWeight,
      formattedTotalWeight: `${totalWeight.toFixed(1)} kg`,
      expiringSoonCount: expiringSoon.length,
      totalSales,
      formattedTotalSales: formatCurrency(totalSales)
    });
  } catch (error) {
    console.error("Error fetching farmer dashboard stats:", error);
    res.status(500).json({ message: "Error fetching dashboard stats" });
  }
});

// Toggle inventory item marketplace listing
farmerApiRouter.patch('/marketplace-listing/:farmerId/:itemId', ensureFarmerOwnership, async (req: FarmerRequest, res: Response) => {
  try {
    const farmerId = Number(req.params.farmerId);
    const itemId = Number(req.params.itemId);
    const { listedOnMarketplace, price } = req.body;
    
    // Validate the inventory item belongs to this farmer
    const item = await storage.getFarmerInventoryItem(itemId);
    if (!item || item.farmerId !== farmerId) {
      return res.status(404).json({ message: "Inventory item not found" });
    }
    
    // Validate marketplace listing requirements
    if (listedOnMarketplace === true && !price) {
      return res.status(400).json({ message: "Price is required for marketplace listings" });
    }
    
    // Update the item
    const updatedData: any = { listedOnMarketplace };
    if (price) updatedData.price = price;
    
    const updatedItem = await storage.updateFarmerInventory(itemId, updatedData);
    
    // Create activity log
    await storage.createActivity({
      type: listedOnMarketplace ? "item_listed" : "item_unlisted",
      description: listedOnMarketplace 
        ? `Item listed on marketplace: ${item.productName}`
        : `Item removed from marketplace: ${item.productName}`,
      details: { 
        farmerId,
        itemId,
        productName: item.productName,
        listedOnMarketplace
      },
      timestamp: new Date(),
      relatedId: itemId,
      relatedType: "farmer_inventory"
    });
    
    res.json(updatedItem);
  } catch (error) {
    console.error("Error updating marketplace listing:", error);
    res.status(500).json({ message: "Error updating marketplace listing" });
  }
});

// Get farmer's storage booking requests
farmerApiRouter.get('/bookings/:farmerId', ensureFarmerOwnership, async (req: FarmerRequest, res: Response) => {
  try {
    const farmerId = Number(req.params.farmerId);
    const bookings = await storage.getStorageBookingsByFarmer(farmerId);
    
    // Enhance bookings data with storage unit details
    const enhancedBookings = await Promise.all(bookings.map(async booking => {
      const storageUnit = await storage.getStorageUnit(booking.storageUnitId);
      return {
        ...booking,
        storageUnitName: storageUnit?.location || 'Unknown Location',
        inventoryItem: booking.inventoryItemId ? 
          await storage.getFarmerInventoryItem(booking.inventoryItemId) : null
      };
    }));
    
    res.json(enhancedBookings);
  } catch (error) {
    console.error("Error fetching storage bookings:", error);
    res.status(500).json({ message: "Error fetching storage bookings" });
  }
});

// Cancel a storage booking request
farmerApiRouter.post('/bookings/:farmerId/:bookingId/cancel', ensureFarmerOwnership, async (req: FarmerRequest, res: Response) => {
  try {
    const farmerId = Number(req.params.farmerId);
    const bookingId = Number(req.params.bookingId);
    const { cancelReason } = req.body;
    
    // Verify the booking exists and belongs to this farmer
    const booking = await storage.getStorageBooking(bookingId);
    if (!booking || booking.farmerId !== farmerId) {
      return res.status(404).json({ message: "Booking not found" });
    }
    
    // Check if booking can be cancelled
    if (booking.status !== 'pending' && booking.status !== 'approved') {
      return res.status(400).json({ 
        message: `Booking with status '${booking.status}' cannot be cancelled` 
      });
    }
    
    // Update booking status to cancelled
    const updatedBooking = await storage.updateStorageBookingStatus(
      bookingId, 
      'cancelled', 
      cancelReason ? `Cancelled by farmer: ${cancelReason}` : 'Cancelled by farmer'
    );
    
    res.json({
      booking: updatedBooking,
      message: "Booking cancelled successfully"
    });
  } catch (error) {
    console.error("Error cancelling booking:", error);
    res.status(500).json({ message: "Error cancelling booking" });
  }
});

// Get all categories for mobile app
farmerApiRouter.get('/categories', async (req: Request, res: Response) => {
  try {
    const categories = await storage.getCategories();
    res.json(categories);
  } catch (error) {
    console.error("Error fetching categories:", error);
    res.status(500).json({ message: "Error fetching categories" });
  }
});

// Get product types by category for mobile app
farmerApiRouter.get('/product-types-by-category/:categoryName', async (req: Request, res: Response) => {
  try {
    const categoryName = req.params.categoryName;
    if (!categoryName) {
      return res.status(400).json({ message: "Category name is required" });
    }
    
    const productTypes = await storage.getProductTypesByCategory(categoryName);
    
    if (productTypes.length === 0) {
      console.log(`No product types found for category: ${categoryName}`);
    }
    
    res.json(productTypes);
  } catch (error) {
    console.error(`Error fetching product types for category ${req.params.categoryName}:`, error);
    res.status(500).json({ message: "Error fetching product types" });
  }
});

// Get all product types for mobile app
farmerApiRouter.get('/product-types', async (req: Request, res: Response) => {
  try {
    const productTypes = await storage.getProductTypes();
    res.json(productTypes);
  } catch (error) {
    console.error("Error fetching product types:", error);
    res.status(500).json({ message: "Error fetching product types" });
  }
});