import { Request, Response, Router } from "express";
import { storage } from "../storage";
import { z } from "zod";

const router = Router();

// Get cart items for a consumer
router.get("/:consumerId", async (req: Request, res: Response) => {
  try {
    const consumerId = parseInt(req.params.consumerId);
    
    if (isNaN(consumerId)) {
      return res.status(400).json({ error: "Invalid consumer ID" });
    }
    
    // Check if consumer exists
    const consumer = await storage.getConsumer(consumerId);
    if (!consumer) {
      return res.status(404).json({ error: "Consumer not found" });
    }
    
    // Get cart items
    const cartItems = await storage.getCartItems(consumerId);
    
    // Enhance cart items with product details
    const enhancedCartItems = await Promise.all(cartItems.map(async (item) => {
      const product = await storage.getProduct(item.productId);
      
      if (!product) {
        return {
          ...item,
          productDetails: { name: "Unknown Product", price: 0, image: null, unit: 'kg' }
        };
      }
      
      // Get product type for unit information
      const productTypes = await storage.getProductTypes();
      const productType = productTypes.find(pt => pt.name === product.productType);
      
      return {
        ...item,
        productDetails: {
          name: product.name,
          price: product.price,
          image: product.image,
          unit: productType?.standardUnit || 'kg',
          isAvailable: product.isListed && product.quantityAvailable > 0,
          quantityAvailable: product.quantityAvailable
        }
      };
    }));
    
    // Calculate cart totals
    const subtotal = enhancedCartItems.reduce((sum, item) => {
      const price = item.productDetails.price || 0;
      return sum + (price * item.quantity);
    }, 0);
    
    // Get delivery settings for fee calculation
    const deliverySettings = await storage.getDeliverySettings();
    const baseDeliveryFee = deliverySettings?.baseDeliveryFee || 0;
    
    const response = {
      items: enhancedCartItems,
      subtotal,
      estimatedDeliveryFee: baseDeliveryFee,
      total: subtotal + baseDeliveryFee,
      itemCount: cartItems.length,
      minOrderAmount: deliverySettings?.minimumOrderAmount || 0
    };
    
    return res.status(200).json(response);
  } catch (error) {
    console.error("Get cart items error:", error);
    return res.status(500).json({ error: "Failed to retrieve cart items" });
  }
});

// Schema for adding item to cart
const addToCartSchema = z.object({
  consumerId: z.number().int().positive(),
  productId: z.number().int().positive(),
  quantity: z.number().int().positive().default(1)
});

// Add item to cart
router.post("/add", async (req: Request, res: Response) => {
  try {
    // Validate request body
    const validatedData = addToCartSchema.parse(req.body);
    
    // Check if consumer exists
    const consumer = await storage.getConsumer(validatedData.consumerId);
    if (!consumer) {
      return res.status(404).json({ error: "Consumer not found" });
    }
    
    // Check if product exists and is available
    const product = await storage.getProduct(validatedData.productId);
    if (!product) {
      return res.status(404).json({ error: "Product not found" });
    }
    
    if (!product.isListed || product.quantityAvailable <= 0) {
      return res.status(400).json({ error: "Product is not available for purchase" });
    }
    
    // Check if requested quantity is available
    if (validatedData.quantity > product.quantityAvailable) {
      return res.status(400).json({ 
        error: "Requested quantity exceeds available quantity",
        availableQuantity: product.quantityAvailable
      });
    }
    
    // Check if product already in cart
    const existingCartItems = await storage.getCartItems(validatedData.consumerId);
    const existingItem = existingCartItems.find(item => item.productId === validatedData.productId);
    
    let cartItem;
    
    if (existingItem) {
      // Update quantity if item already exists
      const newQuantity = existingItem.quantity + validatedData.quantity;
      
      // Check if new total quantity is available
      if (newQuantity > product.quantityAvailable) {
        return res.status(400).json({ 
          error: "Total quantity exceeds available quantity",
          availableQuantity: product.quantityAvailable,
          currentInCart: existingItem.quantity
        });
      }
      
      cartItem = await storage.updateCartItemQuantity(existingItem.id, newQuantity);
    } else {
      // Add new item to cart
      cartItem = await storage.createCartItem({
        consumerId: validatedData.consumerId,
        productId: validatedData.productId,
        quantity: validatedData.quantity
      });
    }
    
    // Create an activity for cart update
    await storage.createActivity({
      type: "cart_updated",
      description: `${consumer.name} added ${product.name} to cart`,
      details: { 
        consumerId: validatedData.consumerId,
        productId: validatedData.productId,
        productName: product.name,
        quantity: validatedData.quantity
      },
      timestamp: new Date(),
      relatedId: validatedData.consumerId,
      relatedType: "consumer"
    });
    
    // Calculate new cart totals
    const updatedCartItems = await storage.getCartItems(validatedData.consumerId);
    const allProducts = await storage.getProducts();
    
    const subtotal = updatedCartItems.reduce((sum, item) => {
      const itemProduct = allProducts.find(p => p.id === item.productId);
      const price = itemProduct?.price || 0;
      return sum + (price * item.quantity);
    }, 0);
    
    // Get delivery settings for fee calculation
    const deliverySettings = await storage.getDeliverySettings();
    const baseDeliveryFee = deliverySettings?.baseDeliveryFee || 0;
    
    return res.status(200).json({
      message: "Item added to cart successfully",
      cartItem,
      cartTotals: {
        subtotal,
        estimatedDeliveryFee: baseDeliveryFee,
        total: subtotal + baseDeliveryFee,
        itemCount: updatedCartItems.length
      }
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors });
    }
    console.error("Add to cart error:", error);
    return res.status(500).json({ error: "Failed to add item to cart" });
  }
});

// Schema for updating cart item
const updateCartSchema = z.object({
  cartItemId: z.number().int().positive(),
  quantity: z.number().int().positive()
});

// Update cart item quantity
router.put("/update", async (req: Request, res: Response) => {
  try {
    // Validate request body
    const validatedData = updateCartSchema.parse(req.body);
    
    // Check if cart item exists
    const cartItem = await storage.getCartItem(validatedData.cartItemId);
    if (!cartItem) {
      return res.status(404).json({ error: "Cart item not found" });
    }
    
    // Check if product exists and is available
    const product = await storage.getProduct(cartItem.productId);
    if (!product) {
      return res.status(404).json({ error: "Product not found" });
    }
    
    // Check if requested quantity is available
    if (validatedData.quantity > product.quantityAvailable) {
      return res.status(400).json({ 
        error: "Requested quantity exceeds available quantity",
        availableQuantity: product.quantityAvailable
      });
    }
    
    // Update cart item
    const updatedCartItem = await storage.updateCartItemQuantity(
      validatedData.cartItemId, 
      validatedData.quantity
    );
    
    // Get consumer and create activity
    const consumer = await storage.getConsumer(cartItem.consumerId);
    await storage.createActivity({
      type: "cart_updated",
      description: `${consumer?.name || 'Consumer'} updated ${product.name} quantity in cart`,
      details: { 
        consumerId: cartItem.consumerId,
        productId: cartItem.productId,
        productName: product.name,
        oldQuantity: cartItem.quantity,
        newQuantity: validatedData.quantity
      },
      timestamp: new Date(),
      relatedId: cartItem.consumerId,
      relatedType: "consumer"
    });
    
    // Calculate new cart totals
    const updatedCartItems = await storage.getCartItems(cartItem.consumerId);
    const allProducts = await storage.getProducts();
    
    const subtotal = updatedCartItems.reduce((sum, item) => {
      const itemProduct = allProducts.find(p => p.id === item.productId);
      const price = itemProduct?.price || 0;
      return sum + (price * item.quantity);
    }, 0);
    
    // Get delivery settings for fee calculation
    const deliverySettings = await storage.getDeliverySettings();
    const baseDeliveryFee = deliverySettings?.baseDeliveryFee || 0;
    
    return res.status(200).json({
      message: "Cart item updated successfully",
      cartItem: updatedCartItem,
      cartTotals: {
        subtotal,
        estimatedDeliveryFee: baseDeliveryFee,
        total: subtotal + baseDeliveryFee,
        itemCount: updatedCartItems.length
      }
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors });
    }
    console.error("Update cart error:", error);
    return res.status(500).json({ error: "Failed to update cart item" });
  }
});

// Remove item from cart
router.delete("/remove/:cartItemId", async (req: Request, res: Response) => {
  try {
    const cartItemId = parseInt(req.params.cartItemId);
    
    if (isNaN(cartItemId)) {
      return res.status(400).json({ error: "Invalid cart item ID" });
    }
    
    // Check if cart item exists
    const cartItem = await storage.getCartItem(cartItemId);
    if (!cartItem) {
      return res.status(404).json({ error: "Cart item not found" });
    }
    
    // Get consumer ID and product info for activity logging
    const consumerId = cartItem.consumerId;
    const product = await storage.getProduct(cartItem.productId);
    
    // Remove cart item
    const result = await storage.deleteCartItem(cartItemId);
    
    if (!result) {
      return res.status(500).json({ error: "Failed to remove item from cart" });
    }
    
    // Create activity for cart update
    const consumer = await storage.getConsumer(consumerId);
    await storage.createActivity({
      type: "cart_updated",
      description: `${consumer?.name || 'Consumer'} removed ${product?.name || 'product'} from cart`,
      details: { 
        consumerId: consumerId,
        productId: cartItem.productId,
        productName: product?.name || 'Unknown product'
      },
      timestamp: new Date(),
      relatedId: consumerId,
      relatedType: "consumer"
    });
    
    // Calculate new cart totals
    const updatedCartItems = await storage.getCartItems(consumerId);
    const allProducts = await storage.getProducts();
    
    const subtotal = updatedCartItems.reduce((sum, item) => {
      const itemProduct = allProducts.find(p => p.id === item.productId);
      const price = itemProduct?.price || 0;
      return sum + (price * item.quantity);
    }, 0);
    
    // Get delivery settings for fee calculation
    const deliverySettings = await storage.getDeliverySettings();
    const baseDeliveryFee = deliverySettings?.baseDeliveryFee || 0;
    
    return res.status(200).json({
      message: "Item removed from cart successfully",
      cartTotals: {
        subtotal,
        estimatedDeliveryFee: baseDeliveryFee,
        total: subtotal + baseDeliveryFee,
        itemCount: updatedCartItems.length
      }
    });
  } catch (error) {
    console.error("Remove from cart error:", error);
    return res.status(500).json({ error: "Failed to remove item from cart" });
  }
});

// Clear entire cart
router.delete("/clear/:consumerId", async (req: Request, res: Response) => {
  try {
    const consumerId = parseInt(req.params.consumerId);
    
    if (isNaN(consumerId)) {
      return res.status(400).json({ error: "Invalid consumer ID" });
    }
    
    // Check if consumer exists
    const consumer = await storage.getConsumer(consumerId);
    if (!consumer) {
      return res.status(404).json({ error: "Consumer not found" });
    }
    
    // Clear cart
    const result = await storage.clearCart(consumerId);
    
    if (!result) {
      return res.status(500).json({ error: "Failed to clear cart" });
    }
    
    // Create activity for cart clear
    await storage.createActivity({
      type: "cart_cleared",
      description: `${consumer.name} cleared their cart`,
      details: { consumerId },
      timestamp: new Date(),
      relatedId: consumerId,
      relatedType: "consumer"
    });
    
    return res.status(200).json({
      message: "Cart cleared successfully",
      cartTotals: {
        subtotal: 0,
        estimatedDeliveryFee: 0,
        total: 0,
        itemCount: 0
      }
    });
  } catch (error) {
    console.error("Clear cart error:", error);
    return res.status(500).json({ error: "Failed to clear cart" });
  }
});

export default router;