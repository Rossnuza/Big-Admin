import { Router } from 'express';
import fs from 'fs';
import path from 'path';

const themeApiRouter = Router();

// Define theme configuration with mobile-specific additions
interface Theme {
  // Core theme properties from theme.json
  variant: 'professional' | 'tint' | 'vibrant';
  primary: string;
  appearance: 'light' | 'dark' | 'system';
  radius: number;
  
  // Mobile-specific theme properties
  colors?: {
    primary: string;
    background: string;
    card: string;
    text: string;
    border: string;
    notification: string;
    success: string;
    warning: string;
    error: string;
    info: string;
    shade: {
      100: string;
      200: string;
      300: string;
      400: string;
      500: string;
      600: string;
      700: string;
      800: string;
      900: string;
    };
  };
  spacing?: {
    xs: number;
    sm: number;
    md: number;
    lg: number;
    xl: number;
    xxl: number;
  };
  typography?: {
    fontFamily: {
      sans: string;
      mono: string;
    };
    fontSize: {
      xs: number;
      sm: number;
      md: number;
      lg: number;
      xl: number;
      xxl: number;
    };
    fontWeight: {
      normal: string;
      medium: string;
      bold: string;
    };
  };
}

// Helper to derive mobile-specific theme properties from core theme
function deriveFullTheme(coreTheme: any): Theme {
  // Parse the primary color to create a color palette
  const primaryHsl = coreTheme.primary.match(/hsl\((\d+)\s+(\d+)%\s+(\d+)%\)/);
  let h = 175, s = 92, l = 26; // defaults if parsing fails
  
  if (primaryHsl && primaryHsl.length === 4) {
    h = parseInt(primaryHsl[1], 10);
    s = parseInt(primaryHsl[2], 10);
    l = parseInt(primaryHsl[3], 10);
  }
  
  // Create a theme object with derived properties
  const fullTheme: Theme = {
    ...coreTheme,
    colors: {
      primary: coreTheme.primary,
      background: coreTheme.appearance === 'dark' ? '#121212' : '#ffffff',
      card: coreTheme.appearance === 'dark' ? '#1e1e1e' : '#ffffff',
      text: coreTheme.appearance === 'dark' ? '#ffffff' : '#000000',
      border: coreTheme.appearance === 'dark' ? '#333333' : '#e2e8f0',
      notification: `hsl(${h}, ${s}%, ${l}%)`,
      success: 'hsl(145, 63%, 42%)',
      warning: 'hsl(45, 100%, 51%)',
      error: 'hsl(0, 91%, 65%)',
      info: 'hsl(200, 98%, 61%)',
      shade: {
        100: coreTheme.appearance === 'dark' ? 'hsl(0, 0%, 15%)' : 'hsl(0, 0%, 98%)',
        200: coreTheme.appearance === 'dark' ? 'hsl(0, 0%, 20%)' : 'hsl(0, 0%, 96%)',
        300: coreTheme.appearance === 'dark' ? 'hsl(0, 0%, 25%)' : 'hsl(0, 0%, 94%)',
        400: coreTheme.appearance === 'dark' ? 'hsl(0, 0%, 30%)' : 'hsl(0, 0%, 92%)',
        500: coreTheme.appearance === 'dark' ? 'hsl(0, 0%, 40%)' : 'hsl(0, 0%, 88%)',
        600: coreTheme.appearance === 'dark' ? 'hsl(0, 0%, 50%)' : 'hsl(0, 0%, 74%)',
        700: coreTheme.appearance === 'dark' ? 'hsl(0, 0%, 60%)' : 'hsl(0, 0%, 62%)',
        800: coreTheme.appearance === 'dark' ? 'hsl(0, 0%, 70%)' : 'hsl(0, 0%, 38%)',
        900: coreTheme.appearance === 'dark' ? 'hsl(0, 0%, 85%)' : 'hsl(0, 0%, 12%)'
      }
    },
    spacing: {
      xs: 4,
      sm: 8,
      md: 16,
      lg: 24,
      xl: 32,
      xxl: 48
    },
    typography: {
      fontFamily: {
        sans: 'System',
        mono: 'Menlo-Regular'
      },
      fontSize: {
        xs: 12,
        sm: 14,
        md: 16,
        lg: 18,
        xl: 20,
        xxl: 24
      },
      fontWeight: {
        normal: '400',
        medium: '500',
        bold: '700'
      }
    }
  };
  
  return fullTheme;
}

// Get the theme
themeApiRouter.get('/', async (req, res) => {
  try {
    // Read theme from theme.json
    const themePath = path.resolve(process.cwd(), 'theme.json');
    const themeData = fs.readFileSync(themePath, 'utf-8');
    const coreTheme = JSON.parse(themeData);
    
    // Derive the full theme with mobile-specific properties
    const fullTheme = deriveFullTheme(coreTheme);
    
    res.json(fullTheme);
  } catch (error) {
    console.error("Error fetching theme:", error);
    res.status(500).json({ message: "Error fetching theme" });
  }
});

// Update the theme (requires authentication)
themeApiRouter.put('/', async (req, res) => {
  try {
    // Check authentication
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    // Validate the theme data
    const { variant, primary, appearance, radius } = req.body;
    if (!variant || !primary || !appearance || radius === undefined) {
      return res.status(400).json({ message: "Invalid theme data" });
    }
    
    // Create the core theme object
    const coreTheme = {
      variant,
      primary,
      appearance,
      radius
    };
    
    // Write to theme.json
    const themePath = path.resolve(process.cwd(), 'theme.json');
    fs.writeFileSync(themePath, JSON.stringify(coreTheme, null, 2));
    
    // Return the full theme
    const fullTheme = deriveFullTheme(coreTheme);
    res.json(fullTheme);
  } catch (error) {
    console.error("Error updating theme:", error);
    res.status(500).json({ message: "Error updating theme" });
  }
});

export default themeApiRouter;