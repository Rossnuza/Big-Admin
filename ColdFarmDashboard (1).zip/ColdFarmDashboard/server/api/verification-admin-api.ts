import { Request, Response, Express } from "express";
import { storage } from "../storage";
import { generateVerificationCode, sendSMS } from "../utils/vonage-service";

// Configuration settings with default values
let verificationSettings = {
  brandName: "ColdFarms",
  codeLength: 4,
  pinExpiry: 300, // 5 minutes
  resendTimeout: 60, // 1 minute
  maxAttempts: 3
};

/**
 * Register verification admin API endpoints
 */
export default function registerVerificationAdminAPI(app: Express) {
  // Check if user is authenticated and is an admin
  const isAdmin = (req: Request, res: Response, next: Function) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    // For now, all authenticated users are admins
    // In a production app, you would check user roles
    next();
  };

  // Get verification logs with filtering options
  app.get('/api/admin/verification-logs', isAdmin, async (req: Request, res: Response) => {
    try {
      // Cast to the correct status type
      const statusParam = req.query.status as string;
      let status: 'initiated' | 'success' | 'failed' | 'cancelled' | undefined = undefined;
      
      if (statusParam) {
        if (['initiated', 'success', 'failed', 'cancelled'].includes(statusParam)) {
          status = statusParam as 'initiated' | 'success' | 'failed' | 'cancelled';
        } else {
          return res.status(400).json({ message: "Invalid status parameter" });
        }
      }
      
      // Get verification logs from activity logs
      const activities = await storage.getActivities(100);
      
      // Filter verification related activities
      const verificationLogs = activities.filter(activity => 
        activity.type === 'verification_sent' || 
        activity.type === 'verification_success' ||
        activity.type === 'verification_failed' ||
        activity.type === 'farmer_verified' ||
        activity.type === 'consumer_verified'
      );
      
      // Apply filters if provided
      let filteredLogs = verificationLogs;
      
      if (status) {
        filteredLogs = filteredLogs.filter(log => {
          if (status === 'initiated' && log.type === 'verification_sent') return true;
          if (status === 'success' && (log.type === 'verification_success' || log.type === 'farmer_verified' || log.type === 'consumer_verified')) return true;
          if (status === 'failed' && log.type === 'verification_failed') return true;
          return false;
        });
      }
      
      const phoneFilter = req.query.phone as string | undefined;
      if (phoneFilter) {
        filteredLogs = filteredLogs.filter(log => {
          const details = log.details as any;
          return details && details.phone && details.phone.includes(phoneFilter);
        });
      }
      
      const startDate = req.query.startDate ? new Date(req.query.startDate as string) : undefined;
      if (startDate) {
        filteredLogs = filteredLogs.filter(log => log.timestamp >= startDate);
      }
      
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : undefined;
      if (endDate) {
        filteredLogs = filteredLogs.filter(log => log.timestamp <= endDate);
      }
      
      res.json(filteredLogs);
    } catch (error: any) {
      console.error("Error fetching verification logs:", error);
      res.status(500).json({ message: error.message || "Failed to fetch verification logs" });
    }
  });

  // Get verification statistics
  app.get('/api/admin/verification-stats', isAdmin, async (req: Request, res: Response) => {
    try {
      // Get verification activities from activity logs
      const activities = await storage.getActivities(500);
      
      // Filter verification related activities
      const verificationActivities = activities.filter(activity => 
        activity.type === 'verification_sent' || 
        activity.type === 'verification_success' ||
        activity.type === 'verification_failed' ||
        activity.type === 'farmer_verified' ||
        activity.type === 'consumer_verified'
      );
      
      // Calculate stats
      const totalVerificationAttempts = verificationActivities.filter(a => 
        a.type === 'verification_sent'
      ).length;
      
      const successfulVerifications = verificationActivities.filter(a => 
        a.type === 'verification_success' || 
        a.type === 'farmer_verified' || 
        a.type === 'consumer_verified'
      ).length;
      
      const failedVerifications = verificationActivities.filter(a => 
        a.type === 'verification_failed'
      ).length;
      
      // Calculate success rate
      const successRate = totalVerificationAttempts > 0 
        ? (successfulVerifications / totalVerificationAttempts) * 100 
        : 0;
        
      // Get counts by day (last 7 days)
      const now = new Date();
      const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      
      const dailyCounts = [];
      for (let i = 0; i < 7; i++) {
        const date = new Date(sevenDaysAgo.getTime() + i * 24 * 60 * 60 * 1000);
        const dayStart = new Date(date.setHours(0, 0, 0, 0));
        const dayEnd = new Date(date.setHours(23, 59, 59, 999));
        
        const dayActivities = verificationActivities.filter(a => 
          a.timestamp >= dayStart && a.timestamp <= dayEnd
        );
        
        const sent = dayActivities.filter(a => a.type === 'verification_sent').length;
        const success = dayActivities.filter(a => 
          a.type === 'verification_success' || 
          a.type === 'farmer_verified' || 
          a.type === 'consumer_verified'
        ).length;
        const failed = dayActivities.filter(a => a.type === 'verification_failed').length;
        
        dailyCounts.push({
          date: dayStart.toISOString().split('T')[0],
          sent,
          success,
          failed
        });
      }
      
      // Return statistics
      res.json({
        totalVerificationAttempts,
        successfulVerifications,
        failedVerifications,
        successRate: successRate.toFixed(2) + '%',
        dailyCounts
      });
    } catch (error: any) {
      console.error("Error fetching verification stats:", error);
      res.status(500).json({ message: error.message || "Failed to fetch verification statistics" });
    }
  });

  // Get verification settings
  app.get('/api/admin/verification-settings', isAdmin, (req: Request, res: Response) => {
    try {
      res.json(verificationSettings);
    } catch (error: any) {
      console.error("Error fetching verification settings:", error);
      res.status(500).json({ message: error.message || "Failed to fetch verification settings" });
    }
  });

  // Update verification settings
  app.post('/api/admin/verification-settings', isAdmin, (req: Request, res: Response) => {
    try {
      const { brandName, codeLength, pinExpiry, resendTimeout, maxAttempts } = req.body;
      
      // Validate settings
      if (brandName && brandName.length > 11) {
        return res.status(400).json({ message: "Brand name cannot exceed 11 characters" });
      }
      
      if (codeLength && (codeLength < 4 || codeLength > 10)) {
        return res.status(400).json({ message: "Code length must be between 4 and 10" });
      }
      
      if (pinExpiry && (pinExpiry < 60 || pinExpiry > 900)) {
        return res.status(400).json({ message: "PIN expiry must be between 60 and 900 seconds" });
      }
      
      if (resendTimeout && (resendTimeout < 30 || resendTimeout > 300)) {
        return res.status(400).json({ message: "Resend timeout must be between 30 and 300 seconds" });
      }
      
      if (maxAttempts && (maxAttempts < 1 || maxAttempts > 10)) {
        return res.status(400).json({ message: "Max attempts must be between 1 and 10" });
      }
      
      // Update settings
      verificationSettings = {
        ...verificationSettings,
        brandName: brandName || verificationSettings.brandName,
        codeLength: codeLength || verificationSettings.codeLength,
        pinExpiry: pinExpiry || verificationSettings.pinExpiry,
        resendTimeout: resendTimeout || verificationSettings.resendTimeout,
        maxAttempts: maxAttempts || verificationSettings.maxAttempts
      };
      
      res.json({ message: "Settings updated successfully", settings: verificationSettings });
    } catch (error: any) {
      console.error("Error updating verification settings:", error);
      res.status(500).json({ message: error.message || "Failed to update verification settings" });
    }
  });

  // Test API connection
  app.get('/api/admin/verification-test-connection', isAdmin, async (req: Request, res: Response) => {
    try {
      // Check if Vonage API keys are configured
      if (!process.env.VONAGE_API_KEY || !process.env.VONAGE_API_SECRET) {
        return res.status(400).json({ 
          success: false, 
          message: "Vonage API credentials are not configured" 
        });
      }
      
      // For testing, we'll make a dummy request to validate credentials
      // Instead of sending a real SMS, we'll just check API connectivity
      const response = await fetch('https://api.nexmo.com/account/get-balance', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Basic ${Buffer.from(`${process.env.VONAGE_API_KEY}:${process.env.VONAGE_API_SECRET}`).toString('base64')}`
        }
      });
      
      const data = await response.json();
      
      if (response.ok) {
        return res.json({ 
          success: true, 
          message: "Successfully connected to Vonage API",
          balance: data.value,
          autoReload: data.autoReload
        });
      } else {
        return res.status(400).json({ 
          success: false, 
          message: data.error_text || "Failed to connect to Vonage API" 
        });
      }
    } catch (error: any) {
      console.error("Error testing Vonage API connection:", error);
      res.status(500).json({ 
        success: false, 
        message: error.message || "Failed to test Vonage API connection" 
      });
    }
  });

  // Cancel an ongoing verification
  app.post('/api/admin/verification-cancel', isAdmin, async (req: Request, res: Response) => {
    try {
      const { requestId, farmerId } = req.body;
      
      if (!farmerId && !requestId) {
        return res.status(400).json({ message: "Either Request ID or Farmer ID is required" });
      }
      
      // If request is by farmer ID
      if (farmerId) {
        const farmer = await storage.getFarmer(farmerId);
        if (!farmer) {
          return res.status(404).json({ message: "Farmer not found" });
        }
        
        // Update the farmer verification status to cancelled
        await storage.updateFarmerVerification(farmerId, "cancelled");
        
        // Create activity log
        await storage.createActivity({
          type: "verification_cancelled",
          description: `Verification for farmer ${farmer.name} cancelled by admin`,
          details: { 
            farmerId,
            phone: farmer.phone,
            adminAction: true
          },
          timestamp: new Date(),
          relatedId: farmerId,
          relatedType: "farmer"
        });
        
        return res.json({ message: "Farmer verification cancelled successfully" });
      }
      
      // For a pure request ID based approach, we can log it but can't actually cancel
      // the verification since we're not using Vonage Verify API directly
      await storage.createActivity({
        type: "verification_cancelled",
        description: `Verification request ${requestId} cancelled by admin`,
        details: { 
          requestId,
          adminAction: true
        },
        timestamp: new Date(),
        relatedType: "verification"
      });
      
      return res.json({ message: "Verification cancellation recorded" });
    } catch (error: any) {
      console.error("Error cancelling verification:", error);
      res.status(500).json({ message: error.message || "Failed to cancel verification" });
    }
  });

  // Manually trigger a verification code
  app.post('/api/admin/verification-send', isAdmin, async (req: Request, res: Response) => {
    try {
      const { phone, farmerId } = req.body;
      
      if (!phone) {
        return res.status(400).json({ message: "Phone number is required" });
      }
      
      // If farmerId is provided, check if the farmer exists
      if (farmerId) {
        const farmer = await storage.getFarmer(farmerId);
        if (!farmer) {
          return res.status(404).json({ message: "Farmer not found" });
        }
        
        // Generate a verification code
        const verificationCode = generateVerificationCode(verificationSettings.codeLength);
        
        // Update farmer with verification code
        await storage.updateFarmerVerification(
          farmerId, 
          "pending", 
          verificationCode
        );
        
        // Send SMS with verification code
        try {
          await sendSMS(
            phone,
            `Your Coldfarms verification code is: ${verificationCode}`
          );
          
          // Create activity log
          await storage.createActivity({
            type: "verification_sent",
            description: `Verification SMS sent to ${farmer.name}`,
            details: { 
              farmerId,
              phone,
              adminTriggered: true
            },
            timestamp: new Date(),
            relatedId: farmerId,
            relatedType: "farmer"
          });
          
          return res.json({ 
            message: "Verification code sent successfully",
            farmerId
          });
        } catch (error) {
          console.error("SMS sending error:", error);
          return res.status(500).json({ 
            error: "Could not send verification code SMS",
            verificationCode: process.env.NODE_ENV === "development" ? verificationCode : undefined
          });
        }
      } else {
        // Handle sending verification without a farmer ID
        // This is for testing purposes
        const verificationCode = generateVerificationCode(verificationSettings.codeLength);
        
        try {
          await sendSMS(
            phone,
            `Your Coldfarms test verification code is: ${verificationCode}`
          );
          
          // Create activity log
          await storage.createActivity({
            type: "verification_sent",
            description: `Test verification SMS sent to ${phone}`,
            details: { 
              phone,
              test: true,
              adminTriggered: true
            },
            timestamp: new Date(),
            relatedType: "verification"
          });
          
          return res.json({ 
            message: "Test verification code sent successfully"
          });
        } catch (error) {
          console.error("SMS sending error:", error);
          return res.status(500).json({ 
            error: "Could not send test verification code SMS",
            verificationCode: process.env.NODE_ENV === "development" ? verificationCode : undefined
          });
        }
      }
    } catch (error: any) {
      console.error("Error sending verification code:", error);
      res.status(500).json({ message: error.message || "Failed to send verification code" });
    }
  });
}