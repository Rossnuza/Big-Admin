import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Slider } from "@/components/ui/slider";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Save, RefreshCw } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";

// Form validation schema
const verificationSettingsSchema = z.object({
  brandName: z.string().min(1, "Brand name is required").max(11, "Brand name cannot exceed 11 characters"),
  codeLength: z.number().min(4).max(10),
  pinExpiry: z.number().min(60).max(900),
  resendTimeout: z.number().min(30).max(300),
  maxAttempts: z.number().min(1).max(10),
});

type VerificationSettings = z.infer<typeof verificationSettingsSchema>;

export default function VerificationSettings() {
  const { toast } = useToast();
  const [isTestingApi, setIsTestingApi] = useState(false);

  // Fetch current settings
  const { data: settings, isLoading } = useQuery({
    queryKey: ["/api/admin/verification-settings"],
    queryFn: async () => {
      const response = await fetch("/api/admin/verification-settings");
      if (!response.ok) throw new Error("Failed to fetch verification settings");
      return await response.json();
    },
  });

  // Form setup
  const form = useForm<VerificationSettings>({
    resolver: zodResolver(verificationSettingsSchema),
    defaultValues: {
      brandName: "ColdFarms",
      codeLength: 4,
      pinExpiry: 300,
      resendTimeout: 60,
      maxAttempts: 3,
    },
    values: settings,
  });

  // Update settings mutation
  const updateSettings = useMutation({
    mutationFn: async (data: VerificationSettings) => {
      return await apiRequest("POST", "/api/admin/verification-settings", data);
    },
    onSuccess: () => {
      toast({
        title: "Settings Updated",
        description: "Verification settings have been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/verification-settings"] });
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update verification settings.",
        variant: "destructive",
      });
    },
  });

  // Test API connection
  const testApiConnection = async () => {
    setIsTestingApi(true);
    try {
      const response = await fetch("/api/admin/verification-test-connection");
      const data = await response.json();
      
      if (data.success) {
        toast({
          title: "Connection Successful",
          description: "Successfully connected to Vonage API.",
        });
      } else {
        toast({
          title: "Connection Failed",
          description: data.message || "Failed to connect to Vonage API.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Connection Failed",
        description: "An error occurred while testing the connection.",
        variant: "destructive",
      });
    } finally {
      setIsTestingApi(false);
    }
  };

  // Handle form submission
  const onSubmit = (data: VerificationSettings) => {
    updateSettings.mutate(data);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>SMS Verification Settings</CardTitle>
        <CardDescription>
          Configure the Vonage SMS verification service parameters.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center py-6">
            <RefreshCw className="h-6 w-6 animate-spin text-primary" />
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid gap-6 md:grid-cols-2">
                <FormField
                  control={form.control}
                  name="brandName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Brand Name</FormLabel>
                      <FormControl>
                        <Input {...field} maxLength={11} />
                      </FormControl>
                      <FormDescription>
                        Appears in SMS messages (max 11 characters)
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="codeLength"
                  render={({ field: { value, onChange } }) => (
                    <FormItem>
                      <FormLabel>Code Length: {value} digits</FormLabel>
                      <FormControl>
                        <Slider
                          value={[value]}
                          min={4}
                          max={10}
                          step={1}
                          onValueChange={(values) => onChange(values[0])}
                        />
                      </FormControl>
                      <FormDescription>
                        Length of verification codes (4-10 digits)
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="pinExpiry"
                  render={({ field: { value, onChange } }) => (
                    <FormItem>
                      <FormLabel>
                        Code Expiry: {value} seconds ({Math.floor(value / 60)} minutes)
                      </FormLabel>
                      <FormControl>
                        <Slider
                          value={[value]}
                          min={60}
                          max={900}
                          step={30}
                          onValueChange={(values) => onChange(values[0])}
                        />
                      </FormControl>
                      <FormDescription>
                        How long a code remains valid (60-900 seconds)
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="resendTimeout"
                  render={({ field: { value, onChange } }) => (
                    <FormItem>
                      <FormLabel>
                        Resend Timeout: {value} seconds ({Math.floor(value / 60)} minutes)
                      </FormLabel>
                      <FormControl>
                        <Slider
                          value={[value]}
                          min={30}
                          max={300}
                          step={30}
                          onValueChange={(values) => onChange(values[0])}
                        />
                      </FormControl>
                      <FormDescription>
                        Minimum wait time between code resends (30-300 seconds)
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="maxAttempts"
                  render={({ field: { value, onChange } }) => (
                    <FormItem>
                      <FormLabel>Max Attempts: {value}</FormLabel>
                      <FormControl>
                        <Slider
                          value={[value]}
                          min={1}
                          max={10}
                          step={1}
                          onValueChange={(values) => onChange(values[0])}
                        />
                      </FormControl>
                      <FormDescription>
                        Maximum number of verification attempts (1-10)
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="md:col-span-2">
                  <div className="border rounded-md p-4 bg-muted/30">
                    <h3 className="text-sm font-medium mb-2">API Credentials</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      API credentials are stored securely as environment variables and cannot be viewed or edited here.
                    </p>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={testApiConnection}
                      disabled={isTestingApi}
                    >
                      {isTestingApi ? (
                        <>
                          <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                          Testing Connection...
                        </>
                      ) : (
                        "Test API Connection"
                      )}
                    </Button>
                  </div>
                </div>
              </div>

              <Button type="submit" disabled={updateSettings.isPending}>
                {updateSettings.isPending ? (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Save Settings
                  </>
                )}
              </Button>
            </form>
          </Form>
        )}
      </CardContent>
    </Card>
  );
}