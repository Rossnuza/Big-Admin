import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { format } from "date-fns";
import { CalendarIcon, RefreshCw } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Status badge color mapping
const statusColorMap: Record<string, string> = {
  initiated: "bg-blue-500",
  success: "bg-green-500",
  failed: "bg-red-500",
  cancelled: "bg-gray-500",
};

// SMS verification log component
export default function VerificationLogs() {
  // State for filters
  const [phoneFilter, setPhoneFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState<string | null>(null);
  const [startDate, setStartDate] = useState<Date | undefined>(undefined);
  const [endDate, setEndDate] = useState<Date | undefined>(undefined);

  // Fetch verification logs
  const { data: logs, isLoading, refetch } = useQuery({
    queryKey: ["/api/admin/verification-logs", phoneFilter, statusFilter, startDate, endDate],
    queryFn: async () => {
      // Build query parameters
      const params = new URLSearchParams();
      if (phoneFilter) params.append("phone", phoneFilter);
      if (statusFilter) params.append("status", statusFilter);
      if (startDate) params.append("startDate", startDate.toISOString());
      if (endDate) params.append("endDate", endDate.toISOString());
      
      // Fetch logs
      const response = await fetch(`/api/admin/verification-logs?${params.toString()}`);
      if (!response.ok) throw new Error("Failed to fetch verification logs");
      return await response.json();
    },
  });

  // Fetch statistics
  const { data: stats } = useQuery({
    queryKey: ["/api/admin/verification-stats"],
    queryFn: async () => {
      const response = await fetch("/api/admin/verification-stats");
      if (!response.ok) throw new Error("Failed to fetch verification statistics");
      return await response.json();
    },
  });

  // Reset filters
  const resetFilters = () => {
    setPhoneFilter("");
    setStatusFilter(null);
    setStartDate(undefined);
    setEndDate(undefined);
  };

  return (
    <div className="space-y-6">
      <Tabs defaultValue="logs">
        <TabsList className="grid w-[400px] grid-cols-2">
          <TabsTrigger value="logs">Verification Logs</TabsTrigger>
          <TabsTrigger value="stats">Statistics</TabsTrigger>
        </TabsList>

        <TabsContent value="logs" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>SMS Verification Logs</CardTitle>
              <CardDescription>
                Monitor phone verification activities and troubleshoot issues.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Filters */}
              <div className="flex flex-wrap gap-4 mb-6">
                <div className="flex-1 min-w-[200px]">
                  <label className="text-sm font-medium mb-1 block">
                    Phone Number
                  </label>
                  <Input
                    placeholder="Filter by phone"
                    value={phoneFilter}
                    onChange={(e) => setPhoneFilter(e.target.value)}
                  />
                </div>

                <div className="flex-1 min-w-[200px]">
                  <label className="text-sm font-medium mb-1 block">
                    Status
                  </label>
                  <select
                    className="w-full h-10 px-3 py-2 rounded-md border border-input bg-background"
                    value={statusFilter || ""}
                    onChange={(e) =>
                      setStatusFilter(
                        e.target.value ? e.target.value : null
                      )
                    }
                  >
                    <option value="">All statuses</option>
                    <option value="initiated">Initiated</option>
                    <option value="success">Success</option>
                    <option value="failed">Failed</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>

                <div className="flex-1 min-w-[200px]">
                  <label className="text-sm font-medium mb-1 block">
                    Start Date
                  </label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {startDate ? (
                          format(startDate, "PPP")
                        ) : (
                          <span>Pick a date</span>
                        )}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={startDate}
                        onSelect={setStartDate}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="flex-1 min-w-[200px]">
                  <label className="text-sm font-medium mb-1 block">
                    End Date
                  </label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {endDate ? (
                          format(endDate, "PPP")
                        ) : (
                          <span>Pick a date</span>
                        )}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={endDate}
                        onSelect={setEndDate}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="flex items-end gap-2 min-w-[180px]">
                  <Button onClick={() => refetch()}>
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Refresh
                  </Button>
                  <Button variant="outline" onClick={resetFilters}>
                    Reset
                  </Button>
                </div>
              </div>

              {/* Logs Table */}
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Phone</TableHead>
                      <TableHead>Farmer</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Request ID</TableHead>
                      <TableHead>Error</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoading ? (
                      <TableRow>
                        <TableCell
                          colSpan={6}
                          className="h-24 text-center"
                        >
                          Loading...
                        </TableCell>
                      </TableRow>
                    ) : logs && logs.length > 0 ? (
                      logs.map((log: any) => (
                        <TableRow key={log.id}>
                          <TableCell>
                            {format(new Date(log.createdAt), "MMM d, yyyy HH:mm")}
                          </TableCell>
                          <TableCell>{log.phone}</TableCell>
                          <TableCell>
                            {log.farmerName || "Unknown"}
                          </TableCell>
                          <TableCell>
                            <Badge
                              className={statusColorMap[log.status] || "bg-gray-500"}
                            >
                              {log.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="font-mono text-xs">
                            {log.requestId}
                          </TableCell>
                          <TableCell className="max-w-[200px] truncate">
                            {log.errorMessage || "-"}
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell
                          colSpan={6}
                          className="h-24 text-center"
                        >
                          No verification logs found.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="stats">
          <Card>
            <CardHeader>
              <CardTitle>SMS Verification Statistics</CardTitle>
              <CardDescription>
                Overview of verification success rates and usage.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Total Verifications
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {stats?.total || 0}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Successful Verifications
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-green-600">
                      {stats?.success || 0}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Failed Verifications
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-red-600">
                      {stats?.failed || 0}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Success Rate
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {stats ? `${(stats.successRate * 100).toFixed(1)}%` : "0%"}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}