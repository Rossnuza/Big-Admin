import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Package } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface InventorySummaryItem {
  productName: string;
  totalQuantity: number;
  unit: string;
  farmerCount: number;
}

interface StorageSummaryProps {
  storageUnitId: number;
}

export function StorageSummary({ storageUnitId }: StorageSummaryProps) {
  const { data: inventorySummary = [], isLoading } = useQuery<InventorySummaryItem[]>({
    queryKey: [`/api/storage-units/${storageUnitId}/inventory-summary`],
    enabled: !!storageUnitId,
  });

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-full" />
        <Skeleton className="h-8 w-full" />
        <Skeleton className="h-8 w-full" />
      </div>
    );
  }

  if (inventorySummary.length === 0) {
    return (
      <div className="text-center py-4">
        <p className="text-muted-foreground">No products stored in this unit.</p>
      </div>
    );
  }

  // Helper function to format quantities nicely
  const formatQuantity = (quantity: number, unit: string) => {
    // For kg/grams conversion
    if (unit.toLowerCase() === 'kg' && quantity >= 1000) {
      return `${(quantity / 1000).toFixed(1)} tons`;
    }
    
    // For liters conversion
    if ((unit.toLowerCase() === 'l' || unit.toLowerCase() === 'liter' || unit.toLowerCase() === 'liters') && quantity >= 1000) {
      return `${(quantity / 1000).toFixed(1)} kL`;
    }
    
    return `${quantity} ${unit}`;
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {inventorySummary.map((item) => (
          <div
            key={item.productName}
            className="bg-muted/40 rounded-md p-4 flex items-center justify-between hover:bg-muted transition-colors"
          >
            <div className="flex items-center space-x-3">
              <Package className="h-5 w-5 text-primary" />
              <div>
                <div className="font-medium">{item.productName}</div>
                <div className="text-sm text-muted-foreground">
                  Total: {formatQuantity(item.totalQuantity, item.unit)}
                </div>
              </div>
            </div>
            <Badge variant="outline">
              {item.farmerCount} farmer{item.farmerCount !== 1 ? 's' : ''}
            </Badge>
          </div>
        ))}
      </div>
    </div>
  );
}