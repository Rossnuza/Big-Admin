import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { SideBar } from "../dashboard/SideBar";
import { Header } from "../dashboard/Header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { StorageUnitForm } from "./StorageUnitForm";
import { queryClient } from "@/lib/queryClient";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { StorageUnit } from "@shared/schema";
import { Calendar, Package, Power, BarChart3, Edit, Trash2, ArrowLeft, Users, FileText } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { FarmersInventoryList } from "./FarmersInventoryList";
import { StorageSummary } from "./StorageSummary";

export function StorageUnitPage() {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  const { data: storageUnit, isLoading, error } = useQuery<StorageUnit>({
    queryKey: [`/api/storage-units/${id}`],
  });

  const deleteUnitMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/storage-units/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Storage unit deleted",
        description: "The storage unit has been deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/storage-units"] });
      setLocation("/storage-units");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to delete storage unit.",
        variant: "destructive",
      });
    },
  });

  const handleDelete = () => {
    deleteUnitMutation.mutate();
  };

  const formatDate = (date: Date | null | undefined) => {
    if (!date) return "Not scheduled";
    return new Date(date).toLocaleDateString();
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status.toLowerCase()) {
      case 'operational':
        return 'bg-green-100 text-success';
      case 'maintenance':
        return 'bg-yellow-100 text-warning';
      case 'offline':
        return 'bg-red-100 text-error';
      default:
        return 'bg-gray-100 text-gray-600';
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col md:flex-row">
        <SideBar />
        <main className="flex-1 overflow-x-hidden">
          <Header title="Storage Unit Details" />
          <div className="p-6">
            <div className="flex justify-center items-center h-64">
              <div className="text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
                <p className="mt-4 text-gray-500">Loading storage unit details...</p>
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (error || !storageUnit) {
    return (
      <div className="min-h-screen flex flex-col md:flex-row">
        <SideBar />
        <main className="flex-1 overflow-x-hidden">
          <Header title="Storage Unit Details" />
          <div className="p-6">
            <div className="flex justify-center items-center h-64">
              <div className="text-center">
                <p className="text-red-500">Error loading storage unit details.</p>
                <Button 
                  variant="outline" 
                  className="mt-4"
                  onClick={() => setLocation("/storage-units")}
                >
                  Go Back
                </Button>
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <SideBar />
      <main className="flex-1 overflow-x-hidden">
        <Header title="Storage Unit Details" />
        <div className="p-6">
          <div className="mb-6 flex items-center justify-between">
            <div className="flex items-center">
              <Button 
                variant="outline" 
                size="sm" 
                className="mr-4"
                onClick={() => setLocation("/storage-units")}
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
              <div>
                <h1 className="text-2xl font-bold">{storageUnit.unitId}</h1>
                <p className="text-gray-500">{storageUnit.location}</p>
              </div>
            </div>
            <div className="flex space-x-2">
              <Button 
                variant="outline" 
                onClick={() => setIsEditModalOpen(true)}
              >
                <Edit className="h-4 w-4 mr-2" />
                Edit
              </Button>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive">
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This action cannot be undone. This will permanently delete this storage unit
                      and remove all associated data.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleDelete}>
                      Delete
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <Badge className={getStatusBadgeVariant(storageUnit.status)}>
                    {storageUnit.status.charAt(0).toUpperCase() + storageUnit.status.slice(1)}
                  </Badge>
                  <div className="text-right">
                    <Badge variant="outline" className="bg-blue-50 text-blue-600">
                      Solar: {storageUnit.solarPanelStatus}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Current Temperature</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">
                  {storageUnit.temperature !== null ? `${storageUnit.temperature}°C` : "N/A"}
                </div>
                <p className="text-xs text-gray-500 mt-1">Optimal Range: 2°C - 5°C</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Battery Level</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Progress value={storageUnit.batteryLevel} className="h-2" />
                  <div className="text-right text-sm">{storageUnit.batteryLevel}%</div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <Card>
              <CardHeader>
                <div className="flex items-center">
                  <Package className="h-5 w-5 mr-2 text-primary" />
                  <CardTitle>Storage Capacity</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span>Current Usage</span>
                      <span className="font-medium">{Math.round((storageUnit.capacity / storageUnit.maxCapacity) * 100)}%</span>
                    </div>
                    <Progress 
                      value={(storageUnit.capacity / storageUnit.maxCapacity) * 100} 
                      className="h-2.5"
                    />
                  </div>
                  <div className="flex justify-between text-sm">
                    <div>
                      <p className="text-gray-500">Capacity</p>
                      <p className="font-medium">{storageUnit.capacity} units</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Maximum</p>
                      <p className="font-medium">{storageUnit.maxCapacity} units</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Available</p>
                      <p className="font-medium">{storageUnit.maxCapacity - storageUnit.capacity} units</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 mr-2 text-primary" />
                  <CardTitle>Maintenance Schedule</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-gray-500 text-sm">Last Maintenance</p>
                      <p className="font-medium">{formatDate(storageUnit.lastMaintenance)}</p>
                    </div>
                    <div>
                      <p className="text-gray-500 text-sm">Next Scheduled</p>
                      <p className="font-medium">{formatDate(storageUnit.nextMaintenance)}</p>
                    </div>
                  </div>
                  <Button variant="outline" className="w-full">
                    Schedule Maintenance
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 gap-6 mb-6">
            <Card>
              <CardHeader>
                <div className="flex items-center">
                  <FileText className="h-5 w-5 mr-2 text-primary" />
                  <CardTitle>Storage Unit Inventory Summary</CardTitle>
                </div>
                <CardDescription>Overview of all produce stored in this unit</CardDescription>
              </CardHeader>
              <CardContent>
                <StorageSummary storageUnitId={Number(id)} />
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 gap-6 mb-6">
            <Card>
              <CardHeader>
                <div className="flex items-center">
                  <Users className="h-5 w-5 mr-2 text-primary" />
                  <CardTitle>Farmers and Inventory</CardTitle>
                </div>
                <CardDescription>Farmers using this storage unit and their stored inventory</CardDescription>
              </CardHeader>
              <CardContent>
                <FarmersInventoryList storageUnitId={Number(id)} />
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <div className="flex items-center">
                <BarChart3 className="h-5 w-5 mr-2 text-primary" />
                <CardTitle>Performance History</CardTitle>
              </div>
              <CardDescription>30-day temperature and capacity history</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-center justify-center">
                <p className="text-gray-500">Historical data visualization will appear here.</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Edit Storage Unit Dialog */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Edit Storage Unit</DialogTitle>
          </DialogHeader>
          <StorageUnitForm 
            storageUnit={storageUnit}
            onSuccess={() => {
              setIsEditModalOpen(false);
              queryClient.invalidateQueries({ queryKey: [`/api/storage-units/${id}`] });
            }} 
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
