import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { format } from "date-fns";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { StorageUnit, Farmer, FarmerInventory } from "@shared/schema";
import { Thermometer, MapPin, Calendar, Users, Package, BarChart3 } from "lucide-react";

interface StorageUnitCardProps {
  storageUnit: StorageUnit;
}

export function StorageUnitCard({ storageUnit }: StorageUnitCardProps) {
  // Fetch farmers using this storage unit
  const { data: farmers = [] } = useQuery<Farmer[]>({
    queryKey: [`/api/storage-units/${storageUnit.id}/farmers`],
    enabled: !!storageUnit.id,
  });

  // Fetch inventory items in this storage unit
  const { data: inventoryItems = [] } = useQuery<(FarmerInventory & { farmerName: string })[]>({
    queryKey: [`/api/storage-units/${storageUnit.id}/inventory`],
    enabled: !!storageUnit.id,
  });

  // Fetch inventory summary
  const { data: inventorySummary = [] } = useQuery<{ productName: string; totalQuantity: number; unit: string; farmerCount: number }[]>({
    queryKey: [`/api/storage-units/${storageUnit.id}/inventory-summary`],
    enabled: !!storageUnit.id,
  });

  // Calculate usage based on the number of inventory items
  const usagePercentage = Math.min(
    100,
    Math.round((inventoryItems.length / (storageUnit.maxCapacity || 10)) * 100)
  );

  // Utility function to get status color
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "active":
        return "bg-green-100 text-green-800";
      case "maintenance":
        return "bg-amber-100 text-amber-800";
      case "offline":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  // Format the temperature display
  const formatTemp = (temp: number | null) => {
    return temp !== null ? `${temp}°C` : "N/A";
  };

  return (
    <Card className="overflow-hidden shadow-md h-full transition-all hover:shadow-lg">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-xl font-bold">{storageUnit.unitId}</CardTitle>
            <CardDescription className="flex items-center mt-1">
              <MapPin className="h-4 w-4 mr-1 text-muted-foreground" />
              {storageUnit.location}
            </CardDescription>
          </div>
          <Badge className={getStatusColor(storageUnit.status)}>
            {storageUnit.status}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="pb-3">
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <Thermometer className="h-5 w-5 mr-2 text-blue-500" />
              <span className="text-sm font-medium">Temperature</span>
            </div>
            <span className="text-sm font-semibold">
              {formatTemp(storageUnit.temperature)}
            </span>
          </div>

          <div className="flex flex-col gap-2">
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <BarChart3 className="h-5 w-5 mr-2 text-purple-500" />
                <span className="text-sm font-medium">Storage Usage</span>
              </div>
              <span className="text-sm font-semibold">{usagePercentage}%</span>
            </div>
            <Progress value={usagePercentage} className="h-2" />
          </div>

          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <Calendar className="h-5 w-5 mr-2 text-green-500" />
              <span className="text-sm font-medium">Last Maintained</span>
            </div>
            <span className="text-sm">
              {storageUnit.lastMaintenance
                ? format(new Date(storageUnit.lastMaintenance), "MMM d, yyyy")
                : "N/A"}
            </span>
          </div>

          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <Users className="h-5 w-5 mr-2 text-amber-500" />
              <span className="text-sm font-medium">Farmers</span>
            </div>
            <span className="text-sm font-semibold">{farmers.length}</span>
          </div>
        </div>

        {(inventorySummary.length > 0 || inventoryItems.length > 0) && (
          <Accordion type="single" collapsible className="mt-4 w-full">
            <AccordionItem value="inventory">
              <AccordionTrigger className="text-sm font-medium py-2">
                <div className="flex items-center">
                  <Package className="h-4 w-4 mr-2" />
                  Storage Contents
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-2">
                  {inventorySummary.map((item, index) => (
                    <div key={index} className="flex justify-between text-sm">
                      <span>{item.productName}</span>
                      <span>
                        {item.totalQuantity} {item.unit} ({item.farmerCount} farmer
                        {item.farmerCount !== 1 ? "s" : ""})
                      </span>
                    </div>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        )}
      </CardContent>
      <CardFooter className="pt-1">
        <Link href={`/storage-units/${storageUnit.id}`} className="text-sm font-medium text-primary hover:underline">
          View Details
        </Link>
      </CardFooter>
    </Card>
  );
}