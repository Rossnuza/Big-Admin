import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { StorageUnit } from "@shared/schema";
import { z } from "zod";
import { africanCountries, getCitiesByCountry, generateStorageUnitId, getCountryNames } from "@/lib/countries-cities";

interface StorageUnitFormProps {
  storageUnit?: StorageUnit;
  onSuccess?: () => void;
}

// First create a form schema specific for the frontend with string dates
const formSchema = z.object({
  unitId: z.string().min(1, "Unit ID is required"),
  location: z.string().min(1, "Location is required"),
  temperature: z.union([z.number(), z.null()]),
  capacity: z.number(),
  maxCapacity: z.number().min(1, "Maximum capacity must be at least 1"),
  status: z.string(),
  lastMaintenance: z.union([z.string(), z.null()]),
  nextMaintenance: z.union([z.string(), z.null()]),
  solarPanelStatus: z.string(),
  batteryLevel: z.number().min(0, "Battery level must be at least 0").max(100, "Battery level cannot exceed 100")
});

export function StorageUnitForm({ storageUnit, onSuccess }: StorageUnitFormProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState<string>("");
  const [availableCities, setAvailableCities] = useState<string[]>([]);
  const [selectedCity, setSelectedCity] = useState<string>("");
  
  // Fetch the count of storage units in the selected country and city for auto-generation
  const { data: unitCountData } = useQuery<{ count: number }>({
    queryKey: ['/api/storage-units/count-by-location', selectedCountry, selectedCity],
    queryFn: async () => {
      if (!selectedCountry || !selectedCity) return { count: 0 };
      const res = await fetch(`/api/storage-units/count-by-location?country=${selectedCountry}&city=${selectedCity}`);
      if (!res.ok) throw new Error('Failed to fetch unit count');
      return res.json();
    },
    enabled: !!selectedCountry && !!selectedCity, // Only run query when both country and city are selected
  });
  
  const unitCount = unitCountData?.count || 0;

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: storageUnit
      ? {
          ...storageUnit,
          lastMaintenance: storageUnit.lastMaintenance ? new Date(storageUnit.lastMaintenance).toISOString().split('T')[0] : null,
          nextMaintenance: storageUnit.nextMaintenance ? new Date(storageUnit.nextMaintenance).toISOString().split('T')[0] : null,
        }
      : {
          unitId: "",
          location: "",
          temperature: null,
          capacity: 0,
          maxCapacity: 100,
          status: "operational",
          lastMaintenance: null,
          nextMaintenance: null,
          solarPanelStatus: "operational",
          batteryLevel: 100,
        },
  });
  
  // When country changes, update available cities
  useEffect(() => {
    if (selectedCountry) {
      const cities = getCitiesByCountry(selectedCountry);
      setAvailableCities(cities);
      setSelectedCity(""); // Reset city when country changes
    } else {
      setAvailableCities([]);
      setSelectedCity("");
    }
  }, [selectedCountry]);
  
  // Auto-generate unit ID when country and city are selected
  useEffect(() => {
    if (selectedCountry && selectedCity && !storageUnit) {
      const generatedId = generateStorageUnitId(selectedCountry, selectedCity, unitCount + 1);
      form.setValue("unitId", generatedId);
      
      // Also update the location field
      form.setValue("location", `${selectedCity}, ${selectedCountry}`);
    }
  }, [selectedCountry, selectedCity, unitCount, form, storageUnit]);

  const mutation = useMutation({
    mutationFn: async (values: z.infer<typeof formSchema>) => {
      // Format dates correctly and handle temperature properly
      const payload = {
        ...values,
        // Convert string dates to Date objects or null
        lastMaintenance: values.lastMaintenance ? new Date(values.lastMaintenance) : null,
        nextMaintenance: values.nextMaintenance ? new Date(values.nextMaintenance) : null,
        // Ensure temperature is a proper number or null
        temperature: values.temperature === null || values.temperature === undefined ? null : Number(values.temperature),
        // Ensure numeric fields are numbers, not strings
        capacity: Number(values.capacity),
        maxCapacity: Number(values.maxCapacity),
        batteryLevel: Number(values.batteryLevel),
      };
      
      console.log("Submitting payload:", payload);
      
      if (storageUnit) {
        // Update existing storage unit
        return apiRequest("PUT", `/api/storage-units/${storageUnit.id}`, payload);
      } else {
        // Create new storage unit
        return apiRequest("POST", "/api/storage-units", payload);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/storage-units"] });
      toast({
        title: storageUnit ? "Storage Unit Updated" : "Storage Unit Created",
        description: storageUnit
          ? "The storage unit has been updated successfully."
          : "The storage unit has been created successfully.",
      });
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      console.error("Mutation error:", error);
      toast({
        title: "Error",
        description: `Failed to ${storageUnit ? "update" : "create"} storage unit: ${error.message}`,
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsSubmitting(false);
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    setIsSubmitting(true);
    mutation.mutate(values);
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        {!storageUnit && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Country</label>
              <Select
                value={selectedCountry}
                onValueChange={setSelectedCountry}
                disabled={!!storageUnit}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select country" />
                </SelectTrigger>
                <SelectContent>
                  {getCountryNames().map(country => (
                    <SelectItem key={country} value={country}>
                      {country}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Select the country where the storage unit is located
              </p>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">City</label>
              <Select
                value={selectedCity}
                onValueChange={setSelectedCity}
                disabled={!selectedCountry || !!storageUnit}
              >
                <SelectTrigger>
                  <SelectValue placeholder={selectedCountry ? "Select city" : "Select country first"} />
                </SelectTrigger>
                <SelectContent>
                  {availableCities.map(city => (
                    <SelectItem key={city} value={city}>
                      {city}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Select the city where the storage unit is located
              </p>
            </div>
          </div>
        )}
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="unitId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Unit ID</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="CSU-XXX" 
                    {...field} 
                    readOnly={!storageUnit && Boolean(selectedCountry && selectedCity)}
                    className={!storageUnit && Boolean(selectedCountry && selectedCity) ? "bg-muted cursor-not-allowed" : ""}
                  />
                </FormControl>
                {!storageUnit && (
                  <FormDescription>
                    {selectedCountry && selectedCity 
                      ? "ID is auto-generated based on country, city, and unit count" 
                      : "Select country and city to auto-generate ID"}
                  </FormDescription>
                )}
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="location"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Location</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="Market location" 
                    {...field} 
                    readOnly={!storageUnit && Boolean(selectedCountry && selectedCity)}
                    className={!storageUnit && Boolean(selectedCountry && selectedCity) ? "bg-muted cursor-not-allowed" : ""}
                  />
                </FormControl>
                {!storageUnit && (
                  <FormDescription>
                    {selectedCountry && selectedCity 
                      ? "Location is auto-filled based on selected city and country" 
                      : "Select country and city to auto-fill location"}
                  </FormDescription>
                )}
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="temperature"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Temperature (°C)</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    step="0.1"
                    placeholder="3.5"
                    {...field}
                    value={field.value === null ? "" : field.value}
                    onChange={(e) => {
                      const value = e.target.value === "" ? null : parseFloat(e.target.value);
                      field.onChange(value);
                    }}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Status</FormLabel>
                <Select
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="operational">Operational</SelectItem>
                    <SelectItem value="maintenance">Maintenance</SelectItem>
                    <SelectItem value="offline">Offline</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="capacity"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Current Capacity</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    placeholder="0"
                    {...field}
                    value={field.value}
                    onChange={(e) => field.onChange(parseInt(e.target.value))}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="maxCapacity"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Maximum Capacity</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    placeholder="100"
                    {...field}
                    value={field.value}
                    onChange={(e) => field.onChange(parseInt(e.target.value))}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="lastMaintenance"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Last Maintenance Date</FormLabel>
                <FormControl>
                  <Input
                    type="date"
                    onChange={field.onChange}
                    onBlur={field.onBlur}
                    ref={field.ref}
                    name={field.name}
                    value={typeof field.value === 'string' ? field.value : ""}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="nextMaintenance"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Next Maintenance Date</FormLabel>
                <FormControl>
                  <Input
                    type="date"
                    onChange={field.onChange}
                    onBlur={field.onBlur}
                    ref={field.ref}
                    name={field.name}
                    value={typeof field.value === 'string' ? field.value : ""}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="solarPanelStatus"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Solar Panel Status</FormLabel>
                <Select
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="operational">Operational</SelectItem>
                    <SelectItem value="maintenance">Maintenance</SelectItem>
                    <SelectItem value="offline">Offline</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="batteryLevel"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Battery Level (%)</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    placeholder="100"
                    min="0"
                    max="100"
                    {...field}
                    value={field.value}
                    onChange={(e) => field.onChange(parseInt(e.target.value))}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="flex justify-end space-x-2 pt-4">
          <Button 
            type="button" 
            variant="outline" 
            onClick={() => onSuccess && onSuccess()}
          >
            Cancel
          </Button>
          <Button 
            type="submit" 
            disabled={isSubmitting || !form.formState.isDirty}
          >
            {isSubmitting ? "Saving..." : "Save"}
          </Button>
        </div>
      </form>
    </Form>
  );
}