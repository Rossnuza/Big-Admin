import { useQuery } from "@tanstack/react-query";
import { Farmer, FarmerInventory } from "@shared/schema";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { format } from "date-fns";
import { User, Package, Calendar } from "lucide-react";

interface FarmersInventoryListProps {
  storageUnitId: number;
}

export function FarmersInventoryList({ storageUnitId }: FarmersInventoryListProps) {
  // Fetch farmers using this storage unit
  const { data: farmers = [], isLoading: farmersLoading } = useQuery<Farmer[]>({
    queryKey: [`/api/storage-units/${storageUnitId}/farmers`],
    enabled: !!storageUnitId,
  });

  // Fetch inventory items in this storage unit
  const { data: inventoryItems = [], isLoading: inventoryLoading } = useQuery<
    (FarmerInventory & { farmerName: string })[]
  >({
    queryKey: [`/api/storage-units/${storageUnitId}/inventory`],
    enabled: !!storageUnitId,
  });

  // Group inventory items by farmer ID
  const inventoryByFarmer: Record<number, (FarmerInventory & { farmerName: string })[]> = {};
  
  inventoryItems.forEach(item => {
    if (!inventoryByFarmer[item.farmerId]) {
      inventoryByFarmer[item.farmerId] = [];
    }
    inventoryByFarmer[item.farmerId].push(item);
  });

  const isLoading = farmersLoading || inventoryLoading;

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-full" />
        <Skeleton className="h-8 w-full" />
        <Skeleton className="h-8 w-full" />
      </div>
    );
  }

  if (farmers.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">No farmers are currently using this storage unit.</p>
      </div>
    );
  }

  return (
    <Accordion type="multiple" className="w-full">
      {farmers.map(farmer => {
        const farmerInventory = inventoryByFarmer[farmer.id] || [];
        
        return (
          <AccordionItem key={farmer.id} value={farmer.id.toString()}>
            <AccordionTrigger className="hover:no-underline">
              <div className="flex items-center text-left">
                <User className="h-5 w-5 mr-2 text-muted-foreground" />
                <div>
                  <div className="font-medium">{farmer.name}</div>
                  <div className="text-sm text-muted-foreground">{farmer.region}</div>
                </div>
                <Badge variant="outline" className="ml-4">
                  {farmerInventory.length} item{farmerInventory.length !== 1 ? 's' : ''}
                </Badge>
              </div>
            </AccordionTrigger>
            <AccordionContent>
              {farmerInventory.length === 0 ? (
                <div className="py-2 px-4 text-muted-foreground">
                  No inventory items found for this farmer.
                </div>
              ) : (
                <div className="space-y-3 py-2">
                  {farmerInventory.map(item => (
                    <div 
                      key={item.id} 
                      className="bg-muted/40 rounded-md p-3 hover:bg-muted transition-colors"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-3">
                          <Package className="h-5 w-5 mt-0.5 text-primary" />
                          <div>
                            <div className="font-medium">{item.productName}</div>
                            <div className="text-sm">
                              <span className="font-medium">{item.quantity} {item.unit}</span>
                              <span className="mx-2 text-muted-foreground">•</span>
                              <span className="text-muted-foreground">Status: {item.status}</span>
                            </div>
                            <div className="text-xs text-muted-foreground flex items-center mt-1">
                              <Calendar className="h-3 w-3 mr-1" />
                              From {format(new Date(item.startDate), "MMM d, yyyy")}
                              {item.endDate && ` to ${format(new Date(item.endDate), "MMM d, yyyy")}`}
                            </div>
                            {item.notes && (
                              <div className="text-xs italic mt-1 text-muted-foreground">
                                Note: {item.notes}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge
                            variant={item.dailyRate ? "default" : "outline"}
                            className="text-xs whitespace-nowrap"
                          >
                            {item.dailyRate ? "Daily Rate" : "Fixed Rate"}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  ))}
                  <div className="pt-2 text-right">
                    <Link 
                      href={`/farmers/${farmer.id}`} 
                      className="text-xs text-primary hover:underline"
                    >
                      View farmer details
                    </Link>
                  </div>
                </div>
              )}
            </AccordionContent>
          </AccordionItem>
        );
      })}
    </Accordion>
  );
}