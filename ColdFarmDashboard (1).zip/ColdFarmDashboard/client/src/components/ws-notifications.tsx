import { useEffect } from "react";
import { useWebSocket, WSMessage } from "@/lib/websocket-context";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import {
  FarmerRegisteredMessage,
  FarmerLoginMessage,
  BookingRequestCreatedMessage,
  BookingRequestApprovedMessage,
  BookingRequestRejectedMessage,
  BookingRequestDeletedMessage,
  InventoryCreatedMessage,
  InventoryUpdatedMessage,
  MarketplaceListingCreatedMessage,
  OrderCreatedMessage,
  OrderStatusChangedMessage
} from "@shared/websocket-types";

// Define our custom event type
interface WebSocketMessageEvent extends CustomEvent {
  detail: WSMessage;
}

/**
 * Component to handle WebSocket notifications and trigger UI updates
 * This is a "headless" component - it doesn't render any UI
 */
export function WebSocketNotifications() {
  const { connected, connecting } = useWebSocket();
  const { toast } = useToast();
  
  useEffect(() => {
    // This effect subscribes to our WebSocket context to receive messages
    // We'll implement a way to receive messages through our custom event
    const handleWebSocketMessage = (event: Event) => {
      try {
        // Cast to our custom event type
        const wsEvent = event as WebSocketMessageEvent;
        const message = wsEvent.detail;
        console.log("WebSocket message received:", message);
        
        // Handle different types of messages
        switch (message.type) {
          case "farmer_registered":
            // A new farmer has registered
            const farmerRegMsg = message as FarmerRegisteredMessage;
            toast({
              title: "New Farmer Registration",
              description: `${farmerRegMsg.farmerName || "A new farmer"} has registered from ${farmerRegMsg.farmerRegion || "unknown region"}`,
            });
            
            // Invalidate the farmers query to refresh data
            queryClient.invalidateQueries({ queryKey: ["/api/farmers"] });
            break;
            
          case "farmer_login":
            // A farmer has logged in
            const farmerLoginMsg = message as FarmerLoginMessage;
            toast({
              title: "Farmer Activity",
              description: `${farmerLoginMsg.farmerName || "A farmer"} has logged in`,
              variant: "default",
            });
            break;
            
          case "booking_request_created":
            // A new storage booking request has been created
            const bookingCreatedMsg = message as BookingRequestCreatedMessage;
            toast({
              title: "New Storage Booking",
              description: `A new storage booking request was submitted for ${bookingCreatedMsg.product || "products"}`,
            });
            
            // Invalidate storage bookings queries
            queryClient.invalidateQueries({ queryKey: ["/api/storage-bookings"] });
            break;
            
          case "booking_request_approved":
            // A storage booking request has been approved
            const bookingApprovedMsg = message as BookingRequestApprovedMessage;
            toast({
              title: "Booking Approved",
              description: `Booking request #${bookingApprovedMsg.bookingId} has been approved`,
              variant: "default",
            });
            
            // Invalidate storage bookings queries
            queryClient.invalidateQueries({ queryKey: ["/api/storage-bookings"] });
            break;
            
          case "booking_request_rejected":
            // A storage booking request has been rejected
            const bookingRejectedMsg = message as BookingRequestRejectedMessage;
            toast({
              title: "Booking Rejected",
              description: `Booking request #${bookingRejectedMsg.bookingId} has been rejected${bookingRejectedMsg.reason ? ': ' + bookingRejectedMsg.reason : ''}`,
              variant: "destructive",
            });
            
            // Invalidate storage bookings queries
            queryClient.invalidateQueries({ queryKey: ["/api/storage-bookings"] });
            break;
            
          case "booking_request_deleted":
            // A storage booking request has been deleted
            const bookingDeletedMsg = message as BookingRequestDeletedMessage;
            toast({
              title: "Booking Cancelled",
              description: `Booking request #${bookingDeletedMsg.bookingId} has been cancelled`,
              variant: "default",
            });
            
            // Invalidate storage bookings queries
            queryClient.invalidateQueries({ queryKey: ["/api/storage-bookings"] });
            break;
            
          case "inventory_created":
            // New inventory has been added
            const inventoryCreatedMsg = message as InventoryCreatedMessage;
            toast({
              title: "New Inventory",
              description: `${inventoryCreatedMsg.quantity} kg of ${inventoryCreatedMsg.productName} has been added to inventory`,
            });
            
            // Invalidate inventory queries
            queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
            break;
            
          case "inventory_updated":
            // Inventory has been updated
            const inventoryUpdatedMsg = message as InventoryUpdatedMessage;
            toast({
              title: "Inventory Updated",
              description: `Inventory item #${inventoryUpdatedMsg.inventoryId} has been updated`,
            });
            
            // Invalidate inventory queries
            queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
            break;
            
          case "marketplace_listing_created":
            // New marketplace listing
            const marketplaceListingMsg = message as MarketplaceListingCreatedMessage;
            toast({
              title: "New Marketplace Listing",
              description: `${marketplaceListingMsg.productName} has been listed on the marketplace for ${marketplaceListingMsg.pricePerKg} XAF/kg`,
            });
            
            // Invalidate marketplace queries
            queryClient.invalidateQueries({ queryKey: ["/api/marketplace"] });
            break;
            
          case "order_created":
            // New order
            const orderCreatedMsg = message as OrderCreatedMessage;
            toast({
              title: "New Order Received",
              description: `Order #${orderCreatedMsg.orderId} has been placed for ${orderCreatedMsg.totalAmount} XAF`,
              variant: "default",
            });
            
            // Invalidate orders queries
            queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
            break;
            
          case "order_status_changed":
            // Order status changed
            const orderStatusMsg = message as OrderStatusChangedMessage;
            toast({
              title: "Order Status Changed",
              description: `Order #${orderStatusMsg.orderId} is now ${orderStatusMsg.status}`,
            });
            
            // Invalidate orders queries
            queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
            break;
        }
      } catch (error) {
        console.error("Error handling WebSocket message:", error);
      }
    };
    
    // Only add the event listener if we're connected
    if (connected) {
      window.addEventListener('coldfarms:ws-message', handleWebSocketMessage as EventListener);
      
      return () => {
        window.removeEventListener('coldfarms:ws-message', handleWebSocketMessage as EventListener);
      };
    }
  }, [connected, toast]);
  
  // This component doesn't render anything
  return null;
}