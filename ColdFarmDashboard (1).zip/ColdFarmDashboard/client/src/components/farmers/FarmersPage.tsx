import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { SideBar } from "../dashboard/SideBar";
import { Header } from "../dashboard/Header";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { FarmerForm } from "./FarmerForm";
import { Farmer, FarmerInventory as FarmerInventoryType, Product } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuCheckboxItem
} from "@/components/ui/dropdown-menu";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarIcon, Eye, Filter, List, LayoutGrid, ListPlus, MapPin, Package, Phone, Plus, Search, MoreVertical, X } from "lucide-react";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { DataTable } from "@/components/ui/data-table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FarmerInventoryManager } from "./FarmerInventory";
import { Calendar } from "@/components/ui/calendar";
import { format } from "date-fns";
import { africanCountries, getCountryNames, getCitiesByCountry } from "@/lib/countries-cities";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

// Define interfaces for category and product types
interface Category {
  id: number;
  name: string;
  description: string;
  productCount: number;
}

interface ProductType {
  id: number;
  name: string;
  category: string;
  description: string;
  standardUnit: string;
}

// Define date filter options
interface DateFilterOption {
  label: string;
  value: string;
  filter: (date: Date) => boolean;
}

const dateFilterOptions: DateFilterOption[] = [
  {
    label: "All Time",
    value: "all",
    filter: () => true
  },
  {
    label: "Last 7 Days",
    value: "last7days",
    filter: (date: Date) => {
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
      return date >= sevenDaysAgo;
    }
  },
  {
    label: "Last 30 Days",
    value: "last30days",
    filter: (date: Date) => {
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      return date >= thirtyDaysAgo;
    }
  },
  {
    label: "Last 90 Days",
    value: "last90days",
    filter: (date: Date) => {
      const ninetyDaysAgo = new Date();
      ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
      return date >= ninetyDaysAgo;
    }
  },
  {
    label: "This Year",
    value: "thisYear",
    filter: (date: Date) => {
      const thisYear = new Date().getFullYear();
      return date.getFullYear() === thisYear;
    }
  }
];

export function FarmersPage() {
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [viewMode, setViewMode] = useState<"card" | "table">("card");
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedFarmer, setSelectedFarmer] = useState<Farmer | null>(null);
  const [isQuickViewOpen, setIsQuickViewOpen] = useState(false);
  const [isQuickAddInventoryOpen, setIsQuickAddInventoryOpen] = useState(false);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  
  // Enhanced filter state
  const [selectedCountry, setSelectedCountry] = useState<string>("");
  const [selectedCity, setSelectedCity] = useState<string>("");
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [selectedProduct, setSelectedProduct] = useState<string>("");
  const [selectedDateFilter, setSelectedDateFilter] = useState<string>("all");
  
  // Legacy filter state (for compatibility)
  const [selectedCities, setSelectedCities] = useState<string[]>([]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [dateFilter, setDateFilter] = useState<Date | undefined>(undefined);
  
  const [activeFiltersCount, setActiveFiltersCount] = useState(0);
  const pageSize = viewMode === "card" ? 9 : 10;

  const { data: farmers = [], isLoading } = useQuery<Farmer[]>({
    queryKey: ["/api/farmers"],
  });

  const { data: products = [] } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });
  
  // Fetch categories data from the categories system
  const { data: categoriesData = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  // Fetch product types based on selected category
  const { data: productTypes = [], isLoading: isProductTypesLoading } = useQuery<ProductType[]>({
    queryKey: ["/api/product-types", selectedCategory],
    queryFn: async () => {
      if (!selectedCategory) return [];
      const response = await fetch(`/api/product-types?category=${selectedCategory}`);
      if (!response.ok) {
        throw new Error("Failed to fetch product types");
      }
      return response.json();
    },
    enabled: !!selectedCategory,
  });
  
  // Get available countries and cities
  const countryNames = getCountryNames();
  const availableCities = selectedCountry ? getCitiesByCountry(selectedCountry) : [];

  // Legacy - Extract unique cities (regions) from farmers
  const farmersRegions = farmers.map(farmer => farmer.region);
  const uniqueCitiesSet = new Set(farmersRegions);
  const uniqueCities: string[] = Array.from(uniqueCitiesSet);
  
  // Legacy - Extract unique product categories
  const productCategories = products.map(product => product.category);
  const uniqueCategoriesSet = new Set(productCategories);
  const uniqueCategories: string[] = Array.from(uniqueCategoriesSet);

  // Update active filters count
  useEffect(() => {
    let count = 0;
    if (selectedCountry && selectedCountry !== "all_countries") count++;
    if (selectedCity && selectedCity !== "all_cities") count++;
    if (selectedCategory && selectedCategory !== "all_categories") count++;
    if (selectedProduct && selectedProduct !== "all_products") count++;
    if (selectedDateFilter !== "all") count++;
    setActiveFiltersCount(count);
  }, [selectedCountry, selectedCity, selectedCategory, selectedProduct, selectedDateFilter]);

  // Filter by all criteria with enhanced filters
  const filteredFarmers = farmers.filter(farmer => {
    // Search term filter
    const matchesSearch = 
      searchTerm === "" || 
      farmer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      farmer.region.toLowerCase().includes(searchTerm.toLowerCase()) ||
      farmer.contactPerson.toLowerCase().includes(searchTerm.toLowerCase()) ||
      farmer.email.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Location filters - use region for both country and city since we don't have a separate country field
    const matchesCountry = !selectedCountry || selectedCountry === "all_countries" || farmer.region.includes(selectedCountry);
    const matchesCity = !selectedCity || selectedCity === "all_cities" || farmer.region === selectedCity;
    
    // Date filter using predefined options
    const farmerJoinDate = new Date(farmer.joinDate);
    const matchesJoinDate = selectedDateFilter === "all" || 
      dateFilterOptions.find(opt => opt.value === selectedDateFilter)?.filter(farmerJoinDate) || false;
    
    // Category and product filters
    // This is a simplified version; ideally we would check farmer's inventory
    const matchesCategory = !selectedCategory || selectedCategory === "all_categories";
    const matchesProduct = !selectedProduct || selectedProduct === "all_products";
    
    return matchesSearch && matchesCountry && matchesCity && matchesJoinDate && 
           matchesCategory && matchesProduct;
  });

  // Pagination
  const totalItems = filteredFarmers.length;
  const paginatedFarmers = filteredFarmers.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  const handleSearch = (term: string) => {
    setSearchTerm(term);
    setCurrentPage(1);
  };

  const handleFarmerCardClick = (farmer: Farmer) => {
    setSelectedFarmer(farmer);
    setIsQuickViewOpen(true);
  };

  const handleAddInventoryClick = (farmer: Farmer, e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent card click event
    setSelectedFarmer(farmer);
    setIsQuickAddInventoryOpen(true);
  };
  
  const formatDate = (dateInput: string | Date) => {
    const date = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <SideBar />
      <main className="flex-1 overflow-x-hidden bg-gray-100">
        <Header title="Farmers" />
        <div className="p-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
            <h1 className="text-2xl font-bold">Manage Farmers</h1>
            
            {/* Search and Controls */}
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative flex-1 min-w-[200px]">
                <input
                  placeholder="Search farmers..."
                  className="h-9 rounded-md border border-input bg-background w-full pl-8 pr-3 py-2 text-sm outline-none"
                  value={searchTerm}
                  onChange={(e) => handleSearch(e.target.value)}
                />
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              </div>
              
              {/* Filter Dropdown */}
              <Popover open={isFilterOpen} onOpenChange={setIsFilterOpen}>
                <PopoverTrigger asChild>
                  <Button variant="outline" size="sm" className="h-9 px-3 relative">
                    <Filter className="h-4 w-4 mr-2" />
                    Filters
                    {activeFiltersCount > 0 && (
                      <span className="absolute -top-2 -right-2 bg-primary text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                        {activeFiltersCount}
                      </span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-80 p-0" align="end">
                  <div className="border-b px-3 py-2 flex items-center justify-between">
                    <h4 className="font-medium text-sm">Filter Options</h4>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => {
                        setSelectedCountry("");
                        setSelectedCity("");
                        setSelectedCategory("");
                        setSelectedProduct("");
                        setSelectedDateFilter("all");
                        setCurrentPage(1);
                      }}
                      className="h-7 px-2 text-xs"
                    >
                      <X className="h-3 w-3 mr-1" />
                      Reset All
                    </Button>
                  </div>
                  
                  <div className="p-3 space-y-4">
                    {/* Location Filters */}
                    <div>
                      <div className="flex items-center mb-2">
                        <MapPin className="h-3.5 w-3.5 mr-1.5 text-muted-foreground" />
                        <span className="text-xs font-medium">LOCATION</span>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <Select
                            value={selectedCountry}
                            onValueChange={(value) => {
                              setSelectedCountry(value);
                              setSelectedCity("");
                              setCurrentPage(1);
                            }}
                          >
                            <SelectTrigger className="h-8 text-xs">
                              <SelectValue placeholder="Country" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="all_countries">All Countries</SelectItem>
                              {countryNames.map(country => (
                                <SelectItem key={country} value={country}>{country}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div>
                          <Select
                            value={selectedCity}
                            onValueChange={(value) => {
                              setSelectedCity(value);
                              setCurrentPage(1);
                            }}
                            disabled={!selectedCountry}
                          >
                            <SelectTrigger className="h-8 text-xs">
                              <SelectValue placeholder="City" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="all_cities">All Cities</SelectItem>
                              {availableCities.map(city => (
                                <SelectItem key={city} value={city}>{city}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                    
                    {/* Product Filters */}
                    <div>
                      <div className="flex items-center mb-2">
                        <Package className="h-3.5 w-3.5 mr-1.5 text-muted-foreground" />
                        <span className="text-xs font-medium">PRODUCTS</span>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <Select
                            value={selectedCategory}
                            onValueChange={(value) => {
                              setSelectedCategory(value);
                              setSelectedProduct("");
                              setCurrentPage(1);
                            }}
                          >
                            <SelectTrigger className="h-8 text-xs">
                              <SelectValue placeholder="Category" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="all_categories">All Categories</SelectItem>
                              {categoriesData.map((category: Category) => (
                                <SelectItem key={category.id} value={category.name}>
                                  {category.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div>
                          <Select
                            value={selectedProduct}
                            onValueChange={(value) => {
                              setSelectedProduct(value);
                              setCurrentPage(1);
                            }}
                            disabled={!selectedCategory || isProductTypesLoading}
                          >
                            <SelectTrigger className="h-8 text-xs">
                              <SelectValue placeholder="Product" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="all_products">All Products</SelectItem>
                              {productTypes.map((product: ProductType) => (
                                <SelectItem key={product.id} value={product.name}>
                                  {product.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                    
                    {/* Date Filter */}
                    <div>
                      <div className="flex items-center mb-2">
                        <CalendarIcon className="h-3.5 w-3.5 mr-1.5 text-muted-foreground" />
                        <span className="text-xs font-medium">JOIN DATE</span>
                      </div>
                      
                      <Select
                        value={selectedDateFilter}
                        onValueChange={(value) => {
                          setSelectedDateFilter(value);
                          setCurrentPage(1);
                        }}
                      >
                        <SelectTrigger className="h-8 text-xs">
                          <SelectValue placeholder="Select time period" />
                        </SelectTrigger>
                        <SelectContent>
                          {dateFilterOptions.map(option => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  {/* Apply Button */}
                  <div className="p-3 border-t flex justify-end">
                    <Button 
                      onClick={() => setIsFilterOpen(false)}
                      size="sm"
                      className="h-8"
                    >
                      Apply Filters
                    </Button>
                  </div>
                </PopoverContent>
              </Popover>
              
              {/* View Mode Toggle */}
              <div className="border rounded-md overflow-hidden">
                <div className="flex h-9">
                  <Button 
                    variant={viewMode === "card" ? "default" : "ghost"}
                    size="sm"
                    className="rounded-none border-0 h-9 px-3"
                    onClick={() => setViewMode("card")}
                  >
                    <LayoutGrid className="w-4 h-4" />
                  </Button>
                  <div className="w-px bg-border"></div>
                  <Button 
                    variant={viewMode === "table" ? "default" : "ghost"}
                    size="sm"
                    className="rounded-none border-0 h-9 px-3"
                    onClick={() => setViewMode("table")}
                  >
                    <List className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              
              {/* Add Farmer Button */}
              <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
                <DialogTrigger asChild>
                  <Button size="sm" className="h-9">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Farmer
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[600px]">
                  <DialogHeader>
                    <DialogTitle>Add New Farmer</DialogTitle>
                  </DialogHeader>
                  <FarmerForm 
                    onSuccess={() => {
                      setIsAddModalOpen(false);
                    }} 
                  />
                </DialogContent>
              </Dialog>
            </div>
          </div>
          
          {/* Active Filters Display */}
          {activeFiltersCount > 0 && (
            <div className="mb-5 flex flex-wrap gap-2 items-center">              
              {selectedCountry && selectedCountry !== "all_countries" && (
                <Badge variant="outline" className="flex items-center gap-1 h-6 px-2 bg-primary-foreground">
                  <MapPin className="h-3 w-3 mr-1 text-muted-foreground" />
                  <span className="text-xs font-normal">{selectedCountry}</span>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-4 w-4 p-0 ml-1" 
                    onClick={() => setSelectedCountry("")}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </Badge>
              )}
              
              {selectedCity && selectedCity !== "all_cities" && (
                <Badge variant="outline" className="flex items-center gap-1 h-6 px-2 bg-primary-foreground">
                  <span className="text-xs font-normal">{selectedCity}</span>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-4 w-4 p-0 ml-1" 
                    onClick={() => setSelectedCity("")}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </Badge>
              )}
              
              {selectedCategory && selectedCategory !== "all_categories" && (
                <Badge variant="outline" className="flex items-center gap-1 h-6 px-2 bg-primary-foreground">
                  <Package className="h-3 w-3 mr-1 text-muted-foreground" />
                  <span className="text-xs font-normal">{selectedCategory}</span>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-4 w-4 p-0 ml-1" 
                    onClick={() => setSelectedCategory("")}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </Badge>
              )}
              
              {selectedProduct && selectedProduct !== "all_products" && (
                <Badge variant="outline" className="flex items-center gap-1 h-6 px-2 bg-primary-foreground">
                  <span className="text-xs font-normal">{selectedProduct}</span>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-4 w-4 p-0 ml-1" 
                    onClick={() => setSelectedProduct("")}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </Badge>
              )}
              
              {selectedDateFilter !== "all" && (
                <Badge variant="outline" className="flex items-center gap-1 h-6 px-2 bg-primary-foreground">
                  <CalendarIcon className="h-3 w-3 mr-1 text-muted-foreground" />
                  <span className="text-xs font-normal">
                    {dateFilterOptions.find(opt => opt.value === selectedDateFilter)?.label}
                  </span>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-4 w-4 p-0 ml-1" 
                    onClick={() => setSelectedDateFilter("all")}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </Badge>
              )}
              
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-6 px-2 text-xs"
                onClick={() => {
                  setSelectedCountry("");
                  setSelectedCity("");
                  setSelectedCategory("");
                  setSelectedProduct("");
                  setSelectedDateFilter("all");
                }}
              >
                Clear All
              </Button>
            </div>
          )}

          {viewMode === "card" ? (
            <>
              <div className="flex flex-col gap-4">
                {paginatedFarmers.map((farmer) => (
                  <Card 
                    key={farmer.id} 
                    className="cursor-pointer hover:shadow-md transition-all duration-200 w-full bg-white border-muted overflow-hidden"
                    onClick={() => handleFarmerCardClick(farmer)}
                  >
                    <div className="flex flex-col sm:flex-row p-4">
                      {/* Main Information */}
                      <div className="flex-1">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="text-lg font-semibold mb-1">{farmer.name}</h3>
                            <div className="flex items-center text-sm text-muted-foreground">
                              <MapPin className="h-3.5 w-3.5 mr-1 flex-shrink-0" />
                              <span>{farmer.region}</span>
                            </div>
                          </div>
                          
                          <div className="flex gap-1">
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              onClick={(e) => handleAddInventoryClick(farmer, e)}
                              title="Add Inventory Item"
                              className="h-8 w-8"
                            >
                              <ListPlus className="h-4 w-4 text-primary" />
                            </Button>
                            <Button variant="ghost" size="icon" asChild className="h-8 w-8">
                              <Link href={`/farmers/${farmer.id}`} onClick={(e) => e.stopPropagation()}>
                                <Eye className="h-4 w-4 text-accent" />
                              </Link>
                            </Button>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-3 mt-4">
                          <div>
                            <div className="text-xs text-muted-foreground">Contact Person</div>
                            <div className="text-sm font-medium truncate">{farmer.contactPerson}</div>
                          </div>
                          <div>
                            <div className="text-xs text-muted-foreground">Phone</div>
                            <div className="text-sm font-medium truncate">{farmer.phone}</div>
                          </div>
                          <div className="col-span-2 sm:col-span-1">
                            <div className="text-xs text-muted-foreground">Joined</div>
                            <div className="text-sm font-medium truncate">{formatDate(farmer.joinDate)}</div>
                          </div>
                        </div>
                        
                        <div className="flex flex-wrap mt-3 gap-2">
                          <Badge 
                            variant={farmer.marketplaceOptIn ? "default" : "secondary"} 
                            className="px-2 py-0.5 h-6 text-xs"
                          >
                            {farmer.marketplaceOptIn ? "Marketplace" : "Not in Marketplace"}
                          </Badge>
                          <Badge 
                            variant={farmer.storageAgreement ? "outline" : "secondary"} 
                            className="px-2 py-0.5 h-6 text-xs"
                          >
                            {farmer.storageAgreement ? "Active Agreement" : "No Agreement"}
                          </Badge>
                        </div>
                      </div>
                      
                      {/* Actions Section */}
                      <div className="flex items-end sm:items-center justify-between sm:justify-end mt-4 sm:mt-0 sm:ml-4 gap-2 sm:w-auto flex-shrink-0">
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={(e) => handleAddInventoryClick(farmer, e)}
                          className="text-xs h-8 px-3"
                        >
                          <Package className="h-3.5 w-3.5 mr-1.5" />
                          Inventory
                        </Button>
                        <Button 
                          variant="default" 
                          size="sm"
                          className="text-xs h-8 px-3"
                          asChild
                        >
                          <Link href={`/farmers/${farmer.id}`} onClick={(e) => e.stopPropagation()}>
                            Details
                          </Link>
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
              
              {totalItems > pageSize && (
                <div className="flex items-center justify-center space-x-2 mt-6">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
                    disabled={currentPage === 1}
                  >
                    Previous
                  </Button>
                  <div className="text-sm">
                    Page {currentPage} of {Math.ceil(totalItems / pageSize)}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage((prev) => Math.min(Math.ceil(totalItems / pageSize), prev + 1))}
                    disabled={currentPage === Math.ceil(totalItems / pageSize)}
                  >
                    Next
                  </Button>
                </div>
              )}
            </>
          ) : (
            <DataTable
              data={paginatedFarmers}
              columns={[
                {
                  header: "Farmer",
                  cell: (row) => (
                    <div>
                      <div className="font-medium">{row.name}</div>
                      <div className="text-sm text-gray-500">{row.region}</div>
                    </div>
                  ),
                },
                {
                  header: "Contact",
                  cell: (row) => (
                    <div>
                      <div>{row.contactPerson}</div>
                      <div className="text-sm text-gray-500">{row.phone}</div>
                    </div>
                  ),
                },
                {
                  header: "Email",
                  accessorKey: "email",
                },
                {
                  header: "Marketplace Opt-In",
                  cell: (row) => (
                    <Badge variant={row.marketplaceOptIn ? "default" : "outline"}>
                      {row.marketplaceOptIn ? "Opted In" : "Opted Out"}
                    </Badge>
                  ),
                },
                {
                  header: "Storage Agreement",
                  cell: (row) => (
                    <Badge variant={row.storageAgreement ? "default" : "outline"}>
                      {row.storageAgreement ? "Active" : "Inactive"}
                    </Badge>
                  ),
                },
                {
                  header: "Join Date",
                  cell: (row) => formatDate(row.joinDate),
                },
                {
                  header: "Actions",
                  cell: (row) => (
                    <div className="flex justify-end gap-1">
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => {
                          setSelectedFarmer(row);
                          setIsQuickAddInventoryOpen(true);
                        }}
                      >
                        <ListPlus className="h-4 w-4 text-primary" />
                      </Button>
                      <Button variant="ghost" size="icon" asChild>
                        <Link href={`/farmers/${row.id}`}>
                          <Eye className="h-4 w-4 text-accent" />
                        </Link>
                      </Button>
                    </div>
                  ),
                },
              ]}
              searchPlaceholder="Search farmers..."
              onSearch={handleSearch}
              pagination={{
                currentPage,
                pageSize,
                totalItems,
                onPageChange: setCurrentPage,
              }}
              isLoading={isLoading}
            />
          )}
        </div>
      </main>

      {/* Quick View Modal */}
      {selectedFarmer && (
        <Dialog open={isQuickViewOpen} onOpenChange={setIsQuickViewOpen}>
          <DialogContent className="sm:max-w-[700px]">
            <DialogHeader>
              <DialogTitle className="text-xl">
                {selectedFarmer.name}
              </DialogTitle>
            </DialogHeader>
            
            <Tabs defaultValue="info">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="info">Farmer Information</TabsTrigger>
                <TabsTrigger value="inventory">Quick Inventory</TabsTrigger>
              </TabsList>
              
              <TabsContent value="info" className="space-y-4 pt-4">
                <div className="grid grid-cols-2 gap-x-6 gap-y-4">
                  <div>
                    <div className="text-sm text-muted-foreground">Region</div>
                    <div className="font-medium mt-1">{selectedFarmer.region}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Contact Person</div>
                    <div className="font-medium mt-1">{selectedFarmer.contactPerson}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Phone</div>
                    <div className="font-medium mt-1 flex items-center">
                      <Phone className="h-3 w-3 mr-1" />
                      {selectedFarmer.phone}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Email</div>
                    <div className="font-medium mt-1 truncate">{selectedFarmer.email}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Join Date</div>
                    <div className="font-medium mt-1 flex items-center">
                      <Calendar className="h-3 w-3 mr-1" />
                      {formatDate(selectedFarmer.joinDate)}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div>
                      <div className="text-sm text-muted-foreground mb-1">Marketplace Status</div>
                      <Badge variant={selectedFarmer.marketplaceOptIn ? "default" : "outline"} className="py-1">
                        {selectedFarmer.marketplaceOptIn ? "Opted In" : "Opted Out"}
                      </Badge>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground mb-1">Agreement Status</div>
                      <Badge variant={selectedFarmer.storageAgreement ? "default" : "outline"} className="py-1">
                        {selectedFarmer.storageAgreement ? "Active" : "Inactive"}
                      </Badge>
                    </div>
                  </div>
                </div>
                
                <div className="mt-1 pb-2">
                  <div className="text-sm text-muted-foreground font-medium mb-2">Notes</div>
                  <div className="p-4 rounded-md bg-muted/50 border border-border text-sm">
                    {selectedFarmer.notes || "No notes available for this farmer."}
                  </div>
                </div>
                
                <div className="pt-4 flex justify-between">
                  <Button variant="ghost" onClick={() => setIsQuickViewOpen(false)}>
                    Close
                  </Button>
                  <div className="space-x-2">
                    <Button variant="outline" onClick={() => {
                      setIsQuickViewOpen(false);
                      setIsQuickAddInventoryOpen(true);
                    }}>
                      <Package className="h-4 w-4 mr-2" />
                      Manage Inventory
                    </Button>
                    <Button asChild>
                      <Link href={`/farmers/${selectedFarmer.id}`}>
                        <Eye className="h-4 w-4 mr-2" />
                        View Details
                      </Link>
                    </Button>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="inventory" className="py-4">
                <div className="text-sm text-muted-foreground mb-4">
                  Quick inventory management for {selectedFarmer.name}
                </div>
                <FarmerInventoryManager farmerId={selectedFarmer.id} />
              </TabsContent>
            </Tabs>
          </DialogContent>
        </Dialog>
      )}

      {/* Quick Add Inventory Modal */}
      {selectedFarmer && (
        <Dialog open={isQuickAddInventoryOpen} onOpenChange={setIsQuickAddInventoryOpen}>
          <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Manage Inventory - {selectedFarmer.name}</DialogTitle>
            </DialogHeader>
            <FarmerInventoryManager farmerId={selectedFarmer.id} />
            <div className="flex justify-end mt-4">
              <Button variant="outline" onClick={() => setIsQuickAddInventoryOpen(false)}>
                Close
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
