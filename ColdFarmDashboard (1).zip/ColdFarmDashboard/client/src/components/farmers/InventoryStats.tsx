import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Box, BarChart3, Package, Clock, Scale, Badge as BadgeIcon, AlertCircle } from "lucide-react";
import { FarmerInventory, StorageUnit } from "@shared/schema";
import { formatCurrency } from "@/lib/currency";

interface InventoryStatsProps {
  farmerId: number;
}

export function InventoryStats({ farmerId }: InventoryStatsProps) {
  // Fetch farmer's inventory data
  const { data: inventory = [], isLoading: isInventoryLoading } = useQuery<FarmerInventory[]>({
    queryKey: ["/api/farmers", farmerId, "inventory"],
    queryFn: async ({ queryKey }) => {
      const [_, id] = queryKey;
      const response = await fetch(`/api/farmers/${id}/inventory`);
      if (!response.ok) {
        throw new Error("Failed to fetch inventory data");
      }
      return response.json();
    },
  });

  // Fetch storage units data (needed for capacity calculations)
  const { data: storageUnits = [], isLoading: isUnitsLoading } = useQuery<StorageUnit[]>({
    queryKey: ["/api/storage-units"],
  });

  // Calculate statistics
  const totalItems = inventory.length;
  const activeItems = inventory.filter(item => item.status === "active").length;
  const activePercentage = totalItems > 0 ? Math.round((activeItems / totalItems) * 100) : 0;
  
  const totalQuantity = inventory.reduce((total, item) => total + item.quantity, 0);
  
  // Calculate average storage time in days
  const averageStorageTime = calculateAverageStorageTime(inventory);
  
  // Identify the most used storage unit
  const storageUnitUsage = inventory.reduce((acc, item) => {
    acc[item.storageUnitId] = (acc[item.storageUnitId] || 0) + 1;
    return acc;
  }, {} as Record<number, number>);
  
  const mostUsedUnitId = Object.entries(storageUnitUsage).sort((a, b) => b[1] - a[1])[0]?.[0];
  const mostUsedUnit = mostUsedUnitId 
    ? storageUnits.find(unit => unit.id === parseInt(mostUsedUnitId))
    : undefined;

  const isLoading = isInventoryLoading || isUnitsLoading;

  // Calculate storage costs based on quantity (10 XAF per kg)
  const storageCost = totalQuantity * 10; // 10 XAF per kg
  
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Items"
          value={totalItems.toString()}
          description={`${activeItems} active items (${activePercentage}%)`}
          icon={<Package className="h-5 w-5 text-primary" />}
          loading={isLoading}
        />
        
        <StatCard
          title="Total Quantity"
          value={`${totalQuantity} kg`}
          description="Combined inventory volume"
          icon={<Scale className="h-5 w-5 text-primary" />}
          loading={isLoading}
        />
        
        <StatCard
          title="Storage Cost"
          value={formatCurrency(storageCost, 'XAF')}
          description="Based on 10 XAF per kg"
          icon={<BadgeIcon className="h-5 w-5 text-primary" />}
          loading={isLoading}
        />
        
        <StatCard
          title="Average Storage Time"
          value={`${averageStorageTime} days`}
          description="Average time in storage"
          icon={<Clock className="h-5 w-5 text-primary" />}
          loading={isLoading}
        />
      </div>
      
      {totalItems > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Storage Utilization</CardTitle>
              <CardDescription>Distribution of inventory across storage units</CardDescription>
            </CardHeader>
            <CardContent>
              {Object.entries(storageUnitUsage).length > 0 ? (
                <div className="space-y-4">
                  {Object.entries(storageUnitUsage).map(([unitId, count]) => {
                    const unit = storageUnits.find(u => u.id === parseInt(unitId));
                    const percentage = Math.round((count / totalItems) * 100);
                    return (
                      <div key={unitId} className="space-y-1">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium">{unit?.unitId || `Unit ${unitId}`}</span>
                          <span className="text-sm text-muted-foreground">{count} items ({percentage}%)</span>
                        </div>
                        <Progress value={percentage} className="h-2" />
                        <p className="text-xs text-muted-foreground">{unit?.location || 'Unknown location'}</p>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-32 text-center">
                  <AlertCircle className="h-8 w-8 text-muted-foreground mb-2 opacity-50" />
                  <p className="text-sm text-muted-foreground">No storage data available</p>
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Inventory Status</CardTitle>
              <CardDescription>Status breakdown of inventory items</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Active Items</span>
                    <span className="text-sm text-muted-foreground">{activePercentage}%</span>
                  </div>
                  <Progress value={activePercentage} className="h-2" />
                </div>
                
                {/* Expired items */}
                {inventory.some(item => item.status === "expired") && (
                  <div className="space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Expired Items</span>
                      <span className="text-sm text-muted-foreground">
                        {Math.round((inventory.filter(item => item.status === "expired").length / totalItems) * 100)}%
                      </span>
                    </div>
                    <Progress 
                      value={Math.round((inventory.filter(item => item.status === "expired").length / totalItems) * 100)} 
                      className="h-2" 
                    />
                  </div>
                )}
                
                {/* Archived items */}
                {inventory.some(item => item.status === "archived") && (
                  <div className="space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Archived Items</span>
                      <span className="text-sm text-muted-foreground">
                        {Math.round((inventory.filter(item => item.status === "archived").length / totalItems) * 100)}%
                      </span>
                    </div>
                    <Progress 
                      value={Math.round((inventory.filter(item => item.status === "archived").length / totalItems) * 100)} 
                      className="h-2" 
                    />
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center p-8 bg-gray-50 rounded-lg border border-dashed text-center">
          <Box className="h-12 w-12 text-muted-foreground mb-3 opacity-30" />
          <h3 className="text-lg font-medium mb-1">No Inventory Items</h3>
          <p className="text-sm text-muted-foreground max-w-md mb-4">
            This farmer doesn't have any inventory items stored in cold storage units yet.
          </p>
        </div>
      )}
    </div>
  );
}

// Helper function to calculate average storage time
function calculateAverageStorageTime(inventory: FarmerInventory[]): number {
  if (inventory.length === 0) return 0;
  
  const now = new Date();
  const totalDays = inventory.reduce((total, item) => {
    const startDate = new Date(item.startDate);
    const endDate = item.endDate ? new Date(item.endDate) : now;
    const daysInStorage = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    return total + daysInStorage;
  }, 0);
  
  return Math.round(totalDays / inventory.length);
}

interface StatCardProps {
  title: string;
  value: string;
  description: string;
  icon: React.ReactNode;
  loading?: boolean;
}

function StatCard({ title, value, description, icon, loading = false }: StatCardProps) {
  return (
    <Card className="overflow-hidden border-0 shadow-sm">
      <CardContent className="p-0">
        {loading ? (
          <div className="animate-pulse p-6">
            <div className="rounded-full bg-slate-200 h-10 w-10 mb-3"></div>
            <div className="space-y-2">
              <div className="h-2 bg-slate-200 rounded w-1/3"></div>
              <div className="h-4 bg-slate-200 rounded w-3/4"></div>
              <div className="h-2 bg-slate-200 rounded w-1/2"></div>
            </div>
          </div>
        ) : (
          <div className="relative">
            <div className="absolute top-4 right-4 rounded-full bg-primary/10 p-2.5">
              {icon}
            </div>
            <div className="p-6 pt-16">
              <p className="text-sm font-medium text-muted-foreground mb-1">{title}</p>
              <p className="text-2xl font-bold">{value}</p>
              <p className="text-xs text-muted-foreground mt-1">{description}</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}