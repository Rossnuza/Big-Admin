import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { FarmerInventoryManager } from "./FarmerInventory";
import { InventoryStats } from "./InventoryStats";
import { StorageBilling } from "../finance/StorageBilling";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { CalendarDays, Mail, Phone, MapPin, ChevronLeft, Edit, User, Briefcase, Home, Calendar as CalendarIcon, Trash2 } from "lucide-react";
import { Farmer } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { FarmerForm } from "./FarmerForm";
import { format } from "date-fns";
import { apiRequest } from "@/lib/queryClient";

interface FarmerDetailProps {
  farmerId: number;
  onBack: () => void;
}

export function FarmerDetail({ farmerId, onBack }: FarmerDetailProps) {
  const { toast } = useToast();
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");
  const [_, setLocation] = useLocation();
  const queryClient = useQueryClient();
  
  const { data: farmer, isLoading, error } = useQuery<Farmer>({
    queryKey: ["/api/farmers", farmerId],
    queryFn: async ({ queryKey }) => {
      const [_, id] = queryKey;
      const response = await fetch(`/api/farmers/${id}`);
      if (!response.ok) {
        throw new Error("Failed to fetch farmer details");
      }
      return response.json();
    },
  });
  
  // Delete farmer mutation
  const deleteFarmerMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("DELETE", `/api/farmers/${farmerId}`);
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to delete farmer");
      }
      return response.json();
    },
    onSuccess: () => {
      // Show success message
      toast({
        title: "Farmer Deleted",
        description: "Farmer has been successfully deleted.",
      });
      
      // Invalidate farmer queries to refresh the data
      queryClient.invalidateQueries({ queryKey: ["/api/farmers"] });
      
      // Navigate back to farmers list
      setLocation("/farmers");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete farmer",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error || !farmer) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh]">
        <h2 className="text-2xl font-bold text-center mb-4">Error Loading Farmer</h2>
        <p className="text-center text-gray-600 mb-6">
          {error ? error.message : "Farmer not found"}
        </p>
        <Button onClick={onBack}>
          <ChevronLeft className="h-4 w-4 mr-2" />
          Back to Farmers
        </Button>
      </div>
    );
  }
  
  // Format join date for display
  const formattedJoinDate = new Date(farmer.joinDate).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
  
  // Format join date as short version
  const shortJoinDate = new Date(farmer.joinDate).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });

  return (
    <div className="space-y-6">
      {/* Back button */}
      <div className="flex justify-between items-center">
        <Button variant="outline" onClick={onBack}>
          <ChevronLeft className="h-4 w-4 mr-2" />
          Back to Farmers
        </Button>
        
        <div className="flex space-x-2">
          {/* Delete Farmer Button with Alert Dialog */}
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" size="sm">
                <Trash2 className="h-4 w-4 mr-2" />
                Delete Farmer
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you sure you want to delete this farmer?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. This will permanently delete the farmer
                  and all associated data including inventory records.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction 
                  onClick={() => deleteFarmerMutation.mutate()}
                  className="bg-destructive hover:bg-destructive/90"
                  disabled={deleteFarmerMutation.isPending}
                >
                  {deleteFarmerMutation.isPending ? "Deleting..." : "Delete Farmer"}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
          
          {/* Edit Farmer Dialog */}
          <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                <Edit className="h-4 w-4 mr-2" />
                Edit Farmer
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Edit Farmer</DialogTitle>
                <DialogDescription>Make changes to the farmer's information</DialogDescription>
              </DialogHeader>
              <FarmerForm 
                farmer={farmer}
                onSuccess={() => {
                  setIsEditModalOpen(false);
                  toast({
                    title: "Farmer Updated",
                    description: "Farmer details have been successfully updated.",
                  });
                }} 
              />
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      {/* Farmer Info Header - Card style layout */}
      <Card className="border-0 shadow-md">
        <CardHeader className="pb-2">
          <div className="flex flex-row justify-between items-start">
            <div>
              <CardTitle className="text-2xl font-bold">{farmer.name}</CardTitle>
              <CardDescription>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="link" className="h-auto p-0 text-sm text-muted-foreground font-normal flex items-center mt-1">
                      <CalendarDays className="h-4 w-4 mr-1.5" />
                      <span>Joined {shortJoinDate}</span>
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar 
                      mode="single"
                      selected={new Date(farmer.joinDate)}
                      defaultMonth={new Date(farmer.joinDate)}
                      disabled
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </CardDescription>
            </div>
            <div className="flex flex-wrap gap-2">
              <Badge variant={farmer.marketplaceOptIn ? "default" : "outline"} className="whitespace-nowrap">
                {farmer.marketplaceOptIn ? "Marketplace: Opted In" : "Marketplace: Opted Out"}
              </Badge>
              <Badge variant={farmer.storageAgreement ? "default" : "outline"} className="whitespace-nowrap">
                {farmer.storageAgreement ? "Storage Agreement: Active" : "Storage Agreement: Inactive"}
              </Badge>
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-y-4 gap-x-6 py-2">
            <div className="space-y-1.5">
              <h3 className="text-sm font-medium text-muted-foreground">Location</h3>
              <div className="flex items-center">
                <MapPin className="h-4 w-4 mr-1.5 text-muted-foreground" />
                <span className="text-sm font-medium">{farmer.region}</span>
              </div>
            </div>
            
            <div className="space-y-1.5">
              <h3 className="text-sm font-medium text-muted-foreground">Contact Person</h3>
              <div className="flex items-center">
                <User className="h-4 w-4 mr-1.5 text-muted-foreground" />
                <span className="text-sm font-medium">{farmer.contactPerson}</span>
              </div>
            </div>
            
            <div className="space-y-1.5">
              <h3 className="text-sm font-medium text-muted-foreground">Business Type</h3>
              <div className="flex items-center">
                <Briefcase className="h-4 w-4 mr-1.5 text-muted-foreground" />
                <span className="text-sm font-medium">{"Farming"}</span>
              </div>
            </div>
            
            <div className="space-y-1.5">
              <h3 className="text-sm font-medium text-muted-foreground">Email</h3>
              <div className="flex items-center">
                <Mail className="h-4 w-4 mr-1.5 text-muted-foreground" />
                <a href={`mailto:${farmer.email}`} className="text-sm font-medium hover:underline">{farmer.email}</a>
              </div>
            </div>
            
            <div className="space-y-1.5">
              <h3 className="text-sm font-medium text-muted-foreground">Phone</h3>
              <div className="flex items-center">
                <Phone className="h-4 w-4 mr-1.5 text-muted-foreground" />
                <a href={`tel:${farmer.phone}`} className="text-sm font-medium hover:underline">{farmer.phone}</a>
              </div>
            </div>
            
            <div className="space-y-1.5">
              <h3 className="text-sm font-medium text-muted-foreground">Address</h3>
              <div className="flex items-center">
                <Home className="h-4 w-4 mr-1.5 text-muted-foreground" />
                <span className="text-sm font-medium">{farmer.region}</span>
              </div>
            </div>
          </div>
          
          {farmer.notes && (
            <>
              <Separator className="my-4" />
              <div className="space-y-1.5">
                <h3 className="text-sm font-medium text-muted-foreground">Notes</h3>
                <p className="text-sm">{farmer.notes}</p>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Tabs for different sections */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="pt-4">
        <TabsList className="w-full justify-start mb-6 bg-transparent p-0 border-b">
          <TabsTrigger 
            value="overview" 
            className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:shadow-none"
          >
            Overview
          </TabsTrigger>
          <TabsTrigger 
            value="inventory" 
            className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:shadow-none"
          >
            Inventory Management
          </TabsTrigger>
          <TabsTrigger 
            value="billing" 
            className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:shadow-none"
          >
            Storage Billing
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="mt-0 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Inventory Statistics</CardTitle>
              <CardDescription>Overview of current inventory and storage usage</CardDescription>
            </CardHeader>
            <CardContent>
              <InventoryStats farmerId={farmer.id} />
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="inventory" className="mt-0">
          <FarmerInventoryManager farmerId={farmer.id} />
        </TabsContent>
        
        <TabsContent value="billing" className="mt-0">
          <StorageBilling farmerId={farmer.id} />
        </TabsContent>
      </Tabs>
    </div>
  );
}