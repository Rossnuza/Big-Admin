import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { CalendarIcon, Plus } from "lucide-react";
import { FarmerInventory as FarmerInventoryType, StorageUnit as StorageUnitType } from "@shared/schema";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

// Form validation schema
const formSchema = z.object({
  productName: z.string().min(2, "Product name must be at least 2 characters"),
  quantity: z.coerce.number().positive("Quantity must be a positive number"),
  unit: z.string().min(1, "Unit is required"),
  storageUnitId: z.coerce.number().positive("Storage unit is required"),
  startDate: z.date({
    required_error: "Start date is required",
  }),
  endDate: z.date().nullable().optional(),
  dailyRate: z.boolean().default(false),
  status: z.string().default("active"),
  notes: z.string().nullable().optional(),
});

type FormValues = z.infer<typeof formSchema>;

interface InventoryItem {
  id: number;
  farmerId: number;
  storageUnitId: number;
  productName: string;
  quantity: number;
  unit: string;
  startDate: string;
  endDate: string | null;
  dailyRate: boolean;
  status: string;
  notes: string | null;
}

interface StorageUnit {
  id: number;
  unitId: string;
  location: string;
  status: string;
}

interface Category {
  id: number;
  name: string;
  description: string;
  productCount: number;
}

interface ProductType {
  id: number;
  name: string;
  category: string;
  description: string;
  standardUnit: string;
}

interface FarmerInventoryProps {
  farmerId: number;
}

export function FarmerInventoryManager({ farmerId }: FarmerInventoryProps) {
  const { toast } = useToast();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [selectedProductType, setSelectedProductType] = useState<ProductType | null>(null);

  // Fetch farmer's inventory
  const { data: inventory = [], isLoading: isInventoryLoading, refetch } = useQuery<InventoryItem[]>({
    queryKey: ["/api/farmers", farmerId, "inventory"],
    queryFn: async ({ queryKey }) => {
      const [_, id] = queryKey;
      const response = await fetch(`/api/farmers/${id}/inventory`);
      if (!response.ok) {
        throw new Error("Failed to fetch inventory data");
      }
      return response.json();
    },
  });

  // Fetch available storage units
  const { data: storageUnits = [], isLoading: isUnitsLoading } = useQuery<StorageUnitType[]>({
    queryKey: ["/api/storage-units"],
  });
  
  // Fetch categories
  const { data: categories = [], isLoading: isCategoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
    queryFn: async () => {
      const response = await fetch("/api/categories");
      if (!response.ok) {
        throw new Error("Failed to fetch categories");
      }
      return response.json();
    },
  });
  
  // Fetch product types
  const { data: productTypes = [], isLoading: isProductTypesLoading } = useQuery<ProductType[]>({
    queryKey: ["/api/product-types"],
    queryFn: async () => {
      const response = await fetch("/api/product-types");
      if (!response.ok) {
        throw new Error("Failed to fetch product types");
      }
      return response.json();
    },
  });
  
  // Filter product types based on selected category
  const filteredProductTypes = selectedCategory 
    ? productTypes.filter(product => product.category === selectedCategory)
    : [];

  // Helper function to convert units to kg
  const convertToKg = (quantity: number, unit: string): number => {
    if (unit === "kg") return quantity;
    if (unit === "tons") return quantity * 1000; // 1 ton = 1000 kg
    return quantity; // Default case - no conversion
  };

  // Create new inventory item
  const createMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      // Convert units to kg if necessary
      const finalQuantity = convertToKg(data.quantity, data.unit);
      const finalUnit = "kg"; // Always store as kg

      const response = await fetch(`/api/farmers/${farmerId}/inventory`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...data,
          farmerId,
          quantity: finalQuantity,
          unit: finalUnit, // Always store as kg regardless of input unit
          startDate: data.startDate.toISOString(),
          endDate: data.endDate ? data.endDate.toISOString() : null,
        }),
      });

      if (!response.ok) {
        try {
          const errorData = await response.json();
          throw new Error(errorData.message || "Failed to create inventory item");
        } catch (parseError) {
          throw new Error(`Failed to create inventory item: ${response.status} ${response.statusText}`);
        }
      }

      return await response.json();
    },
    onSuccess: (newItem) => {
      // Invalidate the farmer's inventory queries
      queryClient.invalidateQueries({ queryKey: ["/api/farmers", farmerId, "inventory"] });
      
      // Also invalidate the related storage unit queries to update data there
      if (newItem && newItem.storageUnitId) {
        queryClient.invalidateQueries({ queryKey: [`/api/storage-units/${newItem.storageUnitId}/farmers`] });
        queryClient.invalidateQueries({ queryKey: [`/api/storage-units/${newItem.storageUnitId}/inventory`] });
        queryClient.invalidateQueries({ queryKey: [`/api/storage-units/${newItem.storageUnitId}/inventory-summary`] });
      }
      
      setIsAddModalOpen(false);
      toast({
        title: "Inventory Item Added",
        description: "The inventory item has been successfully added.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Add Item",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update existing inventory item
  const updateMutation = useMutation({
    mutationFn: async (data: FormValues & { id: number }) => {
      const { id, ...updateData } = data;
      
      // Convert units to kg if necessary
      const finalQuantity = convertToKg(updateData.quantity, updateData.unit);
      const finalUnit = "kg"; // Always store as kg
      
      const response = await fetch(`/api/farmers/${farmerId}/inventory/${id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...updateData,
          quantity: finalQuantity,
          unit: finalUnit, // Always store as kg
          startDate: updateData.startDate.toISOString(),
          endDate: updateData.endDate ? updateData.endDate.toISOString() : null,
        }),
      });

      if (!response.ok) {
        try {
          const errorData = await response.json();
          throw new Error(errorData.message || "Failed to update inventory item");
        } catch (parseError) {
          throw new Error(`Failed to update inventory item: ${response.status} ${response.statusText}`);
        }
      }

      return await response.json();
    },
    onSuccess: (updatedItem) => {
      // Invalidate farmer inventory queries
      queryClient.invalidateQueries({ queryKey: ["/api/farmers", farmerId, "inventory"] });
      
      // Also invalidate storage unit queries
      if (updatedItem && updatedItem.storageUnitId) {
        queryClient.invalidateQueries({ queryKey: [`/api/storage-units/${updatedItem.storageUnitId}/farmers`] });
        queryClient.invalidateQueries({ queryKey: [`/api/storage-units/${updatedItem.storageUnitId}/inventory`] });
        queryClient.invalidateQueries({ queryKey: [`/api/storage-units/${updatedItem.storageUnitId}/inventory-summary`] });
      }
      
      // If the storage unit was changed, also invalidate the old storage unit's queries
      if (selectedItem && selectedItem.storageUnitId && selectedItem.storageUnitId !== updatedItem?.storageUnitId) {
        queryClient.invalidateQueries({ queryKey: [`/api/storage-units/${selectedItem.storageUnitId}/farmers`] });
        queryClient.invalidateQueries({ queryKey: [`/api/storage-units/${selectedItem.storageUnitId}/inventory`] });
        queryClient.invalidateQueries({ queryKey: [`/api/storage-units/${selectedItem.storageUnitId}/inventory-summary`] });
      }
      
      setIsEditModalOpen(false);
      toast({
        title: "Inventory Item Updated",
        description: "The inventory item has been successfully updated.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Update Item",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Delete inventory item
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/farmers/${farmerId}/inventory/${id}`, {
        method: "DELETE",
      });

      if (!response.ok) {
        try {
          const errorData = await response.json();
          throw new Error(errorData.message || "Failed to delete inventory item");
        } catch (parseError) {
          throw new Error(`Failed to delete inventory item: ${response.status} ${response.statusText}`);
        }
      }

      return true;
    },
    onSuccess: () => {
      // Invalidate farmer inventory queries
      queryClient.invalidateQueries({ queryKey: ["/api/farmers", farmerId, "inventory"] });
      
      // Also invalidate the storage unit queries
      if (selectedItem && selectedItem.storageUnitId) {
        queryClient.invalidateQueries({ queryKey: [`/api/storage-units/${selectedItem.storageUnitId}/farmers`] });
        queryClient.invalidateQueries({ queryKey: [`/api/storage-units/${selectedItem.storageUnitId}/inventory`] });
        queryClient.invalidateQueries({ queryKey: [`/api/storage-units/${selectedItem.storageUnitId}/inventory-summary`] });
      }
      
      setIsDeleteModalOpen(false);
      setSelectedItem(null);
      toast({
        title: "Inventory Item Deleted",
        description: "The inventory item has been successfully deleted.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Delete Item",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      productName: "",
      quantity: 1,
      unit: "kg",
      storageUnitId: storageUnits.length > 0 ? storageUnits[0].id : 1,
      startDate: new Date(),
      endDate: null,
      dailyRate: false,
      status: "active",
      notes: "",
    },
  });

  const editForm = useForm<FormValues & { id: number }>({
    resolver: zodResolver(formSchema.extend({ id: z.number() })),
    defaultValues: {
      id: 0,
      productName: "",
      quantity: 1,
      unit: "kg",
      storageUnitId: storageUnits.length > 0 ? storageUnits[0].id : 1,
      startDate: new Date(),
      endDate: null,
      dailyRate: false,
      status: "active",
      notes: "",
    },
  });

  const onSubmit = async (values: FormValues) => {
    createMutation.mutate(values);
  };

  const onEditSubmit = async (values: FormValues & { id: number }) => {
    updateMutation.mutate(values);
  };

  const handleEditClick = (item: InventoryItem) => {
    setSelectedItem(item);
    
    // Find matching category and product type if available
    const matchingProductType = productTypes.find(
      product => product.name === item.productName
    );
    
    if (matchingProductType) {
      setSelectedCategory(matchingProductType.category);
      setSelectedProductType(matchingProductType);
    } else {
      setSelectedCategory("");
      setSelectedProductType(null);
    }
    
    // Reset form with item values
    editForm.reset({
      id: item.id,
      productName: item.productName,
      quantity: item.quantity,
      unit: item.unit,
      storageUnitId: item.storageUnitId,
      startDate: new Date(item.startDate),
      endDate: item.endDate ? new Date(item.endDate) : null,
      dailyRate: item.dailyRate,
      status: item.status,
      notes: item.notes,
    });
    
    setIsEditModalOpen(true);
  };

  const handleDeleteClick = (item: InventoryItem) => {
    setSelectedItem(item);
    setIsDeleteModalOpen(true);
  };

  const confirmDelete = () => {
    if (selectedItem) {
      deleteMutation.mutate(selectedItem.id);
    }
  };

  // Filter inventory by status for tabs
  const activeItems = inventory.filter(item => item.status === "active");
  const archivedItems = inventory.filter(item => item.status === "archived");
  const expiredItems = inventory.filter(item => item.status === "expired");

  const isLoading = isInventoryLoading || isUnitsLoading || isCategoriesLoading || isProductTypesLoading;

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold">Inventory Management</h2>
        <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Item
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Add Inventory Item</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormItem className="col-span-2">
                    <FormLabel>Category</FormLabel>
                    <Select 
                      value={selectedCategory}
                      onValueChange={(value) => {
                        setSelectedCategory(value);
                        setSelectedProductType(null);
                        form.setValue("productName", "");
                        form.setValue("unit", "kg");
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category.id} value={category.name}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormItem>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  {selectedCategory ? (
                    <FormField
                      control={form.control}
                      name="productName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Product Type</FormLabel>
                          <Select 
                            value={field.value}
                            onValueChange={(value) => {
                              field.onChange(value);
                              const selectedProduct = productTypes.find(
                                product => product.name === value && product.category === selectedCategory
                              );
                              if (selectedProduct) {
                                setSelectedProductType(selectedProduct);
                                form.setValue("unit", selectedProduct.standardUnit);
                              }
                            }}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select a product type" />
                            </SelectTrigger>
                            <SelectContent>
                              {filteredProductTypes.map((productType) => (
                                <SelectItem key={productType.id} value={productType.name}>
                                  {productType.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  ) : (
                    <FormField
                      control={form.control}
                      name="productName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Product Name</FormLabel>
                          <FormControl>
                            <Input placeholder="First select a category" disabled {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}
                  
                  <div className="grid grid-cols-2 gap-2">
                    <FormField
                      control={form.control}
                      name="quantity"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Quantity</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              min="0" 
                              step="0.1" 
                              {...field} 
                              onChange={(e) => field.onChange(parseFloat(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="unit"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Input Unit</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select unit" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="kg">kg</SelectItem>
                              <SelectItem value="lbs">lbs</SelectItem>
                              <SelectItem value="tons">tons</SelectItem>
                              <SelectItem value="liters">liters</SelectItem>
                              <SelectItem value="gallons">gallons</SelectItem>
                              <SelectItem value="pieces">pieces</SelectItem>
                              <SelectItem value="boxes">boxes</SelectItem>
                              <SelectItem value="pallets">pallets</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            All measurements will be converted to kg for storage pricing (10 XAF per kg).
                            {field.value === "tons" && (
                              <div className="text-primary font-medium mt-1">
                                1 ton = 1000 kg
                              </div>
                            )}
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
                
                <FormField
                  control={form.control}
                  name="storageUnitId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Storage Unit</FormLabel>
                      <Select 
                        onValueChange={(value) => field.onChange(parseInt(value))} 
                        defaultValue={field.value.toString()}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select storage unit" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {storageUnits.map((unit) => (
                            <SelectItem key={unit.id} value={unit.id.toString()}>
                              {unit.unitId} - {unit.location}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="startDate"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>Start Date</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant={"outline"}
                                className={`w-full pl-3 text-left font-normal ${!field.value && "text-muted-foreground"}`}
                              >
                                {field.value ? (
                                  format(field.value, "PPP")
                                ) : (
                                  <span>Pick a date</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={field.value}
                              onSelect={field.onChange}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="endDate"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>End Date (Optional)</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant={"outline"}
                                className={`w-full pl-3 text-left font-normal ${!field.value && "text-muted-foreground"}`}
                              >
                                {field.value ? (
                                  format(field.value, "PPP")
                                ) : (
                                  <span>Pick a date</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={field.value || undefined}
                              onSelect={field.onChange}
                              initialFocus
                              disabled={(date) => date < form.getValues("startDate")}
                            />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="status"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Status</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select status" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="active">Active</SelectItem>
                            <SelectItem value="archived">Archived</SelectItem>
                            <SelectItem value="expired">Expired</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="dailyRate"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-end space-x-2 space-y-0 pt-6">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Daily Rate Pricing</FormLabel>
                          <p className="text-xs text-gray-500">
                            Apply daily rate instead of flat fee
                          </p>
                        </div>
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notes (Optional)</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Enter any additional notes about this inventory item"
                          {...field}
                          value={field.value || ""}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="flex justify-end space-x-2 pt-4">
                  <Button type="button" variant="outline" onClick={() => setIsAddModalOpen(false)}>
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={createMutation.isPending}
                  >
                    {createMutation.isPending ? "Saving..." : "Save Item"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
      
      <Tabs defaultValue="active" className="mb-8">
        <TabsList className="mb-4">
          <TabsTrigger value="active">Active Items ({activeItems.length})</TabsTrigger>
          <TabsTrigger value="archived">Archived ({archivedItems.length})</TabsTrigger>
          <TabsTrigger value="expired">Expired ({expiredItems.length})</TabsTrigger>
          <TabsTrigger value="all">All Items ({inventory.length})</TabsTrigger>
        </TabsList>
        
        <TabsContent value="active">
          <InventoryTabContent 
            items={activeItems} 
            isLoading={isLoading}
            storageUnits={storageUnits}
            onItemClick={handleEditClick}
            emptyMessage="No active inventory items found."
          />
        </TabsContent>
        
        <TabsContent value="archived">
          <InventoryTabContent 
            items={archivedItems} 
            isLoading={isLoading}
            storageUnits={storageUnits}
            onItemClick={handleEditClick}
            emptyMessage="No archived inventory items found."
          />
        </TabsContent>
        
        <TabsContent value="expired">
          <InventoryTabContent 
            items={expiredItems} 
            isLoading={isLoading}
            storageUnits={storageUnits}
            onItemClick={handleEditClick}
            emptyMessage="No expired inventory items found."
          />
        </TabsContent>
        
        <TabsContent value="all">
          <InventoryTabContent 
            items={inventory} 
            isLoading={isLoading}
            storageUnits={storageUnits}
            onItemClick={handleEditClick}
            emptyMessage="No inventory items found."
          />
        </TabsContent>
      </Tabs>
      
      {/* Edit Modal */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Edit Inventory Item</DialogTitle>
          </DialogHeader>
          {selectedItem && (
            <Form {...editForm}>
              <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormItem className="col-span-2">
                    <FormLabel>Category</FormLabel>
                    <Select 
                      value={selectedCategory}
                      onValueChange={(value) => {
                        setSelectedCategory(value);
                        setSelectedProductType(null);
                        editForm.setValue("productName", "");
                        editForm.setValue("unit", "kg");
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category.id} value={category.name}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormItem>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  {selectedCategory ? (
                    <FormField
                      control={editForm.control}
                      name="productName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Product Type</FormLabel>
                          <Select 
                            value={field.value}
                            onValueChange={(value) => {
                              field.onChange(value);
                              const selectedProduct = productTypes.find(
                                product => product.name === value && product.category === selectedCategory
                              );
                              if (selectedProduct) {
                                setSelectedProductType(selectedProduct);
                                editForm.setValue("unit", selectedProduct.standardUnit);
                              }
                            }}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select a product type" />
                            </SelectTrigger>
                            <SelectContent>
                              {filteredProductTypes.map((productType) => (
                                <SelectItem key={productType.id} value={productType.name}>
                                  {productType.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  ) : (
                    <FormField
                      control={editForm.control}
                      name="productName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Product Name</FormLabel>
                          <FormControl>
                            <Input placeholder="First select a category" disabled {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}
                  
                  <div className="grid grid-cols-2 gap-2">
                    <FormField
                      control={editForm.control}
                      name="quantity"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Quantity</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              min="0" 
                              step="0.1" 
                              {...field} 
                              onChange={(e) => field.onChange(parseFloat(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={editForm.control}
                      name="unit"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Input Unit</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select unit" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="kg">kg</SelectItem>
                              <SelectItem value="lbs">lbs</SelectItem>
                              <SelectItem value="tons">tons</SelectItem>
                              <SelectItem value="liters">liters</SelectItem>
                              <SelectItem value="gallons">gallons</SelectItem>
                              <SelectItem value="pieces">pieces</SelectItem>
                              <SelectItem value="boxes">boxes</SelectItem>
                              <SelectItem value="pallets">pallets</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            All measurements will be converted to kg for storage pricing (10 XAF per kg).
                            {field.value === "tons" && (
                              <div className="text-primary font-medium mt-1">
                                1 ton = 1000 kg
                              </div>
                            )}
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
                
                <FormField
                  control={editForm.control}
                  name="storageUnitId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Storage Unit</FormLabel>
                      <Select 
                        onValueChange={(value) => field.onChange(parseInt(value))} 
                        defaultValue={field.value.toString()}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select storage unit" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {storageUnits.map((unit) => (
                            <SelectItem key={unit.id} value={unit.id.toString()}>
                              {unit.unitId} - {unit.location}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={editForm.control}
                    name="startDate"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>Start Date</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant={"outline"}
                                className={`w-full pl-3 text-left font-normal ${!field.value && "text-muted-foreground"}`}
                              >
                                {field.value ? (
                                  format(field.value, "PPP")
                                ) : (
                                  <span>Pick a date</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={field.value}
                              onSelect={field.onChange}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editForm.control}
                    name="endDate"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>End Date (Optional)</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant={"outline"}
                                className={`w-full pl-3 text-left font-normal ${!field.value && "text-muted-foreground"}`}
                              >
                                {field.value ? (
                                  format(field.value, "PPP")
                                ) : (
                                  <span>Pick a date</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={field.value || undefined}
                              onSelect={field.onChange}
                              initialFocus
                              disabled={(date) => date < editForm.getValues("startDate")}
                            />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={editForm.control}
                    name="status"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Status</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select status" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="active">Active</SelectItem>
                            <SelectItem value="archived">Archived</SelectItem>
                            <SelectItem value="expired">Expired</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editForm.control}
                    name="dailyRate"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-end space-x-2 space-y-0 pt-6">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Daily Rate Pricing</FormLabel>
                          <p className="text-xs text-gray-500">
                            Apply daily rate instead of flat fee
                          </p>
                        </div>
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={editForm.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notes (Optional)</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Enter any additional notes about this inventory item"
                          {...field}
                          value={field.value || ""}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="flex justify-between pt-4">
                  <Button 
                    type="button" 
                    variant="destructive" 
                    onClick={() => {
                      setIsEditModalOpen(false);
                      setIsDeleteModalOpen(true);
                    }}
                  >
                    Delete Item
                  </Button>
                  
                  <div className="flex space-x-2">
                    <Button type="button" variant="outline" onClick={() => setIsEditModalOpen(false)}>
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={updateMutation.isPending}
                    >
                      {updateMutation.isPending ? "Saving..." : "Save Changes"}
                    </Button>
                  </div>
                </div>
              </form>
            </Form>
          )}
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation Modal */}
      <Dialog open={isDeleteModalOpen} onOpenChange={setIsDeleteModalOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p>Are you sure you want to delete this inventory item?</p>
            {selectedItem && (
              <div className="mt-2 p-3 bg-gray-50 rounded-md">
                <p className="font-medium">{selectedItem.productName}</p>
                <p className="text-sm text-gray-600">
                  {selectedItem.quantity} {selectedItem.unit} - {
                    storageUnits.find(unit => unit.id === selectedItem.storageUnitId)?.unitId || "Unknown Unit"
                  }
                </p>
              </div>
            )}
            <p className="mt-4 text-sm text-red-500">This action cannot be undone.</p>
          </div>
          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={() => setIsDeleteModalOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={confirmDelete}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete Item"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

interface InventoryTabContentProps {
  value?: string;
  items: InventoryItem[];
  isLoading: boolean;
  storageUnits: StorageUnit[];
  onItemClick: (item: InventoryItem) => void;
  emptyMessage: string;
}

function InventoryTabContent({
  items,
  isLoading,
  storageUnits,
  onItemClick,
  emptyMessage
}: InventoryTabContentProps) {
  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  if (items.length === 0) {
    return (
      <div className="py-8 text-center">
        <p className="text-gray-500">{emptyMessage}</p>
      </div>
    );
  }
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {items.map((item) => {
        const storageUnit = storageUnits.find(unit => unit.id === item.storageUnitId);
        const startDate = new Date(item.startDate).toLocaleDateString();
        const endDate = item.endDate ? new Date(item.endDate).toLocaleDateString() : "Ongoing";
        
        return (
          <Card key={item.id} className="overflow-hidden hover:shadow-md transition-shadow cursor-pointer" onClick={() => onItemClick(item)}>
            <CardContent className="p-0">
              <div className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-medium truncate">{item.productName}</h3>
                  <Badge 
                    variant={
                      item.status === "active" ? "default" : 
                      item.status === "archived" ? "secondary" : 
                      "destructive"
                    }
                    className="ml-2"
                  >
                    {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                  </Badge>
                </div>
                
                <div className="text-sm text-gray-500 mb-4">
                  <div className="flex justify-between mb-1">
                    <span>Quantity:</span>
                    <span className="font-medium text-gray-700">{item.quantity} {item.unit}</span>
                  </div>
                  <div className="flex justify-between mb-1">
                    <span>Storage Unit:</span>
                    <span className="font-medium text-gray-700">{storageUnit?.unitId || "Unknown"}</span>
                  </div>
                  <div className="flex justify-between mb-1">
                    <span>Location:</span>
                    <span className="font-medium text-gray-700">{storageUnit?.location || "Unknown"}</span>
                  </div>
                  <div className="flex justify-between mb-1">
                    <span>Date Range:</span>
                    <span className="font-medium text-gray-700">{startDate} - {endDate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Pricing:</span>
                    <span className="font-medium text-gray-700">{item.dailyRate ? "Daily Rate" : "Flat Fee"}</span>
                  </div>
                </div>
                
                {item.notes && (
                  <div className="text-xs text-gray-500 mt-2 border-t pt-2">
                    <div className="font-medium mb-1">Notes:</div>
                    <p className="line-clamp-2">{item.notes}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}