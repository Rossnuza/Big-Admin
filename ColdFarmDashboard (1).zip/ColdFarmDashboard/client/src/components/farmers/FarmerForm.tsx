import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Farmer } from "@shared/schema";
import { z } from "zod";
import { africanCountries, getCitiesByCountry, getCountryNames } from "@/lib/countries-cities";

interface FarmerFormProps {
  farmer?: Farmer;
  onSuccess?: () => void;
}

// Create a frontend-specific form schema
const formSchema = z.object({
  contactPerson: z.string().min(1, "Contact person is required"),
  phone: z.string().min(1, "Phone number is required"),
  email: z.string().email("Invalid email address"),
  region: z.string().min(1, "Region is required"),
  joinDate: z.string().min(1, "Join date is required"),
  marketplaceOptIn: z.boolean(),
  storageAgreement: z.boolean(),
  notes: z.string().optional(),
});

export function FarmerForm({ farmer, onSuccess }: FarmerFormProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState<string>("");
  const [availableCities, setAvailableCities] = useState<string[]>([]);
  const [selectedCity, setSelectedCity] = useState<string>("");

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: farmer
      ? {
          contactPerson: farmer.contactPerson,
          phone: farmer.phone,
          email: farmer.email,
          region: farmer.region,
          joinDate: farmer.joinDate 
            ? new Date(farmer.joinDate).toISOString().split('T')[0] 
            : new Date().toISOString().split('T')[0],
          marketplaceOptIn: farmer.marketplaceOptIn,
          storageAgreement: farmer.storageAgreement,

          notes: farmer.notes || "",
        }
      : {
          contactPerson: "",
          phone: "",
          email: "",
          region: "",
          joinDate: new Date().toISOString().split('T')[0],
          marketplaceOptIn: false,
          storageAgreement: false,

          notes: "",
        },
  });
  
  // When country changes, update available cities
  useEffect(() => {
    if (selectedCountry) {
      const cities = getCitiesByCountry(selectedCountry);
      setAvailableCities(cities);
      setSelectedCity(""); // Reset city when country changes
    } else {
      setAvailableCities([]);
      setSelectedCity("");
    }
  }, [selectedCountry]);
  
  // Update region when country and city are selected
  useEffect(() => {
    if (selectedCountry && selectedCity && !farmer) {
      form.setValue("region", `${selectedCity}, ${selectedCountry}`);
    }
  }, [selectedCountry, selectedCity, form, farmer]);

  const mutation = useMutation({
    mutationFn: async (values: z.infer<typeof formSchema>) => {
      // Format dates correctly
      const payload = {
        ...values,
        // Ensure we have a name field (using the contact person's name if creating a new farmer)
        name: farmer ? farmer.name : values.contactPerson,
        joinDate: new Date(values.joinDate),
      };
      
      if (farmer) {
        // Update existing farmer
        return apiRequest("PUT", `/api/farmers/${farmer.id}`, payload);
      } else {
        // Create new farmer
        return apiRequest("POST", "/api/farmers", payload);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/farmers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/farmers/top"] });
      toast({
        title: farmer ? "Farmer Updated" : "Farmer Created",
        description: farmer
          ? "The farmer has been updated successfully."
          : "The farmer has been added successfully.",
      });
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to ${farmer ? "update" : "create"} farmer: ${error.message}`,
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsSubmitting(false);
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    setIsSubmitting(true);
    mutation.mutate(values);
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        {!farmer && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Country</label>
              <Select
                value={selectedCountry}
                onValueChange={setSelectedCountry}
                disabled={!!farmer}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select country" />
                </SelectTrigger>
                <SelectContent>
                  {getCountryNames().map(country => (
                    <SelectItem key={country} value={country}>
                      {country}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Select the country where the farmer is located
              </p>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">City</label>
              <Select
                value={selectedCity}
                onValueChange={setSelectedCity}
                disabled={!selectedCountry || !!farmer}
              >
                <SelectTrigger>
                  <SelectValue placeholder={selectedCountry ? "Select city" : "Select country first"} />
                </SelectTrigger>
                <SelectContent>
                  {availableCities.map(city => (
                    <SelectItem key={city} value={city}>
                      {city}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Select the city where the farmer is located
              </p>
            </div>
          </div>
        )}
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="contactPerson"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Contact Person</FormLabel>
                <FormControl>
                  <Input placeholder="Full name" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="region"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Region</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="e.g., Nairobi, Kenya" 
                    {...field} 
                    disabled={!farmer && (!!selectedCountry && !!selectedCity)}
                    className={!farmer && (!!selectedCountry && !!selectedCity) ? "bg-muted cursor-not-allowed" : ""}
                  />
                </FormControl>
                {!farmer && (
                  <FormDescription>
                    {selectedCountry && selectedCity 
                      ? "Region is auto-filled based on selected city and country" 
                      : "Select country and city to auto-fill region"}
                  </FormDescription>
                )}
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="phone"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Phone Number</FormLabel>
                <FormControl>
                  <Input placeholder="+31 XX XXX XXXX" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Email Address</FormLabel>
                <FormControl>
                  <Input type="email" placeholder="email@example.com" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="joinDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Join Date</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="marketplaceOptIn"
            render={({ field }) => (
              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                <div className="space-y-0.5">
                  <FormLabel>Marketplace Opt-In</FormLabel>
                  <div className="text-sm text-muted-foreground">
                    Allow produce to be listed in the Coldfarms marketplace
                  </div>
                </div>
                <FormControl>
                  <Switch
                    checked={field.value}
                    onCheckedChange={field.onChange}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="storageAgreement"
            render={({ field }) => (
              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                <div className="space-y-0.5">
                  <FormLabel>Storage Agreement</FormLabel>
                  <div className="text-sm text-muted-foreground">
                    Farmer has agreed to storage service terms
                  </div>
                </div>
                <FormControl>
                  <Switch
                    checked={field.value}
                    onCheckedChange={field.onChange}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>



        <FormField
          control={form.control}
          name="notes"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Notes</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Additional information about the farmer" 
                  className="resize-none" 
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end space-x-2 pt-4">
          <Button 
            type="button" 
            variant="outline" 
            onClick={() => onSuccess && onSuccess()}
          >
            Cancel
          </Button>
          <Button 
            type="submit" 
            disabled={isSubmitting || !form.formState.isDirty}
          >
            {isSubmitting ? "Saving..." : "Save"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
