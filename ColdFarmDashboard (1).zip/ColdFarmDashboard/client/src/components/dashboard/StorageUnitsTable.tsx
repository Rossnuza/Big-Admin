import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Link } from "wouter";
import { Eye, MoreVertical, Plus } from "lucide-react";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { StorageUnitForm } from "../storage-units/StorageUnitForm";
import { StorageUnit } from "@shared/schema";

interface StorageUnitsTableProps {
  showViewAll?: boolean;
  limit?: number;
}

export function StorageUnitsTable({ showViewAll = false, limit }: StorageUnitsTableProps) {
  const [location, setLocation] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [currentPage, setCurrentPage] = useState(1);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const pageSize = 4;

  const { data: storageUnits = [], isLoading } = useQuery<StorageUnit[]>({
    queryKey: ["/api/storage-units"],
  });

  // Filter by location and search term
  const filteredUnits = storageUnits.filter(unit => {
    const matchesLocation = location === "all" || unit.location.includes(location);
    const matchesSearch = unit.unitId.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          unit.location.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesLocation && matchesSearch;
  });

  // Pagination
  const totalItems = filteredUnits.length;
  const paginatedUnits = filteredUnits.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  ).slice(0, limit || undefined);

  const statusBadgeVariant = (status: string) => {
    switch (status.toLowerCase()) {
      case 'operational':
        return 'bg-green-100 text-success';
      case 'maintenance':
        return 'bg-yellow-100 text-warning';
      case 'offline':
        return 'bg-red-100 text-error';
      default:
        return 'bg-gray-100 text-gray-600';
    }
  };

  const handleSearch = (term: string) => {
    setSearchTerm(term);
    setCurrentPage(1);
  };

  const locationsSet = new Set(storageUnits.map(unit => unit.location));
  const locations = Array.from(locationsSet);

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-gray-800">Storage Units Status</h2>
        {showViewAll && (
          <Link href="/storage-units">
            <div className="text-accent hover:text-indigo-700 text-sm font-medium cursor-pointer">View all</div>
          </Link>
        )}
      </div>
      <DataTable
        data={paginatedUnits}
        columns={[
          {
            header: "Unit ID",
            accessorKey: "unitId",
          },
          {
            header: "Location",
            accessorKey: "location",
          },
          {
            header: "Temperature",
            cell: (row) => row.temperature !== null ? `${row.temperature}°C` : "--",
          },
          {
            header: "Capacity",
            cell: (row) => (
              <div className="flex items-center">
                <div className="w-24 bg-gray-200 rounded-full h-2.5">
                  <div 
                    className={`h-2.5 rounded-full ${
                      row.capacity / row.maxCapacity > 0.85 
                        ? "bg-warning" 
                        : "bg-primary"
                    }`} 
                    style={{ width: `${(row.capacity / row.maxCapacity) * 100}%` }}
                  ></div>
                </div>
                <span className="text-xs ml-2">{Math.round((row.capacity / row.maxCapacity) * 100)}%</span>
              </div>
            ),
          },
          {
            header: "Status",
            cell: (row) => (
              <Badge variant="outline" className={statusBadgeVariant(row.status)}>
                {row.status.charAt(0).toUpperCase() + row.status.slice(1)}
              </Badge>
            ),
          },
          {
            header: "Actions",
            cell: (row) => (
              <div className="flex justify-end">
                <Button variant="ghost" size="icon" asChild>
                  <Link href={`/storage-units/${row.id}`}>
                    <Eye className="h-4 w-4 text-accent" />
                  </Link>
                </Button>
                <Button variant="ghost" size="icon">
                  <MoreVertical className="h-4 w-4 text-gray-500" />
                </Button>
              </div>
            ),
          },
        ]}
        searchPlaceholder="Search units..."
        onSearch={handleSearch}
        pagination={{
          currentPage,
          pageSize,
          totalItems,
          onPageChange: setCurrentPage,
        }}
        isLoading={isLoading}
      />

      {/* Add Storage Unit Dialog */}
      <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Add New Storage Unit</DialogTitle>
          </DialogHeader>
          <StorageUnitForm 
            onSuccess={() => {
              setIsAddModalOpen(false);
            }} 
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
