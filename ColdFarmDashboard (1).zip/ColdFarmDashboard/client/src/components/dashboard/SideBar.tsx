import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  LayoutGrid, 
  Package, 
  Users, 
  Store, 
  BarChart3, 
  Settings, 
  Snowflake,
  Tags,
  ShoppingCart,
  DollarSign,
  Receipt,
  CreditCard,
  PieChart,
  ChevronDown,
  ChevronRight,
  Calendar
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

interface SidebarLinkProps {
  href: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  isActive: boolean;
  onClick?: () => void;
}

function SidebarLink({ href, icon, children, isActive, onClick }: SidebarLinkProps) {
  return (
    <Link href={href}>
      <div
        onClick={onClick}
        className={cn(
          "flex items-center py-3 px-4 text-white hover:bg-teal-800 hover:bg-opacity-50 cursor-pointer",
          isActive && "bg-teal-800 bg-opacity-50"
        )}
      >
        <span className="w-6">{icon}</span>
        <span>{children}</span>
      </div>
    </Link>
  );
}

interface SidebarSubmenuProps {
  title: string;
  icon: React.ReactNode;
  isActive: boolean;
  isOpen: boolean;
  onToggle: () => void;
  children: React.ReactNode;
}

function SidebarSubmenu({ title, icon, isActive, isOpen, onToggle, children }: SidebarSubmenuProps) {
  return (
    <div>
      <div
        onClick={onToggle}
        className={cn(
          "flex items-center justify-between py-3 px-4 text-white hover:bg-teal-800 hover:bg-opacity-50 cursor-pointer",
          isActive && "bg-teal-800 bg-opacity-50"
        )}
      >
        <div className="flex items-center">
          <span className="w-6">{icon}</span>
          <span>{title}</span>
        </div>
        <span>{isOpen ? <ChevronDown size={16} /> : <ChevronRight size={16} />}</span>
      </div>
      <div className={cn("pl-4", !isOpen && "hidden")}>
        {children}
      </div>
    </div>
  );
}

export function SideBar() {
  const [location] = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isFinanceOpen, setIsFinanceOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  const toggleFinance = () => {
    setIsFinanceOpen(!isFinanceOpen);
  };

  // Determine if any finance-related path is active
  const isFinanceActive = location.startsWith("/finance");

  return (
    <aside className="bg-primary text-white w-full md:w-64 md:min-h-screen transition-all duration-300 ease-in-out">
      <div className="p-4 flex items-center justify-between md:justify-center">
        <div className="flex items-center space-x-2">
          <Snowflake className="h-6 w-6" />
          <span className="text-xl font-bold">COLDFARMS</span>
        </div>
        <button 
          id="sidebarToggle" 
          className="md:hidden"
          onClick={toggleMenu}
        >
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            className="h-6 w-6" 
            fill="none" 
            viewBox="0 0 24 24" 
            stroke="currentColor"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth={2} 
              d="M4 6h16M4 12h16M4 18h16" 
            />
          </svg>
        </button>
      </div>
      <nav className="mt-6">
        <div 
          id="sidebarMenu" 
          className={cn(
            "flex flex-col", 
            !isMenuOpen && "hidden md:block"
          )}
        >
          <SidebarLink 
            href="/" 
            icon={<LayoutGrid size={18} />} 
            isActive={location === "/"} 
            onClick={closeMenu}
          >
            Dashboard
          </SidebarLink>
          <SidebarLink 
            href="/storage-units" 
            icon={<Package size={18} />} 
            isActive={location === "/storage-units"} 
            onClick={closeMenu}
          >
            Storage Units
          </SidebarLink>
          <SidebarLink 
            href="/farmers" 
            icon={<Users size={18} />} 
            isActive={location === "/farmers"} 
            onClick={closeMenu}
          >
            Farmers
          </SidebarLink>
          <SidebarLink 
            href="/marketplace" 
            icon={<Store size={18} />} 
            isActive={location === "/marketplace"} 
            onClick={closeMenu}
          >
            Marketplace
          </SidebarLink>
          <SidebarLink 
            href="/orders" 
            icon={<ShoppingCart size={18} />} 
            isActive={location.startsWith("/orders")} 
            onClick={closeMenu}
          >
            Order Tracking
          </SidebarLink>
          <SidebarLink 
            href="/categories" 
            icon={<Tags size={18} />} 
            isActive={location === "/categories"} 
            onClick={closeMenu}
          >
            Categories
          </SidebarLink>
          <SidebarLink 
            href="/storage-booking-requests" 
            icon={<Calendar size={18} />} 
            isActive={location === "/storage-booking-requests"} 
            onClick={closeMenu}
          >
            Storage Requests
          </SidebarLink>
          <SidebarSubmenu
            title="Finances"
            icon={<DollarSign size={18} />}
            isActive={isFinanceActive}
            isOpen={isFinanceOpen}
            onToggle={toggleFinance}
          >
            <SidebarLink 
              href="/finance/overview"
              icon={<PieChart size={16} />}
              isActive={location === "/finance/overview"}
              onClick={closeMenu}
            >
              Overview
            </SidebarLink>
            <SidebarLink 
              href="/finance/invoices"
              icon={<Receipt size={16} />}
              isActive={location === "/finance/invoices"}
              onClick={closeMenu}
            >
              Invoices
            </SidebarLink>
            <SidebarLink 
              href="/finance/payments" 
              icon={<CreditCard size={16} />}
              isActive={location === "/finance/payments"}
              onClick={closeMenu}
            >
              Payments
            </SidebarLink>
          </SidebarSubmenu>
          <SidebarLink 
            href="/analytics" 
            icon={<BarChart3 size={18} />} 
            isActive={location === "/analytics"} 
            onClick={closeMenu}
          >
            Analytics
          </SidebarLink>
          <SidebarLink 
            href="/settings" 
            icon={<Settings size={18} />} 
            isActive={location === "/settings"} 
            onClick={closeMenu}
          >
            Settings
          </SidebarLink>
        </div>
      </nav>
    </aside>
  );
}
