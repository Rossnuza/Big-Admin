import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ArrowUp, ArrowDown } from "lucide-react";
import { Farmer } from "@shared/schema";
import { useCurrency } from "@/lib/currency-context";
import { formatCurrency } from "@/lib/currency";

export function TopFarmers() {
  const { data: farmers = [], isLoading } = useQuery<Farmer[]>({
    queryKey: ["/api/farmers/top"],
  });
  
  const { activeCurrency } = useCurrency();

  // Get farmer sales data from API
  const { data: farmerSales = [], isLoading: isLoadingSales } = useQuery({
    queryKey: ['/api/farmers/sales'],
    // If API not yet implemented, use placeholder data that matches expected structure
    select: (data) => data || [
      { id: 1, sales: 4230, growth: "up" },
      { id: 2, sales: 3856, growth: "up" },
      { id: 3, sales: 2745, growth: "down" },
      { id: 4, sales: 2130, growth: "up" },
    ]
  });

  // Find sales for a farmer
  const getFarmerSales = (farmerId: number) => {
    const salesData = farmerSales.find(s => s.id === farmerId);
    return salesData || { sales: 0, growth: "up" };
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2 pt-4 px-6">
        <CardTitle className="text-lg font-semibold">Top Farmers</CardTitle>
        <Link href="/farmers">
          <div className="text-accent hover:text-indigo-700 text-sm font-medium cursor-pointer">View all</div>
        </Link>
      </CardHeader>
      <CardContent className="px-6 pb-6">
        {isLoading ? (
          <div className="py-10 text-center">Loading farmers...</div>
        ) : farmers.length === 0 ? (
          <div className="py-10 text-center text-gray-500">No farmers found</div>
        ) : (
          <ul className="divide-y divide-gray-200">
            {farmers.map((farmer) => {
              const salesData = getFarmerSales(farmer.id);
              return (
                <li key={farmer.id} className="py-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Avatar>
                        {farmer.avatar ? <AvatarImage src={farmer.avatar} alt={farmer.name} /> : null}
                        <AvatarFallback>{farmer.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div className="ml-3">
                        <p className="text-sm font-medium text-gray-900">{farmer.name}</p>
                        <p className="text-xs text-gray-500">{farmer.region}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center">
                        <span className="text-sm font-medium text-gray-900">{formatCurrency(salesData.sales, activeCurrency)}</span>
                        <span className={`text-xs ml-1 ${salesData.growth === "up" ? "text-success" : "text-error"}`}>
                          {salesData.growth === "up" ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />}
                        </span>
                      </div>
                      <p className="text-xs text-gray-500">Sales this month</p>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
