import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area
} from "recharts";
import { useCurrency } from "@/lib/currency-context";
import { formatCurrency } from "@/lib/currency";

export function Charts() {
  const { activeCurrency } = useCurrency();
  const { data: storageUtilization, isLoading: isLoadingStorage } = useQuery({
    queryKey: ["/api/analytics/storage-utilization"],
  });
  
  const { data: monthlyRevenue, isLoading: isLoadingRevenue } = useQuery({
    queryKey: ["/api/analytics/monthly-revenue"],
  });

  const formatChartCurrency = (value: number) => {
    return formatCurrency(value, activeCurrency);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
      <Card>
        <CardHeader className="pb-0">
          <CardTitle>Storage Utilization</CardTitle>
        </CardHeader>
        <CardContent className="h-64 pt-6">
          {isLoadingStorage ? (
            <div className="h-full flex items-center justify-center">Loading...</div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={Array.isArray(storageUtilization) ? storageUtilization : []}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="location" 
                  tick={{ fontSize: 12 }} 
                  tickFormatter={(value) => value?.split(' ')[0] || ''}
                />
                <YAxis 
                  tickFormatter={(value) => `${value}%`} 
                  domain={[0, 100]}
                />
                <Tooltip 
                  formatter={(value) => [`${value}%`, 'Capacity Used']}
                  labelFormatter={(label) => `Location: ${label}`}
                />
                <Bar 
                  dataKey="capacityPercentage" 
                  name="Capacity Used" 
                  fill="#0F766E" 
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-0">
          <CardTitle>Marketplace Sales</CardTitle>
        </CardHeader>
        <CardContent className="h-64 pt-6">
          {isLoadingRevenue ? (
            <div className="h-full flex items-center justify-center">Loading...</div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={Array.isArray(monthlyRevenue) ? monthlyRevenue : []}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4F46E5" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#4F46E5" stopOpacity={0.1} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis tickFormatter={(value) => {
                  const currency = activeCurrency === 'XAF' ? 'FCFA' : 
                    activeCurrency === 'USD' ? '$' : 
                    activeCurrency === 'EUR' ? '€' : '£';
                  return `${currency}${value}`;
                }} />
                <Tooltip formatter={(value) => [formatChartCurrency(value as number), 'Revenue']} />
                <Area
                  type="monotone"
                  dataKey="revenue"
                  stroke="#4F46E5"
                  fillOpacity={1}
                  fill="url(#colorRevenue)"
                />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
