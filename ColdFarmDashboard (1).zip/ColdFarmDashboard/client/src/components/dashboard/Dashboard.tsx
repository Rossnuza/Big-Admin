import { useQuery } from "@tanstack/react-query";
import { Package, Users, Store, DollarSign, TrendingUp } from "lucide-react";
import { SideBar } from "./SideBar";
import { Header } from "./Header";
import { StatCard } from "@/components/ui/stat-card";
import { StorageUnitsTable } from "./StorageUnitsTable";
import { Charts } from "./Charts";
import { RecentActivity } from "./RecentActivity";
import { TopFarmers } from "./TopFarmers";
import { useCurrency } from "@/lib/currency-context";
import { formatCurrency } from "@/lib/currency";

interface DashboardStats {
  totalStorageUnits: number;
  activeFarmers: number;
  marketplaceProducts: number;
  monthlyRevenue: number;
}

export function Dashboard() {
  const { data: stats, isLoading: isLoadingStats } = useQuery<DashboardStats>({
    queryKey: ["/api/stats/dashboard"],
  });
  
  const { activeCurrency } = useCurrency();

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <SideBar />
      <main className="flex-1 overflow-x-hidden bg-gray-100">
        <Header title="Dashboard" />
        <div className="p-6">
          {/* Key Metrics Row */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            <StatCard
              title="Total Storage Units"
              value={isLoadingStats ? "..." : (stats?.totalStorageUnits ?? 0)}
              icon={<Package className="h-5 w-5 text-primary" />}
              iconBgClass="bg-teal-100"
              change={{ value: 5, isPositive: true }}
            />
            <StatCard
              title="Active Farmers"
              value={isLoadingStats ? "..." : (stats?.activeFarmers ?? 0)}
              icon={<Users className="h-5 w-5 text-accent" />}
              iconBgClass="bg-indigo-100"
              change={{ value: 12, isPositive: true }}
            />
            <StatCard
              title="Marketplace Products"
              value={isLoadingStats ? "..." : (stats?.marketplaceProducts ?? 0)}
              icon={<Store className="h-5 w-5 text-secondary" />}
              iconBgClass="bg-emerald-100"
              change={{ value: 8, isPositive: true }}
            />
            <StatCard
              title="Revenue (MTD)"
              value={isLoadingStats ? "..." : stats ? formatCurrency(stats.monthlyRevenue, activeCurrency) : "—"}
              icon={<DollarSign className="h-5 w-5 text-success" />}
              iconBgClass="bg-green-100"
              change={{ value: 15, isPositive: true }}
            />
          </div>

          {/* Charts Row */}
          <Charts />

          {/* Storage Units Section */}
          <div className="mb-6">
            <StorageUnitsTable showViewAll={true} limit={4} />
          </div>

          {/* Recent Activity & Top Farmers Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <RecentActivity />
            <TopFarmers />
          </div>
        </div>
      </main>
    </div>
  );
}
