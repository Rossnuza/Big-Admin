import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, AlertTriangle, ShoppingCart, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Activity } from "@shared/schema";

export function RecentActivity() {
  const { data: activities = [], isLoading } = useQuery<Activity[]>({
    queryKey: ["/api/activities"],
    queryFn: async () => {
      const res = await fetch("/api/activities?limit=4");
      if (!res.ok) throw new Error("Failed to fetch activities");
      return res.json();
    },
  });

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
      return `Today, ${date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })}`;
    } else if (diffDays === 1) {
      return `Yesterday, ${date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })}`;
    } else {
      return date.toLocaleDateString('en-US', { day: 'numeric', month: 'short' }) + 
             `, ${date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })}`;
    }
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'new_farmer':
        return <Plus className="text-primary text-sm" />;
      case 'temperature_alert':
        return <AlertTriangle className="text-warning text-sm" />;
      case 'order_placed':
        return <ShoppingCart className="text-success text-sm" />;
      case 'maintenance':
        return <Settings className="text-accent text-sm" />;
      default:
        return <Plus className="text-primary text-sm" />;
    }
  };

  const getActivityBgColor = (type: string) => {
    switch (type) {
      case 'new_farmer':
        return 'bg-teal-100';
      case 'temperature_alert':
        return 'bg-yellow-100';
      case 'order_placed':
        return 'bg-green-100';
      case 'maintenance':
        return 'bg-indigo-100';
      default:
        return 'bg-gray-100';
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2 pt-4 px-6">
        <CardTitle className="text-lg font-semibold">Recent Activity</CardTitle>
        <Button variant="ghost" size="sm">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 12h.01M12 12h.01M19 12h.01M6 12a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0z" />
          </svg>
        </Button>
      </CardHeader>
      <CardContent className="px-6 pb-6">
        {isLoading ? (
          <div className="py-10 text-center">Loading activities...</div>
        ) : activities.length === 0 ? (
          <div className="py-10 text-center text-gray-500">No recent activities</div>
        ) : (
          <ul className="divide-y divide-gray-200">
            {activities.map((activity) => (
              <li key={activity.id} className="py-3">
                <div className="flex items-start">
                  <div className={`flex-shrink-0 ${getActivityBgColor(activity.type)} rounded-full p-2`}>
                    {getActivityIcon(activity.type)}
                  </div>
                  <div className="ml-3 flex-1">
                    <p className="text-sm font-medium text-gray-900">{activity.description}</p>
                    <p className="text-sm text-gray-500">
                      {typeof activity.details === 'string' 
                        ? activity.details 
                        : Object.entries(activity.details || {})
                            .map(([key, value]) => `${value}`)
                            .join(', ')}
                    </p>
                    <p className="text-xs text-gray-400 mt-1">{formatTime(activity.timestamp)}</p>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
        <div className="mt-4 text-center">
          <Button variant="link" className="text-accent hover:text-indigo-700 text-sm font-medium">
            View all activity
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
