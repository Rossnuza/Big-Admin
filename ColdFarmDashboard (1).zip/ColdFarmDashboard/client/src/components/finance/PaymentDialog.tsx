import { useState } from "react";
import { useCurrency } from "@/lib/currency-context";
import { formatCurrency } from "@/lib/currency";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { apiRequest } from "@/lib/queryClient";

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

interface PaymentFormProps {
  amount: number;
  onSuccess: () => void;
  onCancel: () => void;
}

function PaymentForm({ amount, onSuccess, onCancel }: PaymentFormProps) {
  const stripe = useStripe();
  const elements = useElements();
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();
  const { activeCurrency } = useCurrency();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: window.location.origin + '/finance/payments',
        },
        redirect: 'if_required',
      });

      if (error) {
        toast({
          title: "Payment Failed",
          description: error.message,
          variant: "destructive",
        });
        setIsProcessing(false);
      } else {
        toast({
          title: "Payment Successful",
          description: `Payment of ${formatCurrency(amount, activeCurrency)} has been processed.`,
        });
        setIsProcessing(false);
        onSuccess();
      }
    } catch (err: any) {
      toast({
        title: "Payment Error",
        description: err.message || "An unexpected error occurred",
        variant: "destructive",
      });
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="border rounded-lg p-4 bg-muted/50">
        <div className="flex justify-between mb-2">
          <span className="text-sm text-muted-foreground">Amount</span>
          <span className="font-medium">{formatCurrency(amount, activeCurrency)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-sm text-muted-foreground">Fee</span>
          <span className="text-sm">{formatCurrency(0, activeCurrency)}</span>
        </div>
        <div className="border-t my-2"></div>
        <div className="flex justify-between">
          <span className="font-medium">Total</span>
          <span className="font-medium">{formatCurrency(amount, activeCurrency)}</span>
        </div>
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium">Payment Method</label>
        <PaymentElement />
      </div>

      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel} disabled={isProcessing}>
          Cancel
        </Button>
        <Button type="submit" disabled={!stripe || isProcessing}>
          {isProcessing ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Processing
            </>
          ) : (
            "Process Payment"
          )}
        </Button>
      </DialogFooter>
    </form>
  );
}

interface PaymentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  amount: number;
  title: string;
  description: string;
  onSuccess?: () => void;
}

export function PaymentDialog({
  open,
  onOpenChange,
  amount,
  title,
  description,
  onSuccess = () => {},
}: PaymentDialogProps) {
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [loadingSecret, setLoadingSecret] = useState(false);
  const { toast } = useToast();

  // Create payment intent when dialog opens
  useState(() => {
    if (open && !clientSecret && !loadingSecret) {
      setLoadingSecret(true);
      apiRequest("POST", "/api/create-payment-intent", { amount })
        .then((res) => res.json())
        .then((data) => {
          setClientSecret(data.clientSecret);
          setLoadingSecret(false);
        })
        .catch((err) => {
          toast({
            title: "Error",
            description: "Could not initialize payment. Please try again.",
            variant: "destructive",
          });
          setLoadingSecret(false);
          onOpenChange(false);
        });
    }
  });

  const handleClose = () => {
    if (!loadingSecret) {
      onOpenChange(false);
    }
  };

  const handleSuccess = () => {
    onSuccess();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>
        
        {loadingSecret ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <span className="ml-2">Initializing payment...</span>
          </div>
        ) : clientSecret ? (
          <Tabs defaultValue="card" className="py-4">
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="card">Card Payment</TabsTrigger>
              <TabsTrigger value="bank">Bank Transfer</TabsTrigger>
            </TabsList>
            
            <TabsContent value="card">
              <Elements stripe={stripePromise} options={{ clientSecret }}>
                <PaymentForm 
                  amount={amount} 
                  onSuccess={handleSuccess}
                  onCancel={handleClose}
                />
              </Elements>
            </TabsContent>
            
            <TabsContent value="bank">
              <div className="py-6 space-y-6">
                <div className="border rounded-lg p-4 bg-blue-50">
                  <h3 className="font-medium text-blue-800 mb-2">Bank Transfer Details</h3>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-500">Account Name:</span>
                      <span className="font-medium">Coldfarms Ltd</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Account Number:</span>
                      <span className="font-medium">1234567890</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Bank Name:</span>
                      <span className="font-medium">Standard Bank</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Reference:</span>
                      <span className="font-medium text-blue-800">Payment-{new Date().getTime().toString().slice(-6)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Amount:</span>
                      <span className="font-medium">{new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount)}</span>
                    </div>
                  </div>
                </div>
                
                <p className="text-sm text-muted-foreground">
                  Please use the reference number provided when making the transfer. 
                  Payments typically take 1-2 business days to process.
                </p>
                
                <DialogFooter>
                  <Button variant="outline" onClick={handleClose}>
                    Cancel
                  </Button>
                  <Button onClick={handleSuccess}>
                    Mark as Transferred
                  </Button>
                </DialogFooter>
              </div>
            </TabsContent>
          </Tabs>
        ) : (
          <div className="py-6 text-center text-muted-foreground">
            Could not initialize payment. Please try again later.
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}