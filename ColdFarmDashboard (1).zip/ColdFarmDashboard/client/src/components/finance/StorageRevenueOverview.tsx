import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { ArrowUpRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCurrency } from "@/lib/currency-context";
import { formatCurrency } from "@/lib/currency";

interface StorageCostsResponse {
  farmers: {
    farmerId: number;
    farmerName: string;
    totalCost: number;
    formattedCost: string;
    itemCount: number;
    totalWeight: number;
  }[];
  totalRevenue: number;
  formattedTotalRevenue: string;
}

export function StorageRevenueOverview() {
  const { activeCurrency } = useCurrency();
  
  const { data: storageCosts, isLoading, error } = useQuery<StorageCostsResponse>({
    queryKey: ["/api/finance/storage-costs"],
    queryFn: async () => {
      const response = await fetch("/api/finance/storage-costs");
      if (!response.ok) {
        throw new Error("Failed to fetch storage costs");
      }
      return response.json();
    },
  });
  
  if (isLoading) {
    return (
      <>
        <div className="col-span-2 bg-background rounded-lg p-4 border animate-pulse h-24"></div>
        <div className="bg-background rounded-lg p-4 border animate-pulse h-24"></div>
        <div className="bg-background rounded-lg p-4 border animate-pulse h-24"></div>
      </>
    );
  }
  
  if (error || !storageCosts) {
    return (
      <div className="col-span-4 bg-background rounded-lg p-4 border">
        <p className="text-sm font-medium text-muted-foreground">Error Loading Revenue Data</p>
        <Button size="sm" variant="outline" className="mt-2">
          Retry
        </Button>
      </div>
    );
  }
  
  // Calculate some statistics
  const farmerCount = storageCosts.farmers.length;
  const totalWeight = storageCosts.farmers.reduce((acc, farmer) => acc + farmer.totalWeight, 0);
  const averageCostPerFarmer = farmerCount > 0 ? storageCosts.totalRevenue / farmerCount : 0;
  
  // Find the farmer with the highest cost
  const topFarmer = storageCosts.farmers[0] || { farmerName: 'N/A', totalCost: 0 };
  
  return (
    <>
      <div className="bg-background rounded-lg p-4 border col-span-2">
        <p className="text-sm font-medium text-muted-foreground">Storage Revenue</p>
        <h3 className="text-2xl font-bold mt-1">{storageCosts.formattedTotalRevenue}</h3>
        <p className="text-xs text-muted-foreground flex items-center mt-1">
          <span className="font-medium">From {farmerCount} farmers</span>
        </p>
      </div>
      
      <div className="bg-background rounded-lg p-4 border">
        <p className="text-sm font-medium text-muted-foreground">Total Storage</p>
        <h3 className="text-2xl font-bold mt-1">{totalWeight.toFixed(1)} kg</h3>
        <p className="text-xs text-muted-foreground flex items-center mt-1">
          <ArrowUpRight className="h-3 w-3 mr-1 text-green-500" />
          <span className="text-green-500 font-medium">Active Storage</span>
        </p>
      </div>
      
      <div className="bg-background rounded-lg p-4 border">
        <p className="text-sm font-medium text-muted-foreground">Top Farmer</p>
        <h3 className="text-2xl font-bold mt-1 truncate">{topFarmer.farmerName}</h3>
        <Link to={`/farmers/${topFarmer.farmerId}`}>
          <p className="text-xs text-blue-600 hover:underline flex items-center mt-1">
            {formatCurrency(topFarmer.totalCost, activeCurrency)}
          </p>
        </Link>
      </div>
    </>
  );
}