import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  CreditCard,
  DollarSign,
  FileText,
  Home,
  LayoutDashboard,
  Users,
  Wallet,
  Warehouse,
  ArrowLeft,
  FileSpreadsheet,
  Calendar
} from "lucide-react";

interface FinanceLayoutProps {
  children: ReactNode;
  title: string;
}

export function FinanceLayout({ children, title }: FinanceLayoutProps) {
  const [location] = useLocation();

  const navItems = [
    {
      title: "Overview & Revenue",
      href: "/finance/overview",
      icon: <LayoutDashboard className="h-5 w-5" />,
    },
    {
      title: "Invoices",
      href: "/finance/invoices",
      icon: <FileText className="h-5 w-5" />,
    },
    {
      title: "Payments",
      href: "/finance/payments",
      icon: <CreditCard className="h-5 w-5" />,
    },
    {
      title: "Farmer Payments",
      href: "/finance/farmer-payments",
      icon: <Users className="h-5 w-5" />,
    },
    {
      title: "Storage Billing",
      href: "/finance/storage-billing",
      icon: <Warehouse className="h-5 w-5" />,
    },
    {
      title: "Transaction History",
      href: "/finance/transactions",
      icon: <Wallet className="h-5 w-5" />,
    },
  ];

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <Link href="/">
            <div className="inline-flex items-center justify-center rounded-md px-3 py-2 mr-3 text-sm font-medium ring-offset-background transition-colors hover:bg-accent hover:text-accent-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 cursor-pointer">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Dashboard
            </div>
          </Link>
          <h2 className="text-3xl font-bold tracking-tight">{title}</h2>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm" className="hidden md:flex">
            <FileSpreadsheet className="mr-2 h-4 w-4" />
            Export Data
          </Button>
          <Button variant="outline" size="sm" className="hidden md:flex">
            <Calendar className="mr-2 h-4 w-4" />
            Select Date Range
          </Button>
        </div>
      </div>
      
      <div className="flex flex-col space-y-4 md:flex-row md:space-x-4 md:space-y-0">
        <div className="md:w-1/6">
          <nav className="grid gap-2">
            {navItems.map((item, index) => (
              <Link key={index} href={item.href}>
                <div
                  className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-all hover:text-primary cursor-pointer ${
                    location === item.href
                      ? "bg-muted font-medium text-primary"
                      : "text-muted-foreground"
                  }`}
                >
                  {item.icon}
                  {item.title}
                </div>
              </Link>
            ))}
          </nav>
        </div>
        <div className="flex-1 space-y-4">
          {children}
        </div>
      </div>
    </div>
  );
}