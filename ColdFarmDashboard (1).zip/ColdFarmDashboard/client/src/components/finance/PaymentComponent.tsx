import { useState, useEffect } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements } from '@stripe/react-stripe-js';
import { CheckoutForm } from './CheckoutForm';
import { apiRequest } from '@/lib/queryClient';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import { AlertCircle, Loader2 } from 'lucide-react';

// Make sure to call loadStripe outside of a component's render to avoid
// recreating the Stripe object on every render
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

interface PaymentComponentProps {
  amount: number;
  onSuccess?: () => void;
  onCancel?: () => void;
  currency?: string;
  description?: string;
}

export function PaymentComponent({ 
  amount, 
  onSuccess, 
  onCancel, 
  currency = 'USD',
  description
}: PaymentComponentProps) {
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPaymentIntent = async () => {
      try {
        setLoading(true);
        const response = await apiRequest('POST', '/api/create-payment-intent', {
          amount,
          currency: currency.toLowerCase()
        });
        
        const data = await response.json();
        setClientSecret(data.clientSecret);
      } catch (err: any) {
        setError(err.message || 'Failed to initialize payment');
        console.error('Error creating payment intent:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchPaymentIntent();
  }, [amount, currency]);

  const appearance = {
    theme: 'stripe' as const,
    variables: {
      colorPrimary: '#10b981',
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-full" />
        <Skeleton className="h-20 w-full" />
        <Skeleton className="h-20 w-full" />
        <Skeleton className="h-8 w-1/2 mx-auto" />
      </div>
    );
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    );
  }

  if (!clientSecret) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {description && (
        <div className="text-sm text-muted-foreground">{description}</div>
      )}
      <Elements stripe={stripePromise} options={{ clientSecret, appearance }}>
        <CheckoutForm 
          amount={amount} 
          onSuccess={onSuccess} 
          onCancel={onCancel} 
          currency={currency}
        />
      </Elements>
    </div>
  );
}