import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DownloadIcon, PrinterIcon, RefreshCw } from "lucide-react";
import { formatDistance } from "date-fns";
import { useToast } from "@/hooks/use-toast";

interface StorageCostItem {
  inventoryId: number;
  productName: string;
  quantityInKg: number;
  daysStored: number;
  dailyRate: number;
  totalCost: number;
  formattedCost: string;
  startDate: string;
  endDate?: string | null;
  status: string;
}

interface FarmerStorageSummary {
  farmerId: number;
  itemCount: number;
  totalWeight: number;
  totalCost: number;
  formattedCost: string;
  items: StorageCostItem[];
}

interface StorageBillingProps {
  farmerId: number;
}

export function StorageBilling({ farmerId }: StorageBillingProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("summary");
  
  const { data: storageCosts, isLoading, error, refetch } = useQuery<FarmerStorageSummary>({
    queryKey: ["/api/finance/storage-costs", farmerId],
    queryFn: async ({ queryKey }) => {
      const [_, farmerId] = queryKey;
      const response = await fetch(`/api/finance/storage-costs/${farmerId}`);
      if (!response.ok) {
        throw new Error("Failed to fetch storage costs");
      }
      return response.json();
    },
  });
  
  const { data: statementData, isLoading: statementLoading } = useQuery({
    queryKey: ["/api/finance/storage-statement", farmerId],
    queryFn: async ({ queryKey }) => {
      const [_, farmerId] = queryKey;
      const response = await fetch(`/api/finance/storage-statement/${farmerId}`);
      if (!response.ok) {
        throw new Error("Failed to fetch storage statement");
      }
      return response.json();
    },
    enabled: activeTab === "statement",
  });
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  if (error || !storageCosts) {
    return (
      <div className="text-center p-6">
        <h3 className="text-xl font-medium text-gray-700">Error Loading Storage Costs</h3>
        <p className="text-gray-500 mt-2">Failed to load storage billing information.</p>
        <Button onClick={() => refetch()} className="mt-4" variant="outline">
          <RefreshCw className="h-4 w-4 mr-2" />
          Try Again
        </Button>
      </div>
    );
  }
  
  const printStatement = () => {
    if (!statementData) return;
    
    const statementContent = statementData.statement;
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      toast({
        title: "Could not open print window",
        description: "Please check your browser settings and try again.",
        variant: "destructive",
      });
      return;
    }
    
    printWindow.document.write(`
      <html>
        <head>
          <title>Storage Statement</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            h1 { color: #333; }
            .statement { white-space: pre-line; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
            th { background-color: #f2f2f2; }
            .summary { margin-top: 20px; font-weight: bold; }
          </style>
        </head>
        <body>
          <h1>Storage Statement</h1>
          <div class="statement">${statementContent}</div>
        </body>
      </html>
    `);
    
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 500);
  };
  
  const downloadCSV = () => {
    if (!storageCosts || !storageCosts.items.length) return;
    
    // Create CSV content
    const headers = ["Product", "Quantity (kg)", "Days Stored", "Rate (XAF)", "Total Cost (XAF)"];
    const rows = storageCosts.items.map(item => [
      item.productName,
      item.quantityInKg.toFixed(2),
      item.daysStored.toString(),
      item.dailyRate.toString(),
      item.totalCost.toFixed(2)
    ]);
    
    // Add summary row
    rows.push([
      "TOTAL",
      storageCosts.totalWeight.toFixed(2),
      "",
      "",
      storageCosts.totalCost.toFixed(2)
    ]);
    
    // Format as CSV
    const csvContent = [
      headers.join(","),
      ...rows.map(row => row.join(","))
    ].join("\n");
    
    // Create download link
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `storage-costs-${farmerId}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Storage Billing</h2>
          <p className="text-muted-foreground">
            Calculated at 10 XAF per kg per day of storage
          </p>
        </div>
        
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" onClick={downloadCSV}>
            <DownloadIcon className="h-4 w-4 mr-2" />
            Export CSV
          </Button>
          
          <Button variant="outline" size="sm" onClick={printStatement}>
            <PrinterIcon className="h-4 w-4 mr-2" />
            Print Statement
          </Button>
        </div>
      </div>
      
      <Card>
        <CardHeader className="pb-2">
          <CardTitle>Billing Summary</CardTitle>
          <CardDescription>
            Total storage costs based on weight and duration
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-muted rounded-lg p-4">
              <div className="text-sm font-medium text-muted-foreground mb-1">Total Items</div>
              <div className="text-2xl font-bold">{storageCosts.itemCount}</div>
            </div>
            
            <div className="bg-muted rounded-lg p-4">
              <div className="text-sm font-medium text-muted-foreground mb-1">Total Weight</div>
              <div className="text-2xl font-bold">{storageCosts.totalWeight.toFixed(2)} kg</div>
            </div>
            
            <div className="bg-muted rounded-lg p-4">
              <div className="text-sm font-medium text-muted-foreground mb-1">Total Cost</div>
              <div className="text-2xl font-bold">{storageCosts.formattedCost}</div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="summary">Detailed Summary</TabsTrigger>
          <TabsTrigger value="statement">Statement</TabsTrigger>
        </TabsList>
        
        <TabsContent value="summary" className="mt-4">
          <Card>
            <CardContent className="pt-6">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Product</TableHead>
                    <TableHead>Quantity (kg)</TableHead>
                    <TableHead>Start Date</TableHead>
                    <TableHead>Days Stored</TableHead>
                    <TableHead>Daily Rate</TableHead>
                    <TableHead className="text-right">Total Cost</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {storageCosts.items.map((item) => (
                    <TableRow key={item.inventoryId}>
                      <TableCell className="font-medium">{item.productName}</TableCell>
                      <TableCell>{item.quantityInKg.toFixed(2)}</TableCell>
                      <TableCell>{new Date(item.startDate).toLocaleDateString()}</TableCell>
                      <TableCell>{item.daysStored} days</TableCell>
                      <TableCell>{item.dailyRate} XAF</TableCell>
                      <TableCell className="text-right">{item.formattedCost}</TableCell>
                    </TableRow>
                  ))}
                  
                  {/* Summary row */}
                  <TableRow className="bg-muted/50">
                    <TableCell colSpan={5} className="font-semibold">Total</TableCell>
                    <TableCell className="text-right font-bold">{storageCosts.formattedCost}</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="statement" className="mt-4">
          <Card>
            <CardContent className="pt-6">
              {statementLoading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                </div>
              ) : statementData ? (
                <pre className="p-4 bg-muted rounded-md whitespace-pre-line font-mono text-sm">
                  {statementData.statement}
                </pre>
              ) : (
                <div className="text-center p-6">
                  <p className="text-gray-500">No statement data available.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}