import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { SideBar } from "../dashboard/SideBar";
import { Header } from "../dashboard/Header";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ProductForm } from "./ProductForm";
import { Product, Farmer } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { Eye, Plus, MoreVertical, Edit, Trash2 } from "lucide-react";
import { Link } from "wouter";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { format } from "date-fns";

export function MarketplacePage() {
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [currentPage, setCurrentPage] = useState(1);
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const pageSize = 10;

  const { data: products = [], isLoading: isLoadingProducts } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const { data: farmers = [], isLoading: isLoadingFarmers } = useQuery<Farmer[]>({
    queryKey: ["/api/farmers"],
  });

  // Filter by search term and category
  const filteredProducts = products.filter(product => {
    const matchesSearch = 
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      getFarmerName(product.farmerId).toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = categoryFilter === "all" || product.category === categoryFilter;
    
    return matchesSearch && matchesCategory;
  });

  // Pagination
  const totalItems = filteredProducts.length;
  const paginatedProducts = filteredProducts.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  const handleSearch = (term: string) => {
    setSearchTerm(term);
    setCurrentPage(1);
  };

  const getFarmerName = (farmerId: number): string => {
    const farmer = farmers.find(f => f.id === farmerId);
    return farmer ? farmer.name : "Unknown Farmer";
  };

  const getCategoryOptions = () => {
    const categories = [...new Set(products.map(p => p.category))];
    return categories.map(category => (
      <SelectItem key={category} value={category}>{category}</SelectItem>
    ));
  };

  const handleEdit = (product: Product) => {
    setSelectedProduct(product);
    setIsEditModalOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <SideBar />
      <main className="flex-1 overflow-x-hidden bg-gray-100">
        <Header title="Marketplace" />
        <div className="p-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold">Marketplace Products</h1>
              <p className="text-gray-500">Manage all products listed in the Coldfarms marketplace</p>
            </div>
            <div className="mt-4 md:mt-0">
              <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Product
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[600px]">
                  <DialogHeader>
                    <DialogTitle>Add New Product</DialogTitle>
                  </DialogHeader>
                  <ProductForm 
                    farmers={farmers}
                    onSuccess={() => {
                      setIsAddModalOpen(false);
                    }} 
                  />
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Total Products</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{products.length}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Listed Products</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{products.filter(p => p.isListed).length}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Categories</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{new Set(products.map(p => p.category)).size}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Farmers</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{new Set(products.map(p => p.farmerId)).size}</div>
              </CardContent>
            </Card>
          </div>

          <div className="bg-white rounded-lg shadow overflow-hidden mb-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between p-4 border-b">
              <div className="w-full md:w-auto mb-4 md:mb-0">
                <Select 
                  value={categoryFilter} 
                  onValueChange={setCategoryFilter}
                >
                  <SelectTrigger className="w-full md:w-[200px]">
                    <SelectValue placeholder="Filter by category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {!isLoadingProducts && getCategoryOptions()}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <DataTable
            data={paginatedProducts}
            columns={[
              {
                header: "Product",
                cell: (row) => (
                  <div className="flex items-center">
                    <div className="h-10 w-10 rounded bg-gray-200 flex items-center justify-center mr-3">
                      {row.image ? (
                        <img src={row.image} alt={row.name} className="h-10 w-10 rounded object-cover" />
                      ) : (
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4V5h12v10z" clipRule="evenodd" />
                        </svg>
                      )}
                    </div>
                    <div>
                      <div className="font-medium">{row.name}</div>
                      <div className="text-sm text-gray-500">{row.category}</div>
                    </div>
                  </div>
                ),
              },
              {
                header: "Farmer",
                cell: (row) => getFarmerName(row.farmerId),
              },
              {
                header: "Price",
                cell: (row) => `€${row.price.toFixed(2)} / ${row.unit}`,
              },
              {
                header: "Quantity",
                cell: (row) => `${row.quantityAvailable} ${row.unit}s`,
              },
              {
                header: "Expiry Date",
                cell: (row) => row.expiryDate ? format(new Date(row.expiryDate), 'dd MMM yyyy') : 'N/A',
              },
              {
                header: "Status",
                cell: (row) => (
                  <Badge variant={row.isListed ? "success" : "outline"}>
                    {row.isListed ? "Listed" : "Unlisted"}
                  </Badge>
                ),
              },
              {
                header: "Actions",
                cell: (row) => (
                  <div className="flex justify-end">
                    <Button variant="ghost" size="icon" onClick={() => handleEdit(row)}>
                      <Edit className="h-4 w-4 text-gray-500" />
                    </Button>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="h-4 w-4 text-gray-500" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleEdit(row)}>
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600">
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                ),
              },
            ]}
            searchPlaceholder="Search products..."
            onSearch={handleSearch}
            pagination={{
              currentPage,
              pageSize,
              totalItems,
              onPageChange: setCurrentPage,
            }}
            isLoading={isLoadingProducts || isLoadingFarmers}
          />
        </div>
      </main>

      {/* Edit Product Dialog */}
      {selectedProduct && (
        <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Edit Product</DialogTitle>
            </DialogHeader>
            <ProductForm 
              product={selectedProduct}
              farmers={farmers}
              onSuccess={() => {
                setIsEditModalOpen(false);
                setSelectedProduct(null);
              }} 
            />
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
