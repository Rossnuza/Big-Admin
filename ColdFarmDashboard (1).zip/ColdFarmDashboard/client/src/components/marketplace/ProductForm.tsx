import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Checkbox
} from "@/components/ui/checkbox";
import { 
  FarmerInventory,
  Product, 
  Farmer, 
  StorageUnit, 
  products,
  insertProductSchema 
} from "@shared/schema";
import { createInsertSchema } from "drizzle-zod";
import { 
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { z } from "zod";
import { CheckIcon, ChevronUp, ChevronsUpDown, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { currencies, getCurrencyOptions } from "@/lib/currency";

interface ProductFormProps {
  product?: Product;
  farmers: Farmer[];
  onSuccess?: () => void;
}

// Create a new form schema based on the product fields
const formSchema = z.object({
  name: z.string().min(1, "Product name is required"),
  category: z.string().min(1, "Category is required"),
  farmerId: z.number(),
  price: z.number().min(0, "Price must be a positive number"),
  currency: z.string().default("USD"),
  unit: z.string().min(1, "Unit is required"),
  quantityAvailable: z.number().min(0, "Quantity must be a positive number"),
  expiryDate: z.union([z.string(), z.date(), z.null()]).nullable(),
  description: z.string().optional().nullable(),
  image: z.string().optional().nullable(),
  isListed: z.boolean().default(true),
  storageUnitId: z.number(),
  farmerIds: z.array(z.number()).optional(),
});

interface InventorySource {
  id: number;
  name: string;
  totalQuantity: number;
  unit: string;
}

export function ProductForm({ product, farmers, onSuccess }: ProductFormProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>(product?.category || "Vegetables");
  const [selectedProductName, setSelectedProductName] = useState<string>(product?.name || "");
  const [selectedFarmerIds, setSelectedFarmerIds] = useState<number[]>([]);
  const [inventorySources, setInventorySources] = useState<InventorySource[]>([]);
  const [totalQuantity, setTotalQuantity] = useState<number>(0);
  const [selectedUnit, setSelectedUnit] = useState<string>("kg");

  // Fallback categories if API fails to provide them
  const categories = [
    "Vegetables",
    "Fruits",
    "Dairy",
    "Eggs",
    "Meat",
    "Herbs",
    "Bread",
    "Preserves",
    "Other"
  ];

  const units = [
    "kg",
    "piece",
    "bundle",
    "carton",
    "liter",
    "dozen",
    "gram",
    "box"
  ];
  
  const { data: storageUnits = [] } = useQuery<StorageUnit[]>({
    queryKey: ["/api/storage-units"],
  });

  const availableStorageUnits = storageUnits.filter(unit => 
    unit.status === "operational" && 
    unit.capacity < unit.maxCapacity
  );

  // Initialize form
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: product
      ? {
          ...product,
          expiryDate: product.expiryDate 
            ? new Date(product.expiryDate).toISOString().split('T')[0] 
            : null,
          farmerIds: [],
        }
      : {
          name: "",
          category: selectedCategory,
          farmerId: farmers.length > 0 ? farmers[0].id : 0,
          price: 0,
          currency: "USD",
          unit: "kg",
          quantityAvailable: 0,
          expiryDate: null,
          description: "",
          image: "",
          isListed: true,
          storageUnitId: availableStorageUnits.length > 0 ? availableStorageUnits[0].id : 0,
          farmerIds: [],
        },
  });

  // Define Category interface
  interface Category {
    id: number;
    name: string;
    description: string;
    productCount: number;
  }

  // Fetch categories from the new category system
  const { data: categoriesData = [], isLoading: isCategoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  // Define ProductType interface
  interface ProductType {
    id: number;
    name: string;
    category: string;
    description: string;
    standardUnit: string;
  }

  // Fetch product types by category
  const { data: productTypes = [], isLoading: isProductsLoading, refetch: refetchProductTypes } = useQuery<ProductType[]>({
    queryKey: ["/api/product-types", selectedCategory],
    queryFn: async () => {
      const response = await fetch(`/api/product-types?category=${selectedCategory}`);
      if (!response.ok) {
        throw new Error("Failed to fetch product types by category");
      }
      return response.json();
    },
    enabled: !!selectedCategory,
  });
  
  // Extract product names from product types
  const productNames = productTypes.map(product => product.name);

  // Fetch farmers by product name
  const { data: farmersByProduct = [], isLoading: isFarmersLoading, refetch: refetchFarmers } = useQuery({
    queryKey: ["/api/inventory/farmers-by-product", selectedProductName],
    queryFn: async () => {
      const response = await fetch(`/api/inventory/farmers-by-product?productName=${selectedProductName}`);
      if (!response.ok) {
        throw new Error("Failed to fetch farmers by product");
      }
      return response.json();
    },
    enabled: !!selectedProductName,
  });

  // When category changes, update form and reset selections
  useEffect(() => {
    if (selectedCategory) {
      form.setValue("category", selectedCategory);
      refetchProductTypes();
      setSelectedProductName("");
      setSelectedFarmerIds([]);
      setInventorySources([]);
      setTotalQuantity(0);
    }
  }, [selectedCategory, refetchProductTypes, form]);

  // When product name changes, update form and reset farmer selections
  useEffect(() => {
    if (selectedProductName) {
      form.setValue("name", selectedProductName);
      refetchFarmers();
      setSelectedFarmerIds([]);
      setInventorySources([]);
      setTotalQuantity(0);
    }
  }, [selectedProductName, refetchFarmers, form]);

  // Update inventory sources and total quantity when farmers are selected
  useEffect(() => {
    if (farmersByProduct && farmersByProduct.length > 0) {
      const sources = farmersByProduct
        .filter((farmer: any) => selectedFarmerIds.includes(farmer.id))
        .map((farmer: any) => ({
          id: farmer.id,
          name: farmer.name,
          totalQuantity: farmer.totalQuantity,
          unit: farmer.unit
        }));
      
      setInventorySources(sources);
      
      // Calculate total quantity and determine unit
      if (sources.length > 0) {
        const total = sources.reduce((sum: number, source: InventorySource) => sum + source.totalQuantity, 0);
        setTotalQuantity(total);
        setSelectedUnit(sources[0].unit); // Assume all sources use the same unit
        
        // Automatically update the form fields
        form.setValue("quantityAvailable", total, { shouldDirty: true });
        form.setValue("unit", sources[0].unit, { shouldDirty: true });
        
        // Set the primary farmerId to the first selected farmer
        // This field is still required by the database schema
        form.setValue("farmerId", sources[0].id, { shouldDirty: true });
      } else {
        setTotalQuantity(0);
      }
    }
  }, [selectedFarmerIds, farmersByProduct, form]);

  // Clean input value helper
  const cleanInputValue = (value: string | null | undefined): string => {
    return value !== null && value !== undefined ? value : '';
  };
  
  const mutation = useMutation({
    mutationFn: async (values: z.infer<typeof formSchema>) => {
      // Format dates correctly
      const payload = {
        ...values,
        expiryDate: values.expiryDate ? new Date(values.expiryDate as string) : null,
      };
      
      if (product) {
        // Update existing product
        return apiRequest("PUT", `/api/products/${product.id}`, payload);
      } else {
        // Create new product
        return apiRequest("POST", "/api/products", payload);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({
        title: product ? "Product Updated" : "Product Created",
        description: product
          ? "The product has been updated successfully."
          : "The product has been created successfully.",
      });
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to ${product ? "update" : "create"} product: ${error.message}`,
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsSubmitting(false);
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    setIsSubmitting(true);
    mutation.mutate(values);
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 max-h-[70vh] overflow-y-auto pr-1">
        {/* Reorganized interface - Category first, then product name */}
        <div className="grid grid-cols-1 gap-4 bg-gradient-to-r from-muted/30 to-muted/10 p-4 rounded-lg border border-muted">
          <h3 className="text-lg font-medium">Product Selection</h3>
          <p className="text-sm text-muted-foreground mb-2">
            First select a category, then choose a product from inventory
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-base">Product Category</FormLabel>
                    <Select
                      onValueChange={(value) => {
                        field.onChange(value);
                        setSelectedCategory(value);
                      }}
                      value={selectedCategory}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {categoriesData && categoriesData.length > 0 
                          ? categoriesData.map((category) => (
                              <SelectItem key={category.id} value={category.name}>
                                {category.name}
                              </SelectItem>
                            ))
                          : categories.map(category => (
                              <SelectItem key={category} value={category}>{category}</SelectItem>
                            ))
                        }
                      </SelectContent>
                    </Select>
                    {isCategoriesLoading && 
                      <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                        <Loader2 className="h-3 w-3 animate-spin" /> Loading categories...
                      </div>
                    }
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="space-y-2">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-base">Product Name</FormLabel>
                    <Select
                      onValueChange={(value) => {
                        field.onChange(value);
                        setSelectedProductName(value);
                      }}
                      value={selectedProductName}
                      disabled={!selectedCategory || isProductsLoading}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder={isProductsLoading ? "Loading products..." : "Select product"} />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {productNames.map(product => (
                          <SelectItem key={product} value={product}>{product}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {isProductsLoading && 
                      <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                        <Loader2 className="h-3 w-3 animate-spin" /> Loading products...
                      </div>
                    }
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </div>
          
          {/* Inventory Sources Section */}
          {selectedProductName && (
            <div className="mt-4 space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-base font-medium">Inventory Sources</h4>
                {isFarmersLoading && 
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Loader2 className="h-3 w-3 animate-spin" /> Loading sources...
                  </div>
                }
              </div>
              
              <div className="border rounded-md">
                <ScrollArea className="h-48 rounded-md">
                  <div className="p-4 space-y-2">
                    {farmersByProduct.length > 0 ? (
                      farmersByProduct.map((farmer: any) => (
                        <div key={farmer.id} className="flex items-center justify-between p-2 border border-muted rounded-md">
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id={`farmer-${farmer.id}`}
                              checked={selectedFarmerIds.includes(farmer.id)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  setSelectedFarmerIds([...selectedFarmerIds, farmer.id]);
                                  // Also update form state for submission
                                  const currentIds = form.getValues("farmerIds") || [];
                                  form.setValue("farmerIds", [...currentIds, farmer.id], { shouldDirty: true });
                                } else {
                                  setSelectedFarmerIds(selectedFarmerIds.filter((id: number) => id !== farmer.id));
                                  // Update form state
                                  const currentIds = form.getValues("farmerIds") || [];
                                  form.setValue("farmerIds", currentIds.filter((id: number) => id !== farmer.id), { shouldDirty: true });
                                }
                              }}
                            />
                            <label
                              htmlFor={`farmer-${farmer.id}`}
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              {farmer.name}
                            </label>
                          </div>
                          <Badge variant="outline" className="ml-2">
                            {farmer.totalQuantity} {farmer.unit}
                          </Badge>
                        </div>
                      ))
                    ) : (
                      <div className="flex justify-center items-center h-full py-8 text-muted-foreground">
                        No farmers have this product in inventory
                      </div>
                    )}
                  </div>
                </ScrollArea>
              </div>
              
              {/* Source summary */}
              {inventorySources.length > 0 && (
                <Card className="overflow-hidden bg-gradient-to-r from-primary/5 to-primary/10 border border-primary/20">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center mb-2">
                      <h3 className="font-medium">Combined Inventory</h3>
                      <div className="text-xl font-bold text-primary">
                        Total: {totalQuantity} {selectedUnit}
                      </div>
                    </div>
                    <ScrollArea className="h-24">
                      <div className="space-y-2">
                        {inventorySources.map(source => (
                          <div 
                            key={source.id} 
                            className="flex justify-between items-center p-2 border-b border-muted text-sm"
                          >
                            <span>{source.name}</span>
                            <Badge variant="secondary">{source.totalQuantity} {source.unit}</Badge>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              )}
            </div>
          )}
        </div>
        
        {/* Product Details Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-4">
            <div className="flex gap-2 items-start">
              <FormField
                control={form.control}
                name="price"
                render={({ field }) => (
                  <FormItem className="flex-1">
                    <FormLabel>Price</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min="0" 
                        step="0.01" 
                        placeholder="0.00" 
                        {...field}
                        onChange={(e) => field.onChange(parseFloat(e.target.value))} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="currency"
                render={({ field }) => (
                  <FormItem className="w-1/3">
                    <FormLabel>Currency</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      value={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select currency" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {getCurrencyOptions().map(option => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </div>
          <FormField
            control={form.control}
            name="quantityAvailable"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Quantity Available</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="0" 
                    step="0.1" 
                    placeholder="0" 
                    {...field}
                    onChange={(e) => field.onChange(parseFloat(e.target.value))} 
                    className={totalQuantity > 0 ? "bg-muted/50 pointer-events-none" : ""}
                    readOnly={totalQuantity > 0}
                  />
                </FormControl>
                {totalQuantity > 0 && (
                  <FormDescription>
                    Automatically calculated from selected inventory sources
                  </FormDescription>
                )}
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="unit"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Unit</FormLabel>
                <Select
                  onValueChange={field.onChange}
                  value={field.value}
                  disabled={totalQuantity > 0}
                >
                  <FormControl>
                    <SelectTrigger className={totalQuantity > 0 ? "bg-muted/50 pointer-events-none" : ""}>
                      <SelectValue placeholder="Select unit" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {units.map(unit => (
                      <SelectItem key={unit} value={unit}>{unit}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {totalQuantity > 0 && (
                  <FormDescription>
                    Automatically set from selected inventory sources
                  </FormDescription>
                )}
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="expiryDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Expiry Date</FormLabel>
                <FormControl>
                  <Input 
                    type="date" 
                    {...field} 
                    value={cleanInputValue(field.value as string)}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Product description" 
                  className="min-h-[100px]" 
                  {...field}
                  value={cleanInputValue(field.value)}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="image"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Image URL</FormLabel>
              <FormControl>
                <Input 
                  placeholder="https://example.com/image.jpg" 
                  {...field}
                  value={cleanInputValue(field.value)}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* This field remains for database compatibility but will use the first selected farmer */}
          <FormField
            control={form.control}
            name="farmerId"
            render={({ field }) => (
              <FormItem className="hidden">
                <FormControl>
                  <Input type="hidden" {...field} />
                </FormControl>
              </FormItem>
            )}
          />
          
          {/* Replaced Primary Farmer with Inventory Sources section */}
          <FormItem>
            <div className="space-y-2">
              <FormLabel className="text-base font-medium">Inventory Sources</FormLabel>
              <FormDescription>
                Select farmers with inventory of this product to create a combined marketplace listing
              </FormDescription>
              
              <TooltipProvider>
                <div className="relative">
                  <Card className="bg-muted/30 border overflow-hidden">
                    <CardContent className="p-4">
                      {selectedFarmerIds.length === 0 ? (
                        <div className="text-center py-6 text-muted-foreground">
                          No inventory sources selected. Please select at least one source above.
                        </div>
                      ) : (
                        <div className="space-y-4">
                          <div className="grid grid-cols-1 gap-2">
                            {inventorySources.map(source => (
                              <div 
                                key={source.id}
                                className="flex items-center justify-between p-2 border border-border rounded-md bg-background"
                              >
                                <div className="flex items-center gap-2">
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        className="h-6 w-6 rounded-full bg-primary/10 text-primary hover:bg-primary/20"
                                        onClick={() => {
                                          // Remove this source
                                          setSelectedFarmerIds(selectedFarmerIds.filter((id: number) => id !== source.id));
                                          const currentIds = form.getValues("farmerIds") || [];
                                          form.setValue("farmerIds", currentIds.filter((id: number) => id !== source.id), { shouldDirty: true });
                                          
                                          // Also update the primary farmerId field if this was the selected farmer
                                          if (form.getValues("farmerId") === source.id && selectedFarmerIds.length > 1) {
                                            // Find another farmer from the remaining ones
                                            const newPrimaryId = selectedFarmerIds.find((id: number) => id !== source.id);
                                            if (newPrimaryId) {
                                              form.setValue("farmerId", newPrimaryId, { shouldDirty: true });
                                            }
                                          }
                                        }}
                                      >
                                        <ChevronUp className="h-4 w-4" />
                                      </Button>
                                    </TooltipTrigger>
                                    <TooltipContent side="top">
                                      <p>Remove this source</p>
                                    </TooltipContent>
                                  </Tooltip>
                                  
                                  <span className="font-medium">{source.name}</span>
                                </div>
                                <Badge variant="secondary">
                                  {source.totalQuantity} {source.unit}
                                </Badge>
                              </div>
                            ))}
                          </div>
                          
                          <div className="flex items-center justify-between pt-2 border-t border-border">
                            <div className="text-sm font-medium">Total Combined Inventory:</div>
                            <Badge className="text-lg py-1" variant="default">
                              {totalQuantity} {selectedUnit}
                            </Badge>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </TooltipProvider>
            </div>
          </FormItem>
          <FormField
            control={form.control}
            name="storageUnitId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Storage Unit</FormLabel>
                <Select
                  onValueChange={(value) => field.onChange(parseInt(value))}
                  value={field.value?.toString()}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select storage unit" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {availableStorageUnits.map(unit => (
                      <SelectItem key={unit.id} value={unit.id.toString()}>
                        {unit.unitId} - {unit.location}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormDescription>
                  Which storage unit this product is associated with
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="isListed"
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
              <div className="space-y-0.5">
                <FormLabel>List in Marketplace</FormLabel>
                <FormDescription>
                  Whether to display this product in the marketplace
                </FormDescription>
              </div>
              <FormControl>
                <Switch
                  checked={field.value}
                  onCheckedChange={field.onChange}
                />
              </FormControl>
            </FormItem>
          )}
        />

        <div className="flex justify-end space-x-2 pt-4">
          <Button 
            type="button" 
            variant="outline" 
            onClick={() => onSuccess && onSuccess()}
          >
            Cancel
          </Button>
          <Button 
            type="submit" 
            disabled={isSubmitting}
          >
            {isSubmitting ? "Saving..." : (product ? "Update" : "Create")}
          </Button>
        </div>
      </form>
    </Form>
  );
}