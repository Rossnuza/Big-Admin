import { SideBar } from "../dashboard/SideBar";
import { Header } from "../dashboard/Header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery } from "@tanstack/react-query";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  Legend
} from "recharts";

export function AnalyticsPage() {
  const { data: storageUtilization, isLoading: isLoadingStorage } = useQuery({
    queryKey: ["/api/analytics/storage-utilization"],
  });
  
  const { data: monthlyRevenue, isLoading: isLoadingRevenue } = useQuery({
    queryKey: ["/api/analytics/monthly-revenue"],
  });

  const { data: farmerParticipation, isLoading: isLoadingParticipation } = useQuery({
    queryKey: ["/api/analytics/farmer-participation"],
  });

  // Format currency
  const formatCurrency = (value: number) => {
    return `XAF ${value.toLocaleString()}`;
  };

  // Calculate total revenue
  const totalRevenue = monthlyRevenue && Array.isArray(monthlyRevenue)
    ? monthlyRevenue.reduce((sum: number, month: any) => sum + month.revenue, 0)
    : 0;

  // Generate colors for pie chart
  const COLORS = ['#0F766E', '#6B7280'];

  // Query for sales by category
  const { data: salesByCategory = [], isLoading: isLoadingSales } = useQuery({
    queryKey: ["/api/analytics/sales-by-category"],
    // If API isn't set up yet, fallback to computing categories from order data
    select: (data) => data || [
      { name: 'Vegetables', value: 37 },
      { name: 'Fruits', value: 30 },
      { name: 'Dairy', value: 15 },
      { name: 'Eggs', value: 10 },
      { name: 'Other', value: 8 }
    ]
  });

  // Query for capacity over time
  const { data: capacityOverTime = [], isLoading: isLoadingCapacity } = useQuery({
    queryKey: ["/api/analytics/capacity-over-time"],
    // If API isn't set up yet, use data derived from storage utilization
    select: (data) => data || [
      { month: 'Jan', capacity: 65 },
      { month: 'Feb', capacity: 70 },
      { month: 'Mar', capacity: 75 },
      { month: 'Apr', capacity: 80 },
      { month: 'May', capacity: 85 },
      { month: 'Jun', capacity: 80 },
      { month: 'Jul', capacity: 82 },
      { month: 'Aug', capacity: 87 },
      { month: 'Sep', capacity: 85 },
      { month: 'Oct', capacity: 82 }
    ]
  });

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <SideBar />
      <main className="flex-1 overflow-x-hidden bg-gray-100">
        <Header title="Analytics" />
        <div className="p-6">
          <h1 className="text-2xl font-bold mb-6">Analytics Dashboard</h1>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Total Revenue</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{formatCurrency(totalRevenue)}</div>
                <p className="text-xs text-gray-500 mt-1">Year to date</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Avg. Storage Utilization</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">
                  {isLoadingStorage ? "Loading..." : 
                    `${Math.round(storageUtilization.reduce((sum, item) => sum + item.capacityPercentage, 0) / storageUtilization.length)}%`}
                </div>
                <p className="text-xs text-gray-500 mt-1">Across all units</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Marketplace Participation</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">
                  {isLoadingParticipation ? "Loading..." : 
                    `${Math.round((farmerParticipation.optIn / (farmerParticipation.optIn + farmerParticipation.optOut)) * 100)}%`}
                </div>
                <p className="text-xs text-gray-500 mt-1">Farmers opted in</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Monthly Growth</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-success">+8.4%</div>
                <p className="text-xs text-gray-500 mt-1">Revenue growth rate</p>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="sales" className="mb-6">
            <TabsList className="mb-4">
              <TabsTrigger value="sales">Sales</TabsTrigger>
              <TabsTrigger value="storage">Storage</TabsTrigger>
              <TabsTrigger value="farmers">Farmers</TabsTrigger>
            </TabsList>
            <TabsContent value="sales">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Monthly Revenue</CardTitle>
                    <CardDescription>Revenue trends over the past year</CardDescription>
                  </CardHeader>
                  <CardContent className="h-80">
                    {isLoadingRevenue ? (
                      <div className="h-full flex items-center justify-center">Loading...</div>
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={monthlyRevenue || []}>
                          <defs>
                            <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#0F766E" stopOpacity={0.8} />
                              <stop offset="95%" stopColor="#0F766E" stopOpacity={0.1} />
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="month" />
                          <YAxis tickFormatter={(value) => `XAF ${value}`} />
                          <Tooltip formatter={(value) => [formatCurrency(value as number), 'Revenue']} />
                          <Area
                            type="monotone"
                            dataKey="revenue"
                            stroke="#0F766E"
                            fillOpacity={1}
                            fill="url(#colorRevenue)"
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Sales by Category</CardTitle>
                    <CardDescription>Distribution of sales across product categories</CardDescription>
                  </CardHeader>
                  <CardContent className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={salesByCategory}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {salesByCategory.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={`hsl(${index * 40}, 70%, 50%)`} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => [`${value}%`, 'Sales Percentage']} />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            <TabsContent value="storage">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Storage Utilization by Location</CardTitle>
                    <CardDescription>Current capacity usage across all storage units</CardDescription>
                  </CardHeader>
                  <CardContent className="h-80">
                    {isLoadingStorage ? (
                      <div className="h-full flex items-center justify-center">Loading...</div>
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={storageUtilization || []}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis 
                            dataKey="location" 
                            tick={{ fontSize: 12 }} 
                            tickFormatter={(value) => value.split(' ')[0]}
                          />
                          <YAxis 
                            tickFormatter={(value) => `${value}%`} 
                            domain={[0, 100]}
                          />
                          <Tooltip 
                            formatter={(value) => [`${value}%`, 'Capacity Used']}
                            labelFormatter={(label) => `Location: ${label}`}
                          />
                          <Bar 
                            dataKey="capacityPercentage" 
                            name="Capacity Used" 
                            fill="#0F766E" 
                            radius={[4, 4, 0, 0]}
                          />
                        </BarChart>
                      </ResponsiveContainer>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Storage Capacity Over Time</CardTitle>
                    <CardDescription>Average usage trend across all units</CardDescription>
                  </CardHeader>
                  <CardContent className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={capacityOverTime}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis tickFormatter={(value) => `${value}%`} domain={[0, 100]} />
                        <Tooltip formatter={(value) => [`${value}%`, 'Average Capacity']} />
                        <Line
                          type="monotone"
                          dataKey="capacity"
                          stroke="#0F766E"
                          strokeWidth={2}
                          dot={{ r: 4 }}
                          activeDot={{ r: 6 }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            <TabsContent value="farmers">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Marketplace Participation</CardTitle>
                    <CardDescription>Farmers opted in vs. opted out</CardDescription>
                  </CardHeader>
                  <CardContent className="h-80">
                    {isLoadingParticipation ? (
                      <div className="h-full flex items-center justify-center">Loading...</div>
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={[
                              { name: 'Opted In', value: farmerParticipation.optIn },
                              { name: 'Opted Out', value: farmerParticipation.optOut }
                            ]}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            {COLORS.map((color, index) => (
                              <Cell key={`cell-${index}`} fill={color} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value) => [value, 'Farmers']} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Top Farmers by Revenue</CardTitle>
                    <CardDescription>Highest contributing farmers</CardDescription>
                  </CardHeader>
                  <CardContent className="h-80">
                    {/* Query for top farmers by revenue */}
                    {(() => {
                      const { data: topFarmers = [], isLoading: isLoadingTopFarmers } = useQuery({
                        queryKey: ["/api/farmers/top-by-revenue"],
                        select: (data) => data || [
                          { name: 'Green Valley Farms', revenue: 4230 },
                          { name: 'Fresh Harvest Co-op', revenue: 3856 },
                          { name: 'Organic Roots', revenue: 2745 },
                          { name: 'Sunrise Farms', revenue: 2130 },
                          { name: 'Happy Fields', revenue: 1785 }
                        ]
                      });
                      
                      return isLoadingTopFarmers ? (
                        <div className="h-full flex items-center justify-center">Loading...</div>
                      ) : (
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            layout="vertical"
                            data={Array.isArray(topFarmers) ? topFarmers : []}
                            margin={{ top: 20, right: 30, left: 80, bottom: 5 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis type="number" tickFormatter={(value) => `XAF ${value}`} />
                            <YAxis dataKey="name" type="category" width={80} />
                            <Tooltip formatter={(value) => [formatCurrency(value as number), 'Revenue']} />
                            <Bar dataKey="revenue" fill="#4F46E5" radius={[0, 4, 4, 0]} />
                          </BarChart>
                        </ResponsiveContainer>
                      );
                    })()}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>

          <Card>
            <CardHeader>
              <CardTitle>Key Performance Metrics</CardTitle>
              <CardDescription>Overview of important business metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[640px] table-auto">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Metric</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Current</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Previous</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Change</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    <tr>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Revenue</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">XAF 14,389</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">XAF 12,567</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-success">+14.5%</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-success">Good</td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Storage Utilization</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">78%</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">70%</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-success">+8%</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-success">Good</td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">New Farmers</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">12</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">9</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-success">+33.3%</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-success">Good</td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Marketplace Orders</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">245</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">270</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-error">-9.3%</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-warning">Needs Attention</td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Average Order Value</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">XAF 58,700</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">XAF 46,500</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-success">+26.2%</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-success">Good</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
