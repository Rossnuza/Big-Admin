import * as React from "react";
import { CalendarIcon, X } from "lucide-react";
import { format, subDays } from "date-fns";
import { DateRange } from "react-day-picker";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

interface DateRangePickerProps {
  className?: string;
  dateRange: DateRange | undefined;
  setDateRange: (dateRange: DateRange | undefined) => void;
  label?: string;
}

export function DateRangePicker({
  className,
  dateRange,
  setDateRange,
  label = "Select a date range",
}: DateRangePickerProps) {
  return (
    <div className={cn("grid gap-2", className)}>
      <Popover>
        <PopoverTrigger asChild>
          <Button
            id="date"
            variant={"outline"}
            className={cn(
              "w-full justify-start text-left font-normal",
              !dateRange && "text-muted-foreground"
            )}
          >
            <CalendarIcon className="mr-2 h-4 w-4" />
            {dateRange?.from ? (
              dateRange.to ? (
                <>
                  {format(dateRange.from, "LLL dd, y")} -{" "}
                  {format(dateRange.to, "LLL dd, y")}
                </>
              ) : (
                format(dateRange.from, "LLL dd, y")
              )
            ) : (
              <span>{label}</span>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <Calendar
            initialFocus
            mode="range"
            defaultMonth={dateRange?.from}
            selected={dateRange}
            onSelect={setDateRange}
            numberOfMonths={2}
          />
        </PopoverContent>
      </Popover>
    </div>
  );
}

// A more complex version with a toolbar
interface DatePickerWithRangeProps {
  className?: string;
  date: DateRange | undefined;
  setDate: (date: DateRange | undefined) => void;
  showCompare?: boolean;
  align?: "center" | "start" | "end";
}

export function DatePickerWithRange({
  className,
  date,
  setDate,
  showCompare = false,
  align = "start",
}: DatePickerWithRangeProps) {
  const [isOpen, setIsOpen] = React.useState(false);

  // Predefined ranges for common time periods
  const handleSelectLast7Days = () => {
    const today = new Date();
    const from = subDays(today, 6);
    setDate({ from, to: today });
    setIsOpen(false);
  };

  const handleSelectLast30Days = () => {
    const today = new Date();
    const from = subDays(today, 29);
    setDate({ from, to: today });
    setIsOpen(false);
  };

  const handleSelectLast90Days = () => {
    const today = new Date();
    const from = subDays(today, 89);
    setDate({ from, to: today });
    setIsOpen(false);
  };

  const handleClearDate = () => {
    setDate({ from: undefined, to: undefined });
  };

  return (
    <div className={cn("grid gap-2", className)}>
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button
            id="date"
            variant={"outline"}
            className={cn(
              "w-full justify-start text-left font-normal",
              !date && "text-muted-foreground"
            )}
          >
            <CalendarIcon className="mr-2 h-4 w-4" />
            {date?.from ? (
              date.to ? (
                <>
                  {format(date.from, "LLL dd, y")} -{" "}
                  {format(date.to, "LLL dd, y")}
                </>
              ) : (
                format(date.from, "LLL dd, y")
              )
            ) : (
              <span>Pick a date</span>
            )}
            {date?.from && (
              <X
                className="ml-auto h-4 w-4 opacity-50 hover:opacity-100"
                onClick={(e) => {
                  e.stopPropagation();
                  handleClearDate();
                }}
              />
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto flex flex-col p-0" align={align}>
          <div className="p-2 border-b">
            <div className="flex space-x-2">
              <Button
                size="sm"
                variant="ghost"
                onClick={handleSelectLast7Days}
              >
                Last 7 days
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={handleSelectLast30Days}
              >
                Last 30 days
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={handleSelectLast90Days}
              >
                Last 90 days
              </Button>
            </div>
          </div>
          <Calendar
            initialFocus
            mode="range"
            defaultMonth={date?.from}
            selected={date}
            onSelect={(newDate) => {
              if (newDate?.from && newDate?.to) {
                setDate(newDate as DateRange);
                setIsOpen(false);
              } else {
                setDate(newDate as DateRange);
              }
            }}
            numberOfMonths={2}
          />
        </PopoverContent>
      </Popover>
    </div>
  );
}