import { useCurrency } from "@/lib/currency-context";
import { formatCurrency } from "@/lib/currency";
import { cn } from "@/lib/utils";

interface CurrencyDisplayProps {
  amount: number;
  className?: string;
  showSymbol?: boolean;
  size?: "sm" | "md" | "lg";
}

export function CurrencyDisplay({ 
  amount, 
  className, 
  showSymbol = true,
  size = "md"
}: CurrencyDisplayProps) {
  const { activeCurrency } = useCurrency();
  
  const sizeClasses = {
    sm: "text-sm",
    md: "text-base",
    lg: "text-xl font-semibold"
  };
  
  return (
    <span className={cn(sizeClasses[size], className)}>
      {formatCurrency(amount, activeCurrency)}
    </span>
  );
}