import { useWebSocket } from "@/lib/websocket-context";
import { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Wifi, WifiOff, Loader2, Info, Bell, BellOff, RotateCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { PingMessage } from "@shared/websocket-types";

export function WebSocketStatus() {
  const { connected, connecting, reconnect, sendMessage } = useWebSocket();
  const [showControls, setShowControls] = useState(false);
  const [messageCount, setMessageCount] = useState(0);
  const [lastMessage, setLastMessage] = useState<string | null>(null);
  const [showNotifications, setShowNotifications] = useState(true);
  
  // Hide the full controls after a period of inactivity
  useEffect(() => {
    if (showControls) {
      const timer = setTimeout(() => {
        setShowControls(false);
      }, 10000); // Hide after 10 seconds
      
      return () => clearTimeout(timer);
    }
  }, [showControls]);
  
  // Listen for WebSocket messages to keep track of message count and last message
  useEffect(() => {
    const handleMessage = (event: CustomEvent) => {
      setMessageCount((prev) => prev + 1);
      setLastMessage(event.detail.type);
    };
    
    window.addEventListener('coldfarms:ws-message', handleMessage as EventListener);
    
    return () => {
      window.removeEventListener('coldfarms:ws-message', handleMessage as EventListener);
    };
  }, []);
  
  // Ping function - sends a simple ping message to test the connection
  const handlePing = () => {
    if (connected) {
      const pingMessage: PingMessage = {
        type: "ping",
        data: { timestamp: new Date().toISOString() }
      };
      sendMessage(pingMessage);
    }
  };
  
  if (!showControls) {
    return (
      <div 
        className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 items-end"
        onClick={() => setShowControls(true)}
      >
        {connected ? (
          <Badge className="cursor-pointer bg-green-600 hover:bg-green-700">
            <Wifi className="h-4 w-4 mr-1" />
            Connected {messageCount > 0 && `(${messageCount})`}
          </Badge>
        ) : connecting ? (
          <Badge className="cursor-pointer bg-yellow-500 hover:bg-yellow-600">
            <Loader2 className="h-4 w-4 mr-1 animate-spin" />
            Connecting
          </Badge>
        ) : (
          <Badge className="cursor-pointer bg-red-600 hover:bg-red-700">
            <WifiOff className="h-4 w-4 mr-1" />
            Disconnected
          </Badge>
        )}
        
        {lastMessage && showNotifications && (
          <Badge className="cursor-pointer bg-blue-600 hover:bg-blue-700" variant="outline">
            <Info className="h-4 w-4 mr-1" />
            {lastMessage}
          </Badge>
        )}
      </div>
    );
  }
  
  return (
    <div className="fixed bottom-4 right-4 z-50 p-4 bg-background border rounded-md shadow-lg max-w-xs w-full">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-medium text-lg">WebSocket Status</h3>
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => setShowControls(false)}
        >
          Hide
        </Button>
      </div>
      
      <div className="space-y-4">
        <div className="flex items-center">
          <div className="mr-3">
            {connected ? (
              <Badge className="bg-green-600">
                <Wifi className="h-4 w-4 mr-1" />
                Connected
              </Badge>
            ) : connecting ? (
              <Badge className="bg-yellow-500">
                <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                Connecting
              </Badge>
            ) : (
              <Badge className="bg-red-600">
                <WifiOff className="h-4 w-4 mr-1" />
                Disconnected
              </Badge>
            )}
          </div>
          
          <Button 
            size="sm" 
            variant="outline"
            disabled={connecting} 
            onClick={reconnect}
          >
            <RotateCw className="h-4 w-4 mr-1" />
            Reconnect
          </Button>
        </div>
        
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div className="font-medium">Messages received:</div>
          <div>{messageCount}</div>
          
          {lastMessage && (
            <>
              <div className="font-medium">Last message:</div>
              <div className="truncate">{lastMessage}</div>
            </>
          )}
        </div>
        
        <div className="flex flex-wrap gap-2">
          <Button 
            size="sm" 
            variant="outline"
            disabled={!connected} 
            onClick={handlePing}
          >
            Ping
          </Button>
          
          <Button 
            size="sm" 
            variant={showNotifications ? "default" : "outline"}
            onClick={() => setShowNotifications(!showNotifications)}
          >
            {showNotifications ? (
              <>
                <BellOff className="h-4 w-4 mr-1" />
                Hide Notifications
              </>
            ) : (
              <>
                <Bell className="h-4 w-4 mr-1" />
                Show Notifications
              </>
            )}
          </Button>
        </div>
        
        <div className="text-xs text-muted-foreground">
          Click anywhere outside this panel to minimize it.
        </div>
      </div>
    </div>
  );
}