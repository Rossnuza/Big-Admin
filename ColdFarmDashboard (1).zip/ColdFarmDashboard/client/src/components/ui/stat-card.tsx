import { Card, CardContent } from "@/components/ui/card";
import { ArrowDown, ArrowUp } from "lucide-react";
import { ReactNode } from "react";

interface StatCardProps {
  title: string;
  value: string | number;
  icon: ReactNode;
  iconBgClass: string;
  change?: {
    value: number;
    isPositive: boolean;
  };
  subtitle?: string;
}

export function StatCard({
  title,
  value,
  icon,
  iconBgClass,
  change,
  subtitle = "from last month",
}: StatCardProps) {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500">{title}</p>
            <p className="text-3xl font-bold text-gray-900 mt-1">{value}</p>
          </div>
          <div className={`${iconBgClass} p-3 rounded-full`}>
            {icon}
          </div>
        </div>
        {change && (
          <div className="mt-4 flex items-center">
            <span className={`flex items-center text-sm font-medium ${change.isPositive ? 'text-success' : 'text-error'}`}>
              {change.isPositive ? <ArrowUp className="h-4 w-4 mr-1" /> : <ArrowDown className="h-4 w-4 mr-1" />}
              {Math.abs(change.value)}%
            </span>
            <span className="text-gray-500 text-sm ml-2">{subtitle}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
