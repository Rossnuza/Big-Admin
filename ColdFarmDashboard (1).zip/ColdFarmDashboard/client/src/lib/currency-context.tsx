import React, { createContext, useState, useContext, useEffect, ReactNode } from "react";
import { currencies, defaultCurrency } from "./currency";

// Define context type
interface CurrencyContextType {
  activeCurrency: string;
  setActiveCurrency: (code: string) => void;
}

// Create the context with default values
const CurrencyContext = createContext<CurrencyContextType>({
  activeCurrency: defaultCurrency,
  setActiveCurrency: () => {},
});

// Create provider component
export function CurrencyProvider({ children }: { children: ReactNode }) {
  // Initialize with stored value or default
  const [activeCurrency, setActiveCurrency] = useState<string>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("coldfarmsActiveCurrency");
      return saved || defaultCurrency;
    }
    return defaultCurrency;
  });

  // Save to localStorage when value changes
  useEffect(() => {
    localStorage.setItem("coldfarmsActiveCurrency", activeCurrency);
  }, [activeCurrency]);

  return (
    <CurrencyContext.Provider value={{ activeCurrency, setActiveCurrency }}>
      {children}
    </CurrencyContext.Provider>
  );
}

// Hook for accessing currency context
export function useCurrency() {
  const context = useContext(CurrencyContext);
  if (!context) {
    throw new Error("useCurrency must be used within a CurrencyProvider");
  }
  return context;
}