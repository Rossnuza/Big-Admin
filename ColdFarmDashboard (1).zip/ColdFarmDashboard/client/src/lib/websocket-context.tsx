import React, { createContext, useContext, useEffect, useState, useCallback, ReactNode } from 'react';
import { useToast } from '@/hooks/use-toast';
import { 
  WebSocketMessage, 
  AuthMessage, 
  PingMessage,
  ErrorMessage 
} from '@shared/websocket-types';

// Export the WebSocketMessage type as WSMessage for backward compatibility
export type WSMessage = WebSocketMessage;

// Define the WebSocket context interface
interface WebSocketContextType {
  connected: boolean;
  connecting: boolean;
  sendMessage: (message: WebSocketMessage) => boolean;
  authenticateFarmer: (farmerId: number) => boolean;
  reconnect: () => void;
  disconnect: () => void;
}

// Create the context with default values
const WebSocketContext = createContext<WebSocketContextType>({
  connected: false,
  connecting: false,
  sendMessage: () => false,
  authenticateFarmer: () => false,
  reconnect: () => {},
  disconnect: () => {},
});

// Custom hook to use the WebSocket context
export const useWebSocket = () => useContext(WebSocketContext);

// WebSocketProvider component
export const WebSocketProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [connected, setConnected] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const { toast } = useToast();

  // Function to create a new WebSocket connection
  const connect = useCallback(() => {
    if (socket) return; // Don't connect if already connected

    try {
      setConnecting(true);
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      console.log('Connecting to WebSocket:', wsUrl);
      const newSocket = new WebSocket(wsUrl);
      
      newSocket.onopen = () => {
        console.log('WebSocket connection established');
        setConnected(true);
        setConnecting(false);
      };
      
      newSocket.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);
          console.log('WebSocket message received:', message);
          
          // Handle different message types here
          if (message.type === 'error') {
            const errorMsg = message as ErrorMessage;
            toast({
              title: 'WebSocket Error',
              description: errorMsg.error?.message || 'An error occurred',
              variant: 'destructive',
            });
          }
          
          // Dispatch a custom event for other components to listen to
          const customEvent = new CustomEvent('coldfarms:ws-message', { 
            detail: message 
          });
          window.dispatchEvent(customEvent);
          
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      };
      
      newSocket.onclose = (event) => {
        console.log(`WebSocket connection closed: ${event.code} ${event.reason}`);
        setConnected(false);
        setConnecting(false);
        setSocket(null);
        
        // Attempt to reconnect after a delay, with exponential backoff
        // Code 1000 is normal closure (intentional)
        if (event.code !== 1000) {
          // Code explanations for better debugging:
          let explanation = "";
          switch (event.code) {
            case 1001: explanation = "Endpoint going away (server shutdown)"; break;
            case 1002: explanation = "Protocol error"; break;
            case 1003: explanation = "Unsupported data type"; break;
            case 1005: explanation = "No status code was present"; break;
            case 1006: explanation = "Abnormal closure (connection lost)"; break;
            case 1007: explanation = "Invalid frame payload data"; break;
            case 1008: explanation = "Policy violation"; break;
            case 1009: explanation = "Message too big"; break;
            case 1010: explanation = "Extension required by client not supported by server"; break;
            case 1011: explanation = "Server error"; break;
            case 1012: explanation = "Server restarting"; break;
            case 1013: explanation = "Try again later (temporary error)"; break;
            case 1014: explanation = "Bad gateway"; break;
            case 1015: explanation = "TLS handshake failure"; break;
          }
          
          if (explanation) {
            console.log(`WebSocket close explanation: ${explanation}`);
          }
          
          // Exponential backoff for reconnection
          const delay = Math.min(30000, (Math.random() + 1) * 2000);
          console.log(`Attempting to reconnect in ${delay}ms...`);
          setTimeout(() => {
            if (!connected && !connecting) {
              connect();
            }
          }, delay);
        }
      };
      
      newSocket.onerror = (error) => {
        console.error('WebSocket error:', error);
        setConnecting(false);
      };
      
      setSocket(newSocket);
    } catch (error) {
      console.error('Error creating WebSocket:', error);
      setConnecting(false);
    }
  }, [socket, toast]);
  
  // Reconnect function
  const reconnect = useCallback(() => {
    if (socket) {
      socket.close();
      setSocket(null);
    }
    connect();
  }, [socket, connect]);
  
  // Disconnect function
  const disconnect = useCallback(() => {
    if (socket) {
      socket.close();
      setSocket(null);
    }
  }, [socket]);
  
  // Send message function
  const sendMessage = useCallback((message: WSMessage): boolean => {
    if (!socket || socket.readyState !== WebSocket.OPEN) {
      console.error('Cannot send message: WebSocket is not connected');
      return false;
    }
    
    try {
      socket.send(JSON.stringify(message));
      console.log('WebSocket message sent:', message);
      return true;
    } catch (error) {
      console.error('Error sending WebSocket message:', error);
      return false;
    }
  }, [socket]);
  
  // Authenticate as a farmer
  const authenticateFarmer = useCallback((farmerId: number): boolean => {
    const authMessage: AuthMessage = {
      type: 'auth',
      farmerId
    };
    return sendMessage(authMessage);
  }, [sendMessage]);
  
  // Connect on mount
  useEffect(() => {
    connect();
    
    // Cleanup on unmount
    return () => {
      if (socket) {
        socket.close();
      }
    };
  }, [connect, socket]);
  
  // Provide the WebSocket functionality to children
  return (
    <WebSocketContext.Provider
      value={{
        connected,
        connecting,
        sendMessage,
        authenticateFarmer,
        reconnect,
        disconnect,
      }}
    >
      {children}
    </WebSocketContext.Provider>
  );
};