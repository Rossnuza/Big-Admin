import React, { createContext, useState, useContext, useEffect, ReactNode } from "react";
import { apiRequest } from "./queryClient";

export interface User {
  id: number;
  username: string;
  name: string;
  role: string;
  avatar?: string;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<User>;
  register: (userData: { username: string, password: string, name: string, role?: string }) => Promise<User>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check if user is already logged in
    fetch("/api/auth/current-user", {
      credentials: "include",
    })
      .then((res) => {
        if (!res.ok) {
          throw new Error("Not authenticated");
        }
        return res.json();
      })
      .then((data) => {
        setUser(data.user);
      })
      .catch(() => {
        setUser(null);
      })
      .finally(() => {
        setIsLoading(false);
      });
  }, []);

  const login = async (username: string, password: string): Promise<User> => {
    try {
      const res = await apiRequest("POST", "/api/auth/login", { username, password });
      const data = await res.json();
      setUser(data.user);
      return data.user;
    } catch (error) {
      throw new Error("Invalid username or password");
    }
  };

  const register = async (userData: { username: string, password: string, name: string, role?: string }): Promise<User> => {
    try {
      const res = await apiRequest("POST", "/api/auth/register", userData);
      const data = await res.json();
      setUser(data.user);
      return data.user;
    } catch (error) {
      throw new Error("Registration failed");
    }
  };

  const logout = async (): Promise<void> => {
    try {
      await apiRequest("POST", "/api/auth/logout");
      setUser(null);
    } catch (error) {
      console.error("Error logging out", error);
    }
  };

  const resetPassword = async (email: string): Promise<void> => {
    // This would typically send a reset email, but for now we'll just simulate it
    console.log(`Password reset requested for ${email}`);
    // In a real implementation, we would call an API endpoint to trigger an email
  };

  const contextValue: AuthContextType = {
    user, 
    isLoading, 
    login, 
    register, 
    logout, 
    resetPassword
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
