// African countries with major cities
export const africanCountries = [
  {
    name: "Kenya",
    cities: ["Nairobi", "Mombasa", "Kisumu", "Nakuru", "Eldoret"]
  },
  {
    name: "Nigeria",
    cities: ["Lagos", "Abuja", "Kano", "Ibadan", "Port Harcourt"]
  },
  {
    name: "South Africa",
    cities: ["Johannesburg", "Cape Town", "Durban", "Pretoria", "Port Elizabeth"]
  },
  {
    name: "Ghana",
    cities: ["Accra", "Kumasi", "Tamale", "Sekondi-Takoradi", "Cape Coast"]
  },
  {
    name: "Ethiopia",
    cities: ["Addis Ababa", "Dire Dawa", "Mek'ele", "Gondar", "Bahir Dar"]
  },
  {
    name: "Tanzania",
    cities: ["Dar es Salaam", "Mwanza", "Zanzibar City", "Arusha", "Dodoma"]
  },
  {
    name: "Egypt",
    cities: ["Cairo", "Alexandria", "Giza", "Shubra El Kheima", "Port Said"]
  },
  {
    name: "Morocco",
    cities: ["Casablanca", "Rabat", "Fes", "Marrakesh", "Tangier"]
  },
  {
    name: "Senegal",
    cities: ["Dakar", "Touba", "Thiès", "Rufisque", "Kaolack"]
  },
  {
    name: "Rwanda",
    cities: ["Kigali", "Butare", "Gitarama", "Ruhengeri", "Gisenyi"]
  },
  {
    name: "Cameroon",
    cities: ["Douala", "Yaoundé", "Garoua", "Bamenda", "Maroua"]
  },
  {
    name: "Uganda",
    cities: ["Kampala", "Gulu", "Lira", "Mbarara", "Jinja"]
  },
  {
    name: "Côte d'Ivoire",
    cities: ["Abidjan", "Bouaké", "Daloa", "Yamoussoukro", "Korhogo"]
  },
  {
    name: "Zambia",
    cities: ["Lusaka", "Kitwe", "Ndola", "Kabwe", "Chingola"]
  },
  {
    name: "Tunisia",
    cities: ["Tunis", "Sfax", "Sousse", "Kairouan", "Bizerte"]
  }
];

// Helper function to get cities based on country name
export function getCitiesByCountry(countryName: string): string[] {
  const country = africanCountries.find(c => c.name === countryName);
  return country ? country.cities : [];
}

// Get list of just country names
export function getCountryNames(): string[] {
  return africanCountries.map(country => country.name);
}

// Function to generate a storage unit ID based on country, city and count
export function generateStorageUnitId(country: string, city: string, count: number): string {
  // Get country code (first 2 letters)
  const countryCode = country.substring(0, 2).toUpperCase();
  
  // Get city code (first 2 letters)
  const cityCode = city.substring(0, 2).toUpperCase();
  
  // Format the count with leading zeros (e.g., 001, 012, 123)
  const formattedCount = count.toString().padStart(3, '0');
  
  // Generate the ID: CSU-COUNTRY-CITY-COUNT
  return `CSU-${countryCode}-${cityCode}-${formattedCount}`;
}