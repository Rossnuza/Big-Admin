// Available currencies in the system
export const currencies = [
  { code: 'USD', symbol: '$', name: 'US Dollar' },
  { code: 'EUR', symbol: '€', name: 'Euro' },
  { code: 'XAF', symbol: 'FCFA', name: 'Central African CFA Franc' }
];

// Default currency to use
export const defaultCurrency = 'USD';

// Helper function to format currency amount based on currency code
export function formatCurrency(amount: number, currencyCode: string = defaultCurrency): string {
  const currency = currencies.find(c => c.code === currencyCode) || currencies[0];
  
  // For XAF (CFA Franc), we use a different format
  if (currencyCode === 'XAF') {
    return `${amount.toLocaleString()} ${currency.symbol}`;
  }
  
  // For other currencies, we use the standard format
  return `${currency.symbol}${amount.toLocaleString()}`;
}

// Get currency options for select components
export function getCurrencyOptions() {
  return currencies.map(currency => ({
    label: `${currency.name} (${currency.symbol})`,
    value: currency.code
  }));
}