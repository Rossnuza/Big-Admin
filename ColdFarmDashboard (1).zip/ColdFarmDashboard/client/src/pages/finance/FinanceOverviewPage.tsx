import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useCurrency } from "@/lib/currency-context";
import { formatCurrency } from "@/lib/currency";
import { Link } from "wouter";
import { StorageRevenueOverview } from "@/components/finance/StorageRevenueOverview";
import { FinanceLayout } from "@/components/finance/FinanceLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { DatePickerWithRange } from "@/components/ui/date-range-picker";
import { DateRange } from "react-day-picker";
import { 
  DollarSign, 
  CreditCard, 
  TrendingUp, 
  Wallet, 
  BarChart4, 
  PieChart,
  ArrowUpRight, 
  ArrowDownRight, 
  Percent,
  Warehouse,
  ShoppingCart,
  Plus,
  Download,
  RefreshCw,
  Filter,
  Search,
  Home,
  ArrowLeft,
  ChevronDown,
  FileSpreadsheet,
  Calendar
} from "lucide-react";
import { 
  BarChart, 
  Bar, 
  LineChart,
  Line,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend,
  ResponsiveContainer 
} from "recharts";

// Sample revenue data with separate streams
const detailedRevenueData = [
  { month: "Jan", storageRevenue: 150000, marketplaceRevenue: 30000, totalRevenue: 180000 },
  { month: "Feb", storageRevenue: 160000, marketplaceRevenue: 32000, totalRevenue: 192000 },
  { month: "Mar", storageRevenue: 170000, marketplaceRevenue: 35000, totalRevenue: 205000 },
  { month: "Apr", storageRevenue: 175000, marketplaceRevenue: 40000, totalRevenue: 215000 },
  { month: "May", storageRevenue: 180000, marketplaceRevenue: 43000, totalRevenue: 223000 },
  { month: "Jun", storageRevenue: 190000, marketplaceRevenue: 48000, totalRevenue: 238000 },
  { month: "Jul", storageRevenue: 195000, marketplaceRevenue: 52000, totalRevenue: 247000 },
  { month: "Aug", storageRevenue: 192000, marketplaceRevenue: 55000, totalRevenue: 247000 },
  { month: "Sep", storageRevenue: 188000, marketplaceRevenue: 53000, totalRevenue: 241000 },
  { month: "Oct", storageRevenue: 185000, marketplaceRevenue: 51000, totalRevenue: 236000 },
  { month: "Nov", storageRevenue: 180000, marketplaceRevenue: 49000, totalRevenue: 229000 },
  { month: "Dec", storageRevenue: 178000, marketplaceRevenue: 47000, totalRevenue: 225000 },
];

// Revenue by location data - updated to match higher revenue scale
const revenueByLocation = [
  { name: "Amsterdam", value: 380000 },
  { name: "Cape Town", value: 270000 },
  { name: "Lagos", value: 350000 },
  { name: "Nairobi", value: 250000 },
];

// Farmer payment analysis data
const farmerPaymentData = [
  { month: "Jan", paid: 2200, pending: 300 },
  { month: "Feb", paid: 2400, pending: 350 },
  { month: "Mar", paid: 2600, pending: 400 },
  { month: "Apr", paid: 2800, pending: 450 },
  { month: "May", paid: 3000, pending: 500 },
  { month: "Jun", paid: 3200, pending: 550 },
];

// Colors for the pie chart
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

export default function FinanceOverviewPage() {
  const { activeCurrency } = useCurrency();
  
  // Fetch monthly revenue data 
  const { data: revenueData } = useQuery<{ month: string; revenue: number }[]>({
    queryKey: ["/api/analytics/monthly-revenue"],
    placeholderData: detailedRevenueData.map(item => ({ 
      month: item.month, 
      revenue: item.totalRevenue 
    })),
  });

  // Fetch storage costs data for accurate revenue
  const { data: storageCosts } = useQuery<{
    totalRevenue: number,
    formattedTotalRevenue: string,
    farmers: any[]
  }>({
    queryKey: ["/api/finance/storage-costs"],
    queryFn: async () => {
      const response = await fetch("/api/finance/storage-costs");
      if (!response.ok) {
        throw new Error("Failed to fetch storage costs");
      }
      return response.json();
    },
  });

  // Financial summary statistics based on actual data
  const financialStats = {
    totalRevenue: 2500000,
    storageRevenue: storageCosts?.totalRevenue || 1800000, // Use actual storage revenue
    marketplaceRevenue: 500000,
    pendingPayments: 150000,
    paidInvoices: 2350000,
    outstandingInvoices: 150000,
    growthMoM: 8.5,
    growthYoY: 22.3
  };

  // Create date range state for revenue filtering
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: new Date(new Date().getFullYear(), 0, 1), // January 1st of current year
    to: new Date(),
  });

  return (
    <FinanceLayout title="Finance & Revenue Overview">
      {/* Quick Action Buttons */}
      <div className="flex flex-wrap gap-3 mb-6">
        <Button className="shadow-sm">
          <Plus className="mr-2 h-4 w-4" />
          New Invoice
        </Button>
        <Button variant="outline" className="shadow-sm">
          <Download className="mr-2 h-4 w-4" />
          Export Reports
        </Button>
        <Button variant="outline" className="shadow-sm">
          <RefreshCw className="mr-2 h-4 w-4" />
          Sync Data
        </Button>
      </div>

      {/* Revenue Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Revenue</p>
                <p className="text-3xl font-bold mt-1">
                  {formatCurrency(financialStats.totalRevenue, activeCurrency)}
                </p>
                <div className="flex items-center mt-1 text-sm text-green-600">
                  <ArrowUpRight className="h-3 w-3 mr-1" />
                  <span>{financialStats.growthYoY}% vs last year</span>
                </div>
              </div>
              <div className="bg-green-100 p-3 rounded-full">
                <DollarSign className="h-5 w-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Storage Revenue</p>
                <p className="text-3xl font-bold mt-1">
                  {formatCurrency(financialStats.storageRevenue, activeCurrency)}
                </p>
                <div className="flex items-center mt-1 text-sm text-green-600">
                  <ArrowUpRight className="h-3 w-3 mr-1" />
                  <span>5.2% vs last month</span>
                </div>
              </div>
              <div className="bg-blue-100 p-3 rounded-full">
                <Warehouse className="h-5 w-5 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Marketplace Revenue</p>
                <p className="text-3xl font-bold mt-1">
                  {formatCurrency(financialStats.marketplaceRevenue, activeCurrency)}
                </p>
                <div className="flex items-center mt-1 text-sm text-green-600">
                  <ArrowUpRight className="h-3 w-3 mr-1" />
                  <span>7.8% vs last month</span>
                </div>
              </div>
              <div className="bg-indigo-100 p-3 rounded-full">
                <ShoppingCart className="h-5 w-5 text-indigo-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Outstanding</p>
                <p className="text-3xl font-bold mt-1">
                  {formatCurrency(financialStats.outstandingInvoices, activeCurrency)}
                </p>
                <div className="flex items-center mt-1 text-sm text-red-600">
                  <ArrowDownRight className="h-3 w-3 mr-1" />
                  <span>2.3% vs last month</span>
                </div>
              </div>
              <div className="bg-red-100 p-3 rounded-full">
                <TrendingUp className="h-5 w-5 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Storage Service Revenue Card */}
      <Card className="border-0 shadow-sm mb-8">
        <CardHeader className="pb-2">
          <CardTitle>Storage Service Revenue</CardTitle>
          <CardDescription>Current revenue from farmer storage services (10 XAF per kg per day)</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <StorageRevenueOverview />
          </div>
        </CardContent>
      </Card>
      
      {/* Revenue Visualization Tabs */}
      <Card className="mb-8">
        <CardHeader className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
          <div>
            <CardTitle>Revenue Analysis</CardTitle>
            <CardDescription>Track all income streams and analyze performance trends</CardDescription>
          </div>
          <div className="mt-2 sm:mt-0 w-full sm:w-auto flex flex-col sm:flex-row gap-2">
            <DatePickerWithRange 
              className="w-full sm:w-auto"
              date={dateRange}
              setDate={setDateRange}
            />
            <Select defaultValue="all">
              <SelectTrigger className="w-full sm:w-40">
                <div className="flex items-center">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Filter" />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Revenue</SelectItem>
                <SelectItem value="storage">Storage Only</SelectItem>
                <SelectItem value="marketplace">Marketplace Only</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="trends">
            <TabsList className="mb-4">
              <TabsTrigger value="trends">Revenue Trends</TabsTrigger>
              <TabsTrigger value="breakdown">Revenue Breakdown</TabsTrigger>
              <TabsTrigger value="locations">Revenue by Location</TabsTrigger>
              <TabsTrigger value="forecast">Forecasting</TabsTrigger>
            </TabsList>
            
            <TabsContent value="trends" className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={detailedRevenueData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="month" />
                  <YAxis 
                    tickFormatter={(value) => 
                      formatCurrency(value, activeCurrency)
                    } 
                  />
                  <Tooltip 
                    formatter={(value) => [formatCurrency(Number(value), activeCurrency)]}
                    labelFormatter={(label) => `Month: ${label}`}
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="totalRevenue" 
                    name="Total Revenue"
                    stroke="#10b981" 
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    activeDot={{ r: 8 }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="storageRevenue" 
                    name="Storage Revenue"
                    stroke="#3b82f6" 
                    strokeWidth={2}
                    dot={{ r: 4 }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="marketplaceRevenue" 
                    name="Marketplace Revenue"
                    stroke="#8b5cf6" 
                    strokeWidth={2}
                    dot={{ r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </TabsContent>
            
            <TabsContent value="breakdown" className="h-80">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-full">
                <div className="flex flex-col justify-center">
                  <div className="space-y-6">
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium">Storage Fees</span>
                        <span className="font-semibold">{formatCurrency(financialStats.storageRevenue, activeCurrency)}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-blue-500 h-2.5 rounded-full" style={{ width: `${Math.round(financialStats.storageRevenue / (financialStats.storageRevenue + financialStats.marketplaceRevenue) * 100)}%` }}></div>
                      </div>
                      <div className="flex justify-between text-xs text-muted-foreground mt-1">
                        <span>{Math.round(financialStats.storageRevenue / (financialStats.storageRevenue + financialStats.marketplaceRevenue) * 100)}% of total revenue</span>
                        <span>+12% from last year</span>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium">Marketplace Sales</span>
                        <span className="font-semibold">{formatCurrency(financialStats.marketplaceRevenue, activeCurrency)}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-indigo-500 h-2.5 rounded-full" style={{ width: "40%" }}></div>
                      </div>
                      <div className="flex justify-between text-xs text-muted-foreground mt-1">
                        <span>40% of total revenue</span>
                        <span>+18% from last year</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsPieChart>
                    <Pie
                      data={[
                        { name: 'Storage Revenue', value: financialStats.storageRevenue },
                        { name: 'Marketplace Revenue', value: financialStats.marketplaceRevenue }
                      ]}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      <Cell fill="#3b82f6" />
                      <Cell fill="#8b5cf6" />
                    </Pie>
                    <Tooltip formatter={(value) => formatCurrency(Number(value), activeCurrency)} />
                  </RechartsPieChart>
                </ResponsiveContainer>
              </div>
            </TabsContent>
            
            <TabsContent value="locations" className="h-80">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-full">
                <div className="overflow-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Revenue</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Share</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {revenueByLocation.map((item, index) => (
                        <tr key={index}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{item.name}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{formatCurrency(item.value, activeCurrency)}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {Math.round(item.value / financialStats.totalRevenue * 100)}%
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsPieChart>
                    <Pie
                      data={revenueByLocation}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {revenueByLocation.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => formatCurrency(Number(value), activeCurrency)} />
                  </RechartsPieChart>
                </ResponsiveContainer>
              </div>
            </TabsContent>
            
            <TabsContent value="forecast" className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={[
                  ...detailedRevenueData, 
                  { month: "Jan '24", storageRevenue: 8000, marketplaceRevenue: 5000, totalRevenue: 13000 },
                  { month: "Feb '24", storageRevenue: 8200, marketplaceRevenue: 5200, totalRevenue: 13400 },
                  { month: "Mar '24", storageRevenue: 8400, marketplaceRevenue: 5400, totalRevenue: 13800 }
                ]}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="month" />
                  <YAxis 
                    tickFormatter={(value) => 
                      formatCurrency(value, activeCurrency)
                    } 
                  />
                  <Tooltip 
                    formatter={(value) => [formatCurrency(Number(value), activeCurrency)]}
                    labelFormatter={(label) => `Month: ${label}`}
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="totalRevenue" 
                    name="Total Revenue"
                    stroke="#10b981" 
                    strokeWidth={2}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="storageRevenue" 
                    name="Storage Revenue"
                    stroke="#3b82f6" 
                    strokeWidth={2}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="marketplaceRevenue" 
                    name="Marketplace Revenue"
                    stroke="#8b5cf6" 
                    strokeWidth={2}
                  />
                </LineChart>
              </ResponsiveContainer>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline">View Detailed Reports</Button>
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Export Data
          </Button>
        </CardFooter>
      </Card>

      {/* Farmer Payment Management Summary */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Farmer Payment Management</CardTitle>
          <CardDescription>Track and manage payments to farmers from marketplace sales</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={farmerPaymentData} barGap={10}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="month" />
                  <YAxis 
                    tickFormatter={(value) => 
                      formatCurrency(value, activeCurrency)
                    } 
                  />
                  <Tooltip 
                    formatter={(value) => [formatCurrency(Number(value), activeCurrency)]}
                    labelFormatter={(label) => `Month: ${label}`}
                  />
                  <Legend />
                  <Bar 
                    dataKey="paid" 
                    name="Paid to Farmers"
                    fill="#22c55e" 
                    radius={[4, 4, 0, 0]} 
                    barSize={20}
                  />
                  <Bar 
                    dataKey="pending" 
                    name="Pending Payments"
                    fill="#f59e0b" 
                    radius={[4, 4, 0, 0]} 
                    barSize={20}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
            
            <div className="space-y-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-base font-semibold mb-2">Payment Summary</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Total Payments</span>
                    <span className="font-medium">{formatCurrency(16300, activeCurrency)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Paid This Month</span>
                    <span className="font-medium">{formatCurrency(3200, activeCurrency)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Pending</span>
                    <span className="font-medium">{formatCurrency(550, activeCurrency)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Success Rate</span>
                    <span className="font-medium">98.7%</span>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-col gap-2">
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Process New Payments
                </Button>
                <Button variant="outline">
                  View Payment Schedule
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Revenue By Product Category */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle>Top Product Categories</CardTitle>
            <CardDescription>Revenue from marketplace by product category</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium">Fruits & Vegetables</span>
                  <span className="font-semibold">{formatCurrency(18500, activeCurrency)}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div className="bg-primary h-2.5 rounded-full" style={{ width: "37%" }}></div>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>37% of marketplace revenue</span>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium">Dairy</span>
                  <span className="font-semibold">{formatCurrency(12500, activeCurrency)}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div className="bg-blue-500 h-2.5 rounded-full" style={{ width: "25%" }}></div>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>25% of marketplace revenue</span>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium">Meat</span>
                  <span className="font-semibold">{formatCurrency(10000, activeCurrency)}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div className="bg-indigo-500 h-2.5 rounded-full" style={{ width: "20%" }}></div>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>20% of marketplace revenue</span>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium">Grains</span>
                  <span className="font-semibold">{formatCurrency(9000, activeCurrency)}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div className="bg-purple-500 h-2.5 rounded-full" style={{ width: "18%" }}></div>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>18% of marketplace revenue</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Storage Utilization</CardTitle>
            <CardDescription>Revenue by storage facility utilization</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium">Amsterdam Central</span>
                  <span className="font-semibold">{formatCurrency(25000, activeCurrency)}</span>
                </div>
                <div className="flex items-center">
                  <div className="w-full bg-gray-200 rounded-full h-2.5 mr-2">
                    <div className="bg-green-500 h-2.5 rounded-full" style={{ width: "92%" }}></div>
                  </div>
                  <span className="text-xs font-semibold">92%</span>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>Utilization rate</span>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium">Cape Town Harbor</span>
                  <span className="font-semibold">{formatCurrency(18000, activeCurrency)}</span>
                </div>
                <div className="flex items-center">
                  <div className="w-full bg-gray-200 rounded-full h-2.5 mr-2">
                    <div className="bg-green-500 h-2.5 rounded-full" style={{ width: "85%" }}></div>
                  </div>
                  <span className="text-xs font-semibold">85%</span>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>Utilization rate</span>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium">Lagos Market</span>
                  <span className="font-semibold">{formatCurrency(22000, activeCurrency)}</span>
                </div>
                <div className="flex items-center">
                  <div className="w-full bg-gray-200 rounded-full h-2.5 mr-2">
                    <div className="bg-green-500 h-2.5 rounded-full" style={{ width: "95%" }}></div>
                  </div>
                  <span className="text-xs font-semibold">95%</span>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>Utilization rate</span>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium">Nairobi Central</span>
                  <span className="font-semibold">{formatCurrency(10000, activeCurrency)}</span>
                </div>
                <div className="flex items-center">
                  <div className="w-full bg-gray-200 rounded-full h-2.5 mr-2">
                    <div className="bg-yellow-500 h-2.5 rounded-full" style={{ width: "68%" }}></div>
                  </div>
                  <span className="text-xs font-semibold">68%</span>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>Utilization rate</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </FinanceLayout>
  );
}