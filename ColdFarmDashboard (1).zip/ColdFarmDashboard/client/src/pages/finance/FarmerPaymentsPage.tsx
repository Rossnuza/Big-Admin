import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useCurrency } from "@/lib/currency-context";
import { formatCurrency } from "@/lib/currency";
import { FinanceLayout } from "@/components/finance/FinanceLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DataTable } from "@/components/ui/data-table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PaymentDialog } from "@/components/finance/PaymentDialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { 
  Download, 
  Filter, 
  RefreshCw, 
  Calendar,
  Search,
  Plus,
  Check,
  Clock,
  Users,
  Wallet,
  AlertCircle,
  FileText,
  CheckCircle,
  AlertTriangle,
  ChevronDown
} from "lucide-react";
import { 
  BarChart, 
  Bar, 
  LineChart,
  Line,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend,
  ResponsiveContainer 
} from "recharts";
import { format } from "date-fns";

// Sample farmer payment data
const pendingPayments = [
  { 
    id: 1,
    farmerName: "Green Valley Farms",
    farmerID: "F-10001",
    amount: 2850,
    dueDate: new Date("2023-05-10"),
    salesPeriod: "Apr 1-30, 2023",
    items: 28,
    status: "pending",
  },
  { 
    id: 2,
    farmerName: "Organic Crops Ltd",
    farmerID: "F-10015",
    amount: 1950,
    dueDate: new Date("2023-05-10"),
    salesPeriod: "Apr 1-30, 2023",
    items: 15,
    status: "pending",
  },
  { 
    id: 3,
    farmerName: "Fresh Fields Co-op",
    farmerID: "F-10022",
    amount: 3200,
    dueDate: new Date("2023-05-05"),
    salesPeriod: "Apr 1-30, 2023",
    items: 32,
    status: "scheduled",
  },
  { 
    id: 4,
    farmerName: "Sunrise Farmers",
    farmerID: "F-10037",
    amount: 1650,
    dueDate: new Date("2023-05-15"),
    salesPeriod: "Apr 1-30, 2023",
    items: 18,
    status: "pending",
  },
  { 
    id: 5,
    farmerName: "Mountain Range Produce",
    farmerID: "F-10042",
    amount: 2100,
    dueDate: new Date("2023-05-12"),
    salesPeriod: "Apr 1-30, 2023",
    items: 22,
    status: "pending",
  },
];

// Payment history data
const paymentHistory = [
  { 
    id: 1,
    farmerName: "Green Valley Farms",
    farmerID: "F-10001",
    amount: 2450,
    paidDate: new Date("2023-04-10"),
    salesPeriod: "Mar 1-31, 2023",
    items: 24,
    paymentMethod: "bank_transfer",
    status: "completed",
    transactionId: "PMT-38291"
  },
  { 
    id: 2,
    farmerName: "Organic Crops Ltd",
    farmerID: "F-10015",
    amount: 1875,
    paidDate: new Date("2023-04-08"),
    salesPeriod: "Mar 1-31, 2023",
    items: 15,
    paymentMethod: "mobile_money",
    status: "completed",
    transactionId: "PMT-38273"
  },
  { 
    id: 3,
    farmerName: "Fresh Fields Co-op",
    farmerID: "F-10022",
    amount: 3100,
    paidDate: new Date("2023-04-05"),
    salesPeriod: "Mar 1-31, 2023",
    items: 30,
    paymentMethod: "bank_transfer",
    status: "completed",
    transactionId: "PMT-38224"
  },
  { 
    id: 4,
    farmerName: "Sunrise Farmers",
    farmerID: "F-10037",
    amount: 1500,
    paidDate: new Date("2023-04-12"),
    salesPeriod: "Mar 1-31, 2023",
    items: 16,
    paymentMethod: "mobile_money",
    status: "completed",
    transactionId: "PMT-38315"
  },
  { 
    id: 5,
    farmerName: "Mountain Range Produce",
    farmerID: "F-10042",
    amount: 2000,
    paidDate: new Date("2023-04-07"),
    salesPeriod: "Mar 1-31, 2023",
    items: 20,
    paymentMethod: "bank_transfer",
    status: "completed",
    transactionId: "PMT-38253"
  },
  { 
    id: 6,
    farmerName: "Southern Harvest",
    farmerID: "F-10048",
    amount: 1750,
    paidDate: new Date("2023-04-11"),
    salesPeriod: "Mar 1-31, 2023",
    items: 18,
    paymentMethod: "mobile_money",
    status: "completed",
    transactionId: "PMT-38302"
  },
];

// Monthly payment trend data
const monthlyPaymentTrend = [
  { month: "Jan", totalPaid: 12500, farmerCount: 15 },
  { month: "Feb", totalPaid: 13500, farmerCount: 16 },
  { month: "Mar", totalPaid: 14700, farmerCount: 18 },
  { month: "Apr", totalPaid: 15800, farmerCount: 20 },
  { month: "May", totalPaid: 11750, farmerCount: 14 },
  { month: "Jun", totalPaid: 16200, farmerCount: 22 },
];

export default function FarmerPaymentsPage() {
  const { activeCurrency } = useCurrency();
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedPayment, setSelectedPayment] = useState<any>(null);
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [showBulkPaymentDialog, setShowBulkPaymentDialog] = useState(false);
  const [showPaymentDetailDialog, setShowPaymentDetailDialog] = useState(false);
  const pageSize = 5;

  // Function to get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-200">Completed</Badge>;
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">Pending</Badge>;
      case "scheduled":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">Scheduled</Badge>;
      case "failed":
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-200">Failed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  // Function to get payment method badge
  const getPaymentMethodBadge = (method: string) => {
    switch (method) {
      case "bank_transfer":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">Bank Transfer</Badge>;
      case "mobile_money":
        return <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-200">Mobile Money</Badge>;
      case "cash":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-200">Cash</Badge>;
      default:
        return <Badge variant="outline">{method}</Badge>;
    }
  };

  // Function to handle "Pay Now" button click
  const handlePayNow = (payment: any) => {
    setSelectedPayment(payment);
    setShowPaymentDialog(true);
  };
  
  // Function to handle viewing payment details
  const handleViewPayment = (payment: any) => {
    setSelectedPayment(payment);
    setShowPaymentDetailDialog(true);
  };

  // Function to handle successful payment
  const handlePaymentSuccess = () => {
    // Here you would typically refetch the data or update the local state
    // For simplicity we'll just close the dialog
    setShowPaymentDialog(false);
  };

  return (
    <FinanceLayout title="Farmer Payment Management">
      {/* Summary Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="bg-green-100 p-3 rounded-full mr-4">
                <Wallet className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Paid (YTD)</p>
                <div className="flex items-center">
                  <p className="text-2xl font-bold">
                    {formatCurrency(81700, activeCurrency)}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="bg-yellow-100 p-3 rounded-full mr-4">
                <AlertCircle className="h-5 w-5 text-yellow-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Pending Payments</p>
                <div className="flex items-center">
                  <p className="text-2xl font-bold">
                    {formatCurrency(11750, activeCurrency)}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="bg-blue-100 p-3 rounded-full mr-4">
                <Users className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Active Farmers</p>
                <div className="flex items-center">
                  <p className="text-2xl font-bold">
                    22
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="bg-indigo-100 p-3 rounded-full mr-4">
                <Clock className="h-5 w-5 text-indigo-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Avg. Processing Time</p>
                <div className="flex items-center">
                  <p className="text-2xl font-bold">
                    1.2 days
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Payment Management Tabs */}
      <Tabs defaultValue="pending" className="mb-8">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="pending">Pending Payments</TabsTrigger>
          <TabsTrigger value="history">Payment History</TabsTrigger>
          <TabsTrigger value="analytics">Payment Analytics</TabsTrigger>
        </TabsList>
        
        <TabsContent value="pending">
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
                <div>
                  <CardTitle>Pending Farmer Payments</CardTitle>
                  <CardDescription>Process payments for marketplace sales</CardDescription>
                </div>
                <div className="flex gap-2 flex-wrap">
                  <Button onClick={() => setShowBulkPaymentDialog(true)}>
                    <Plus className="mr-2 h-4 w-4" />
                    Process Bulk Payment
                  </Button>
                  <Button variant="outline">
                    <Calendar className="mr-2 h-4 w-4" />
                    Schedule Payments
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <DataTable
                data={pendingPayments}
                columns={[
                  {
                    header: "Farmer",
                    accessorKey: "farmerName",
                    cell: (row) => (
                      <div className="font-medium">
                        {row.farmerName}
                        <div className="text-xs text-gray-500">{row.farmerID}</div>
                      </div>
                    ),
                  },
                  {
                    header: "Amount",
                    cell: (row) => (
                      <div className="font-medium">
                        {formatCurrency(row.amount, activeCurrency)}
                      </div>
                    ),
                  },
                  {
                    header: "Due Date",
                    cell: (row) => format(new Date(row.dueDate), "MMM dd, yyyy"),
                  },
                  {
                    header: "Sales Period",
                    accessorKey: "salesPeriod",
                  },
                  {
                    header: "Items",
                    accessorKey: "items",
                  },
                  {
                    header: "Status",
                    cell: (row) => getStatusBadge(row.status),
                  },
                  {
                    header: "Action",
                    cell: (row) => (
                      <div className="flex space-x-2">
                        <Button 
                          size="sm" 
                          onClick={() => handlePayNow(row)}
                          disabled={row.status === 'scheduled'}
                        >
                          Pay Now
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleViewPayment(row)}
                        >
                          Details
                        </Button>
                      </div>
                    ),
                  },
                ]}
                pagination={{
                  currentPage,
                  pageSize,
                  totalItems: pendingPayments.length,
                  onPageChange: setCurrentPage,
                }}
              />
            </CardContent>
            <CardFooter className="flex justify-between border-t px-6 py-4">
              <div className="text-sm text-muted-foreground">
                Total pending: {formatCurrency(pendingPayments.reduce((sum, p) => sum + p.amount, 0), activeCurrency)}
              </div>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export List
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="history">
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
                <div>
                  <CardTitle>Payment History</CardTitle>
                  <CardDescription>Record of all payments to farmers</CardDescription>
                </div>
                <div className="flex gap-2 flex-wrap">
                  <div className="w-[200px]">
                    <Input placeholder="Search payments..." className="h-9" />
                  </div>
                  <Button size="sm" variant="outline">
                    <Search className="h-4 w-4 mr-2" />
                    Search
                  </Button>
                  <Button size="sm" variant="outline">
                    <Filter className="h-4 w-4 mr-2" />
                    Filter
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <DataTable
                data={paymentHistory}
                columns={[
                  {
                    header: "Farmer",
                    accessorKey: "farmerName",
                    cell: (row) => (
                      <div className="font-medium">
                        {row.farmerName}
                        <div className="text-xs text-gray-500">{row.farmerID}</div>
                      </div>
                    ),
                  },
                  {
                    header: "Amount",
                    cell: (row) => (
                      <div className="font-medium">
                        {formatCurrency(row.amount, activeCurrency)}
                      </div>
                    ),
                  },
                  {
                    header: "Date Paid",
                    cell: (row) => format(new Date(row.paidDate), "MMM dd, yyyy"),
                  },
                  {
                    header: "Sales Period",
                    accessorKey: "salesPeriod",
                  },
                  {
                    header: "Payment Method",
                    cell: (row) => getPaymentMethodBadge(row.paymentMethod),
                  },
                  {
                    header: "Status",
                    cell: (row) => getStatusBadge(row.status),
                  },
                  {
                    header: "Transaction ID",
                    accessorKey: "transactionId",
                    cell: (row) => (
                      <div className="font-mono text-xs">
                        {row.transactionId}
                      </div>
                    ),
                  },
                  {
                    header: "Action",
                    cell: (row) => (
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleViewPayment(row)}
                      >
                        Details
                      </Button>
                    ),
                  },
                ]}
                pagination={{
                  currentPage,
                  pageSize,
                  totalItems: paymentHistory.length,
                  onPageChange: setCurrentPage,
                }}
              />
            </CardContent>
            <CardFooter className="flex justify-between border-t px-6 py-4">
              <div className="text-sm text-muted-foreground">
                Showing latest {Math.min(pageSize, paymentHistory.length)} of {paymentHistory.length} payments
              </div>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export History
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="analytics">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Monthly Payment Trends</CardTitle>
                <CardDescription>Payment amounts and farmer counts by month</CardDescription>
              </CardHeader>
              <CardContent className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={monthlyPaymentTrend}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="month" />
                    <YAxis 
                      yAxisId="left" 
                      tickFormatter={(value) => 
                        formatCurrency(value, activeCurrency)
                      } 
                    />
                    <YAxis 
                      yAxisId="right" 
                      orientation="right" 
                      domain={[0, 50]}
                    />
                    <Tooltip 
                      formatter={(value, name) => {
                        if (name === "totalPaid") {
                          return [formatCurrency(Number(value), activeCurrency), "Total Paid"];
                        }
                        return [value, "Farmer Count"];
                      }}
                      labelFormatter={(label) => `Month: ${label}`}
                    />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="totalPaid" 
                      name="Total Paid"
                      stroke="#10b981" 
                      strokeWidth={2}
                      yAxisId="left"
                      dot={{ r: 4 }}
                      activeDot={{ r: 8 }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="farmerCount" 
                      name="Farmer Count"
                      stroke="#8b5cf6" 
                      strokeWidth={2}
                      yAxisId="right"
                      dot={{ r: 4 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Payment Methods</CardTitle>
                <CardDescription>Distribution of payment methods used</CardDescription>
              </CardHeader>
              <CardContent className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={[
                    { method: "Bank Transfer", count: 12, amount: 8250 },
                    { method: "Mobile Money", count: 6, amount: 4500 },
                    { method: "Cash", count: 2, amount: 950 }
                  ]}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="method" />
                    <YAxis 
                      tickFormatter={(value) => 
                        formatCurrency(value, activeCurrency)
                      } 
                    />
                    <Tooltip 
                      formatter={(value) => [formatCurrency(Number(value), activeCurrency)]}
                    />
                    <Legend />
                    <Bar 
                      dataKey="amount" 
                      name="Amount" 
                      fill="#3b82f6" 
                      radius={[4, 4, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Payment Cycle Statistics</CardTitle>
                <CardDescription>Processing times and success rates</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-8 py-4">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Payment Success Rate</span>
                      <span className="font-semibold">99.2%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-green-500 h-2.5 rounded-full" style={{ width: "99.2%" }}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Average Processing Time</span>
                      <span className="font-semibold">1.2 days</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-blue-500 h-2.5 rounded-full" style={{ width: "40%" }}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">On-time Payment Rate</span>
                      <span className="font-semibold">97.5%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-indigo-500 h-2.5 rounded-full" style={{ width: "97.5%" }}></div>
                    </div>
                  </div>
                  
                  <div className="pt-4 border-t">
                    <h4 className="text-sm font-semibold mb-3">Payment Schedule Distribution</h4>
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div className="bg-blue-50 p-3 rounded">
                        <div className="text-blue-600 text-lg font-bold">65%</div>
                        <div className="text-xs text-gray-500">Monthly</div>
                      </div>
                      <div className="bg-indigo-50 p-3 rounded">
                        <div className="text-indigo-600 text-lg font-bold">30%</div>
                        <div className="text-xs text-gray-500">Bi-Weekly</div>
                      </div>
                      <div className="bg-purple-50 p-3 rounded">
                        <div className="text-purple-600 text-lg font-bold">5%</div>
                        <div className="text-xs text-gray-500">Weekly</div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
      
      {/* Payment Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Payment Settings</CardTitle>
          <CardDescription>Configure payment cycles and processing options</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="border rounded-lg p-4">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h3 className="font-medium">Default Payment Cycle</h3>
                  <p className="text-sm text-gray-500">Monthly (End of Month)</p>
                </div>
                <Button variant="outline" size="sm">Edit</Button>
              </div>
              <div className="flex items-center text-sm text-muted-foreground">
                <Clock className="h-4 w-4 mr-2" />
                <span>Next scheduled: May 31, 2023</span>
              </div>
            </div>
            
            <div className="border rounded-lg p-4">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h3 className="font-medium">Default Payment Method</h3>
                  <p className="text-sm text-gray-500">Bank Transfer</p>
                </div>
                <Button variant="outline" size="sm">Edit</Button>
              </div>
              <div className="flex items-center text-sm text-muted-foreground">
                <Check className="h-4 w-4 mr-2" />
                <span>Processing fee: 1.5%</span>
              </div>
            </div>
            
            <div className="border rounded-lg p-4">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h3 className="font-medium">Mobile Payment Integration</h3>
                  <p className="text-sm text-gray-500">M-Pesa, MTN Mobile Money</p>
                </div>
                <Button variant="outline" size="sm">Configure</Button>
              </div>
              <div className="flex items-center text-sm text-muted-foreground">
                <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                <span>Active and working properly</span>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between border-t px-6 py-4">
          <Button variant="outline">
            <FileText className="h-4 w-4 mr-2" />
            View Payment Policies
          </Button>
          <Button>
            <ChevronDown className="h-4 w-4 mr-2" />
            Advanced Settings
          </Button>
        </CardFooter>
      </Card>

      {/* Payment Dialog */}
      {selectedPayment && (
        <PaymentDialog 
          open={showPaymentDialog}
          onOpenChange={setShowPaymentDialog}
          amount={selectedPayment.amount}
          title={`Pay ${selectedPayment.farmerName}`}
          description={`Payment for marketplace sales during ${selectedPayment.salesPeriod}.`}
          onSuccess={handlePaymentSuccess}
        />
      )}

      {/* Bulk Payment Dialog */}
      <Dialog open={showBulkPaymentDialog} onOpenChange={setShowBulkPaymentDialog}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Process Bulk Payments</DialogTitle>
            <DialogDescription>
              Schedule payments for multiple farmers at once
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="border rounded-lg p-4">
              <h3 className="font-medium mb-2">Payment Summary</h3>
              <div className="flex justify-between mb-1">
                <span className="text-sm text-gray-500">Total Farmers</span>
                <span className="font-medium">5</span>
              </div>
              <div className="flex justify-between mb-1">
                <span className="text-sm text-gray-500">Total Amount</span>
                <span className="font-medium">{formatCurrency(11750, activeCurrency)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-500">Sales Period</span>
                <span className="font-medium">Apr 1-30, 2023</span>
              </div>
            </div>
            
            <div className="border rounded-lg p-4">
              <h3 className="font-medium mb-2">Payment Method</h3>
              <Select defaultValue="bank_transfer">
                <SelectTrigger>
                  <SelectValue placeholder="Select payment method" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                  <SelectItem value="mobile_money">Mobile Money</SelectItem>
                  <SelectItem value="cash">Cash</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="border rounded-lg p-4">
              <h3 className="font-medium mb-2">Payment Date</h3>
              <Select defaultValue="immediate">
                <SelectTrigger>
                  <SelectValue placeholder="Select payment timing" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="immediate">Process Immediately</SelectItem>
                  <SelectItem value="scheduled">Schedule for May 10, 2023</SelectItem>
                  <SelectItem value="custom">Custom Date</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="border rounded-lg p-4 bg-yellow-50">
              <div className="flex items-start">
                <AlertTriangle className="h-5 w-5 text-yellow-600 mr-2 mt-0.5" />
                <div>
                  <h3 className="font-medium text-yellow-800 mb-1">Confirmation Required</h3>
                  <p className="text-sm text-yellow-700">
                    You are about to process payments totaling {formatCurrency(11750, activeCurrency)} to 5 farmers. 
                    This action cannot be undone.
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowBulkPaymentDialog(false)}>
              Cancel
            </Button>
            <Button onClick={() => setShowBulkPaymentDialog(false)}>
              Confirm Payments
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Payment Detail Dialog */}
      <Dialog open={showPaymentDetailDialog} onOpenChange={setShowPaymentDetailDialog}>
        {selectedPayment && (
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Payment Details</DialogTitle>
              <DialogDescription>
                {selectedPayment.status === 'completed' 
                  ? `Payment to ${selectedPayment.farmerName} on ${format(new Date(selectedPayment.paidDate || selectedPayment.dueDate), "MMM dd, yyyy")}`
                  : `Pending payment to ${selectedPayment.farmerName} due on ${format(new Date(selectedPayment.dueDate), "MMM dd, yyyy")}`
                }
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-sm text-gray-500">Farmer ID</p>
                  <p className="font-medium">{selectedPayment.farmerID}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-gray-500">Amount</p>
                  <p className="font-medium text-lg">{formatCurrency(selectedPayment.amount, activeCurrency)}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-gray-500">Items Sold</p>
                  <p className="font-medium">{selectedPayment.items} items</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-gray-500">Sales Period</p>
                  <p className="font-medium">{selectedPayment.salesPeriod}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-gray-500">Status</p>
                  <div>{getStatusBadge(selectedPayment.status)}</div>
                </div>
                {selectedPayment.status === 'completed' && (
                  <div className="space-y-1">
                    <p className="text-sm text-gray-500">Payment Method</p>
                    <div>{getPaymentMethodBadge(selectedPayment.paymentMethod)}</div>
                  </div>
                )}
                {selectedPayment.transactionId && (
                  <div className="space-y-1 col-span-2">
                    <p className="text-sm text-gray-500">Transaction ID</p>
                    <p className="font-mono">{selectedPayment.transactionId}</p>
                  </div>
                )}
              </div>
              
              {selectedPayment.status === 'pending' && (
                <div className="border rounded-lg p-4 bg-blue-50 mt-4">
                  <div className="flex items-start">
                    <AlertCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5" />
                    <div>
                      <h3 className="font-medium text-blue-800">Payment Information</h3>
                      <p className="text-sm text-blue-700 mt-1">
                        This payment is scheduled to be processed on {format(new Date(selectedPayment.dueDate), "MMM dd, yyyy")}.
                        You can process it now or modify the payment details.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowPaymentDetailDialog(false)}>
                Close
              </Button>
              {selectedPayment.status === 'pending' && (
                <Button onClick={() => {
                  setShowPaymentDetailDialog(false);
                  handlePayNow(selectedPayment);
                }}>
                  Process Payment
                </Button>
              )}
              {selectedPayment.status === 'completed' && (
                <Button variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Export Receipt
                </Button>
              )}
            </DialogFooter>
          </DialogContent>
        )}
      </Dialog>
    </FinanceLayout>
  );
}