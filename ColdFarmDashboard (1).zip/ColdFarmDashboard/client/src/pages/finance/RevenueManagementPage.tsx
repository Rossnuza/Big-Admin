import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useCurrency } from "@/lib/currency-context";
import { formatCurrency } from "@/lib/currency";
import { FinanceLayout } from "@/components/finance/FinanceLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { DataTable } from "@/components/ui/data-table";
import { Badge } from "@/components/ui/badge";
import { DatePickerWithRange } from "@/components/ui/date-range-picker";
import { DateRange } from "react-day-picker";
import { 
  Download, 
  Filter, 
  RefreshCw, 
  TrendingUp, 
  ArrowUpRight, 
  Warehouse, 
  ShoppingCart, 
  Search,
  FileSpreadsheet,
  Calendar,
  ChevronDown,
} from "lucide-react";
import { 
  BarChart, 
  Bar, 
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend,
  ResponsiveContainer 
} from "recharts";
import { format } from "date-fns";

// Revenue data with storage and marketplace breakdown
// Updated with accurate storage and marketplace revenue figures
const revenueByMonth = [
  { month: "Jan", storageRevenue: 150000, marketplaceRevenue: 40000, totalRevenue: 190000 },
  { month: "Feb", storageRevenue: 160000, marketplaceRevenue: 42000, totalRevenue: 202000 },
  { month: "Mar", storageRevenue: 170000, marketplaceRevenue: 45000, totalRevenue: 215000 },
  { month: "Apr", storageRevenue: 175000, marketplaceRevenue: 47000, totalRevenue: 222000 },
  { month: "May", storageRevenue: 180000, marketplaceRevenue: 48000, totalRevenue: 228000 },
  { month: "Jun", storageRevenue: 190000, marketplaceRevenue: 50000, totalRevenue: 240000 },
];

// Location-specific revenue
const revenueByLocation = [
  { 
    location: "Amsterdam Central", 
    storageRevenue: 16500, 
    marketplaceRevenue: 8500, 
    totalRevenue: 25000,
    growthRate: 8.2
  },
  { 
    location: "Cape Town Harbor", 
    storageRevenue: 12000, 
    marketplaceRevenue: 6000, 
    totalRevenue: 18000,
    growthRate: 5.7
  },
  { 
    location: "Lagos Market", 
    storageRevenue: 15000, 
    marketplaceRevenue: 7000, 
    totalRevenue: 22000,
    growthRate: 12.4
  },
  { 
    location: "Nairobi Central", 
    storageRevenue: 6500, 
    marketplaceRevenue: 3500, 
    totalRevenue: 10000,
    growthRate: 3.8
  },
];

// Product category revenue
const revenueByCategory = [
  { category: "Fruits & Vegetables", revenue: 18500, share: 37, growth: 9.2 },
  { category: "Dairy", revenue: 12500, share: 25, growth: 7.5 },
  { category: "Meat", revenue: 10000, share: 20, growth: 5.8 },
  { category: "Grains", revenue: 9000, share: 18, growth: 4.3 },
];

// Recent revenue transactions
const recentTransactions = [
  { 
    id: "TR-12345", 
    date: new Date("2023-04-25"), 
    description: "Storage fees - Amsterdam", 
    amount: 1250, 
    type: "storage", 
    status: "completed" 
  },
  { 
    id: "TR-12346", 
    date: new Date("2023-04-23"), 
    description: "Marketplace commission - Fruits", 
    amount: 850, 
    type: "marketplace", 
    status: "completed" 
  },
  { 
    id: "TR-12347", 
    date: new Date("2023-04-22"), 
    description: "Storage fees - Lagos", 
    amount: 980, 
    type: "storage", 
    status: "completed" 
  },
  { 
    id: "TR-12348", 
    date: new Date("2023-04-21"), 
    description: "Marketplace commission - Dairy", 
    amount: 720, 
    type: "marketplace", 
    status: "completed" 
  },
  { 
    id: "TR-12349", 
    date: new Date("2023-04-20"), 
    description: "Storage fees - Cape Town", 
    amount: 1100, 
    type: "storage", 
    status: "completed" 
  },
  { 
    id: "TR-12350", 
    date: new Date("2023-04-19"), 
    description: "Marketplace commission - Meat", 
    amount: 650, 
    type: "marketplace", 
    status: "completed" 
  },
];

// Forecast data - updated with higher value projections matching the actual data scale
const forecastData = [
  { month: "Jul", forecast: 245000, actual: null },
  { month: "Aug", forecast: 252000, actual: null },
  { month: "Sep", forecast: 260000, actual: null },
  { month: "Oct", forecast: 265000, actual: null },
  { month: "Nov", forecast: 272000, actual: null },
  { month: "Dec", forecast: 280000, actual: null },
];

export default function RevenueManagementPage() {
  const { activeCurrency } = useCurrency();
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: new Date(2023, 0, 1),
    to: new Date(),
  });
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 6;

  // Function to get transaction type badge
  const getTransactionTypeBadge = (type: string) => {
    switch (type) {
      case "storage":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">Storage</Badge>;
      case "marketplace":
        return <Badge className="bg-indigo-100 text-indigo-800 hover:bg-indigo-200">Marketplace</Badge>;
      default:
        return <Badge variant="outline">{type}</Badge>;
    }
  };

  // Function to get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-200">Completed</Badge>;
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">Pending</Badge>;
      case "failed":
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-200">Failed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <FinanceLayout title="Revenue Management">
      {/* Top Revenue Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="bg-blue-100 p-3 rounded-full mr-4">
                <Warehouse className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Storage Revenue</p>
                <div className="flex items-center">
                  <p className="text-2xl font-bold mr-2">
                    {formatCurrency(1800000, activeCurrency)}
                  </p>
                  <span className="text-sm text-green-600 flex items-center">
                    <ArrowUpRight className="h-3 w-3 mr-1" />
                    5.6%
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="bg-indigo-100 p-3 rounded-full mr-4">
                <ShoppingCart className="h-5 w-5 text-indigo-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Marketplace Revenue</p>
                <div className="flex items-center">
                  <p className="text-2xl font-bold mr-2">
                    {formatCurrency(500000, activeCurrency)}
                  </p>
                  <span className="text-sm text-green-600 flex items-center">
                    <ArrowUpRight className="h-3 w-3 mr-1" />
                    12.5%
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="bg-green-100 p-3 rounded-full mr-4">
                <TrendingUp className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Projected Annual Revenue</p>
                <div className="flex items-center">
                  <p className="text-2xl font-bold mr-2">
                    {formatCurrency(2500000, activeCurrency)}
                  </p>
                  <span className="text-sm text-green-600 flex items-center">
                    <ArrowUpRight className="h-3 w-3 mr-1" />
                    22.3%
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters for Revenue Analysis */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Revenue Analysis</CardTitle>
          <CardDescription>Filter and analyze revenue streams over time</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="flex-1">
              <DatePickerWithRange 
                className="w-full"
                date={dateRange}
                setDate={setDateRange}
              />
            </div>
            <div className="flex-1">
              <Select defaultValue="all">
                <SelectTrigger>
                  <div className="flex items-center">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Filter by type" />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Revenue</SelectItem>
                  <SelectItem value="storage">Storage Only</SelectItem>
                  <SelectItem value="marketplace">Marketplace Only</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex-1">
              <Select defaultValue="all">
                <SelectTrigger>
                  <div className="flex items-center">
                    <Warehouse className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Filter by location" />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Locations</SelectItem>
                  <SelectItem value="amsterdam">Amsterdam</SelectItem>
                  <SelectItem value="capetown">Cape Town</SelectItem>
                  <SelectItem value="lagos">Lagos</SelectItem>
                  <SelectItem value="nairobi">Nairobi</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button className="shrink-0">
              <RefreshCw className="h-4 w-4 mr-2" />
              Update
            </Button>
          </div>

          <Tabs defaultValue="chart">
            <TabsList className="mb-4">
              <TabsTrigger value="chart">Chart View</TabsTrigger>
              <TabsTrigger value="table">Table View</TabsTrigger>
              <TabsTrigger value="locations">By Location</TabsTrigger>
              <TabsTrigger value="categories">By Category</TabsTrigger>
            </TabsList>
            
            <TabsContent value="chart" className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={revenueByMonth}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="month" />
                  <YAxis 
                    tickFormatter={(value) => 
                      formatCurrency(value, activeCurrency)
                    } 
                  />
                  <Tooltip 
                    formatter={(value) => [formatCurrency(Number(value), activeCurrency)]}
                    labelFormatter={(label) => `Month: ${label}`}
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="totalRevenue" 
                    name="Total Revenue"
                    stroke="#10b981" 
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    activeDot={{ r: 8 }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="storageRevenue" 
                    name="Storage Revenue"
                    stroke="#3b82f6" 
                    strokeWidth={2}
                    dot={{ r: 4 }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="marketplaceRevenue" 
                    name="Marketplace Revenue"
                    stroke="#8b5cf6" 
                    strokeWidth={2}
                    dot={{ r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </TabsContent>
            
            <TabsContent value="table">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Month</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Storage Revenue</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Marketplace Revenue</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Revenue</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">MoM Change</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {revenueByMonth.map((item, index) => {
                      const prevMonth = index > 0 ? revenueByMonth[index - 1].totalRevenue : item.totalRevenue;
                      const changePercent = ((item.totalRevenue - prevMonth) / prevMonth * 100).toFixed(1);
                      const isPositive = index === 0 ? true : item.totalRevenue > prevMonth;
                      
                      return (
                        <tr key={index}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{item.month}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {formatCurrency(item.storageRevenue, activeCurrency)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {formatCurrency(item.marketplaceRevenue, activeCurrency)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            {formatCurrency(item.totalRevenue, activeCurrency)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm">
                            {index === 0 ? (
                              <span className="text-gray-500">-</span>
                            ) : (
                              <span className={isPositive ? "text-green-600" : "text-red-600"}>
                                {isPositive ? "+" : ""}{changePercent}%
                              </span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </TabsContent>
            
            <TabsContent value="locations">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Storage Revenue</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Marketplace Revenue</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Revenue</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Growth Rate</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {revenueByLocation.map((item, index) => (
                      <tr key={index}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{item.location}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {formatCurrency(item.storageRevenue, activeCurrency)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {formatCurrency(item.marketplaceRevenue, activeCurrency)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          {formatCurrency(item.totalRevenue, activeCurrency)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600">
                          +{item.growthRate}%
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="bg-gray-50">
                    <tr>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Total</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        {formatCurrency(revenueByLocation.reduce((sum, item) => sum + item.storageRevenue, 0), activeCurrency)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        {formatCurrency(revenueByLocation.reduce((sum, item) => sum + item.marketplaceRevenue, 0), activeCurrency)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        {formatCurrency(revenueByLocation.reduce((sum, item) => sum + item.totalRevenue, 0), activeCurrency)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm"></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </TabsContent>
            
            <TabsContent value="categories">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Revenue</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Share</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Growth</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {revenueByCategory.map((item, index) => (
                        <tr key={index}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{item.category}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {formatCurrency(item.revenue, activeCurrency)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {item.share}%
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600">
                            +{item.growth}%
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={revenueByCategory}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="revenue"
                        nameKey="category"
                        label={({ category, percent }) => `${category}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {revenueByCategory.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={['#10b981', '#3b82f6', '#8b5cf6', '#f59e0b'][index % 4]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => formatCurrency(Number(value), activeCurrency)} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="flex justify-between border-t px-6 py-4">
          <Button variant="outline">
            <FileSpreadsheet className="h-4 w-4 mr-2" />
            Export as CSV
          </Button>
          <Button variant="outline">
            <Calendar className="h-4 w-4 mr-2" />
            Schedule Reports
          </Button>
        </CardFooter>
      </Card>

      {/* Revenue Forecasting */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Revenue Forecasting</CardTitle>
          <CardDescription>Projected revenue for the next 6 months</CardDescription>
        </CardHeader>
        <CardContent className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={[
              ...revenueByMonth,
              ...forecastData
            ]}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="month" />
              <YAxis 
                tickFormatter={(value) => 
                  formatCurrency(value, activeCurrency)
                } 
              />
              <Tooltip 
                formatter={(value) => value !== null ? [formatCurrency(Number(value), activeCurrency)] : ['-']}
                labelFormatter={(label) => `Month: ${label}`}
              />
              <Legend />
              {/* Actual Revenue */}
              <Line 
                type="monotone" 
                dataKey="totalRevenue" 
                name="Actual Revenue"
                stroke="#10b981" 
                strokeWidth={2}
                dot={{ r: 4 }}
                activeDot={{ r: 8 }}
              />
              {/* Forecast Revenue */}
              <Line 
                type="monotone" 
                dataKey="forecast" 
                name="Forecast Revenue"
                stroke="#f59e0b" 
                strokeWidth={2}
                strokeDasharray="5 5"
                dot={{ r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
        <CardFooter className="flex justify-between border-t px-6 py-4">
          <div className="text-sm text-muted-foreground">
            Forecast based on historical data with seasonal adjustments
          </div>
          <Button variant="outline">
            <ChevronDown className="h-4 w-4 mr-2" />
            Forecast Settings
          </Button>
        </CardFooter>
      </Card>

      {/* Recent Transactions */}
      <Card>
        <CardHeader>
          <div className="flex justify-between">
            <div>
              <CardTitle>Recent Revenue Transactions</CardTitle>
              <CardDescription>List of recent revenue entries</CardDescription>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <div className="w-[200px]">
                <Input placeholder="Search transactions..." className="h-9" />
              </div>
              <Button size="sm" variant="outline">
                <Search className="h-4 w-4 mr-2" />
                Search
              </Button>
              <Button size="sm" variant="outline">
                <Filter className="h-4 w-4 mr-2" />
                Filter
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <DataTable
            data={recentTransactions}
            columns={[
              {
                header: "Transaction ID",
                accessorKey: "id",
              },
              {
                header: "Date",
                cell: (row) => format(new Date(row.date), "MMM dd, yyyy"),
              },
              {
                header: "Description",
                accessorKey: "description",
              },
              {
                header: "Amount",
                cell: (row) => formatCurrency(row.amount, activeCurrency),
              },
              {
                header: "Type",
                cell: (row) => getTransactionTypeBadge(row.type),
              },
              {
                header: "Status",
                cell: (row) => getStatusBadge(row.status),
              },
            ]}
            pagination={{
              currentPage,
              pageSize,
              totalItems: recentTransactions.length,
              onPageChange: setCurrentPage,
            }}
          />
        </CardContent>
        <CardFooter className="flex justify-between border-t px-6 py-4">
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export Transactions
          </Button>
          <Button>View All Transactions</Button>
        </CardFooter>
      </Card>
    </FinanceLayout>
  );
}