import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { FinanceLayout } from "@/components/finance/FinanceLayout";
import { formatCurrency } from "@/lib/currency";
import { useCurrency } from "@/lib/currency-context";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { ArrowRight, CreditCard, BadgeCheck, MoreHorizontal } from "lucide-react";
import { DataTable } from "@/components/ui/data-table";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { PaymentDialog } from "@/components/finance/PaymentDialog";
import { useToast } from "@/hooks/use-toast";

// Mock payment history data - in a real app, this would come from the API
const mockPayments = [
  {
    id: 1,
    transactionId: "TRX12345",
    date: new Date("2023-04-15"),
    description: "Storage fees payment",
    amount: 1250.00,
    method: "credit_card",
    status: "completed",
  },
  {
    id: 2,
    transactionId: "TRX12346",
    date: new Date("2023-04-01"),
    description: "Marketplace commission",
    amount: 450.75,
    method: "bank_transfer",
    status: "completed",
  },
  {
    id: 3,
    transactionId: "TRX12347",
    date: new Date("2023-03-15"),
    description: "Storage fees payment",
    amount: 1250.00,
    method: "credit_card",
    status: "completed",
  },
  {
    id: 4,
    transactionId: "TRX12348",
    date: new Date("2023-03-10"),
    description: "Marketplace commission",
    amount: 325.50,
    method: "bank_transfer",
    status: "completed",
  },
  {
    id: 5,
    transactionId: "TRX12349",
    date: new Date("2023-02-15"),
    description: "Storage fees payment",
    amount: 1250.00,
    method: "credit_card",
    status: "completed",
  },
];

// Upcoming payments mock data
const mockUpcomingPayments = [
  {
    id: 1,
    description: "Storage fees - May 2023",
    dueDate: new Date("2023-05-15"),
    amount: 1250.00,
    status: "pending",
  },
  {
    id: 2,
    description: "Marketplace fees - May 2023",
    dueDate: new Date("2023-05-05"),
    amount: 480.25,
    status: "pending",
  },
];

export default function FinancePaymentsPage() {
  const [currentPage, setCurrentPage] = useState(1);
  const [activeTab, setActiveTab] = useState("history");
  const { activeCurrency } = useCurrency();
  const { toast } = useToast();
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState<any>(null);
  
  const pageSize = 5;
  
  // Pagination for payment history
  const paginatedPayments = mockPayments.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );
  
  // Fetch payment data from API
  const { data: paymentStats, isLoading: isStatsLoading } = useQuery({
    queryKey: ['/api/payment-stats'],
    queryFn: async () => {
      const res = await fetch('/api/payment-stats');
      if (!res.ok) throw new Error('Failed to fetch payment stats');
      return res.json();
    }
  });
  
  const { data: upcomingPayments, isLoading: isUpcomingLoading } = useQuery({
    queryKey: ['/api/upcoming-payments'],
    queryFn: async () => {
      const res = await fetch('/api/upcoming-payments');
      if (!res.ok) throw new Error('Failed to fetch upcoming payments');
      return res.json();
    }
  });
  
  // Function to handle "Pay Now" button click
  const handlePayNow = (payment: any) => {
    setSelectedPayment(payment);
    setShowPaymentDialog(true);
  };
  
  // Function to handle successful payment
  const handlePaymentSuccess = () => {
    toast({
      title: 'Payment processed successfully',
      description: 'Your payment has been processed successfully.',
      variant: 'default',
    });
    
    // Here you would typically refetch the data
    // queryClient.invalidateQueries(['/api/upcoming-payments']);
    // queryClient.invalidateQueries(['/api/payment-stats']);
  };
  
  // Function to get payment method badge
  const getMethodBadge = (method: string) => {
    switch (method) {
      case "credit_card":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">Credit Card</Badge>;
      case "bank_transfer":
        return <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-200">Bank Transfer</Badge>;
      default:
        return <Badge variant="outline">{method}</Badge>;
    }
  };
  
  // Function to get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-200">Completed</Badge>;
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">Pending</Badge>;
      case "failed":
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-200">Failed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <FinanceLayout title="Payments">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">This Month</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">
                  {formatCurrency(3275.50, activeCurrency)}
                </p>
              </div>
              <div className="bg-green-100 p-3 rounded-full">
                <CreditCard className="h-5 w-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Upcoming</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">
                  {formatCurrency(1730.25, activeCurrency)}
                </p>
              </div>
              <div className="bg-orange-100 p-3 rounded-full">
                <ArrowRight className="h-5 w-5 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Success Rate</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">
                  99.2%
                </p>
              </div>
              <div className="bg-blue-100 p-3 rounded-full">
                <BadgeCheck className="h-5 w-5 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Total YTD</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">
                  {formatCurrency(32750.00, activeCurrency)}
                </p>
              </div>
              <div className="bg-purple-100 p-3 rounded-full">
                <CreditCard className="h-5 w-5 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Payment Management</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-6">
              <TabsTrigger value="history">Payment History</TabsTrigger>
              <TabsTrigger value="upcoming">Upcoming Payments</TabsTrigger>
              <TabsTrigger value="settings">Payment Settings</TabsTrigger>
            </TabsList>
            
            <TabsContent value="history">
              <DataTable
                data={paginatedPayments}
                columns={[
                  {
                    header: "Transaction ID",
                    accessorKey: "transactionId",
                  },
                  {
                    header: "Date",
                    cell: (row) => format(new Date(row.date), "MMM dd, yyyy"),
                  },
                  {
                    header: "Description",
                    accessorKey: "description",
                  },
                  {
                    header: "Amount",
                    cell: (row) => formatCurrency(row.amount, activeCurrency),
                  },
                  {
                    header: "Method",
                    cell: (row) => getMethodBadge(row.method),
                  },
                  {
                    header: "Status",
                    cell: (row) => getStatusBadge(row.status),
                  },
                  {
                    header: "",
                    cell: () => (
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    ),
                  },
                ]}
                pagination={{
                  currentPage,
                  pageSize,
                  totalItems: mockPayments.length,
                  onPageChange: setCurrentPage,
                }}
              />
            </TabsContent>
            
            <TabsContent value="upcoming">
              <div className="space-y-4">
                {mockUpcomingPayments.map((payment) => (
                  <div
                    key={payment.id}
                    className="p-4 border rounded-lg flex flex-col md:flex-row md:items-center md:justify-between"
                  >
                    <div>
                      <h3 className="font-semibold">{payment.description}</h3>
                      <p className="text-sm text-gray-500">
                        Due: {format(new Date(payment.dueDate), "MMM dd, yyyy")}
                      </p>
                    </div>
                    <div className="mt-4 md:mt-0 flex items-center">
                      <span className="font-bold mr-4">
                        {formatCurrency(payment.amount, activeCurrency)}
                      </span>
                      <Button onClick={() => handlePayNow(payment)}>Pay Now</Button>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="settings">
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">Payment Methods</h3>
                  <div className="border rounded-lg p-4 mb-4 flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="bg-blue-100 p-2 rounded-full mr-3">
                        <CreditCard className="h-5 w-5 text-blue-600" />
                      </div>
                      <div>
                        <p className="font-medium">Visa ending in 4242</p>
                        <p className="text-sm text-gray-500">Expires 12/25</p>
                      </div>
                    </div>
                    <Badge>Default</Badge>
                  </div>
                  <Button variant="outline">
                    <CreditCard className="h-4 w-4 mr-2" />
                    Add Payment Method
                  </Button>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-4">Billing Settings</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between border-b pb-4">
                      <div>
                        <p className="font-medium">Billing Email</p>
                        <p className="text-sm text-gray-500">billing@coldfarms.com</p>
                      </div>
                      <Button variant="outline" size="sm">Edit</Button>
                    </div>
                    <div className="flex items-center justify-between border-b pb-4">
                      <div>
                        <p className="font-medium">Billing Address</p>
                        <p className="text-sm text-gray-500">123 Market St, San Francisco, CA 94103</p>
                      </div>
                      <Button variant="outline" size="sm">Edit</Button>
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Tax ID</p>
                        <p className="text-sm text-gray-500">US123456789</p>
                      </div>
                      <Button variant="outline" size="sm">Edit</Button>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      
      {/* Payment Dialog */}
      {selectedPayment && (
        <PaymentDialog 
          open={showPaymentDialog}
          onOpenChange={setShowPaymentDialog}
          amount={selectedPayment.amount}
          title={`Pay ${selectedPayment.description}`}
          description={`Please complete your payment for ${selectedPayment.description} due on ${format(new Date(selectedPayment.dueDate), "MMM dd, yyyy")}.`}
          onSuccess={handlePaymentSuccess}
        />
      )}
    </FinanceLayout>
  );
}