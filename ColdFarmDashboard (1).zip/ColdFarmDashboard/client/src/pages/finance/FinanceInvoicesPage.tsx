import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { FinanceLayout } from "@/components/finance/FinanceLayout";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Download, Eye, Filter, Plus } from "lucide-react";
import { format } from "date-fns";
import { formatCurrency } from "@/lib/currency";
import { useCurrency } from "@/lib/currency-context";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Mock invoice data - in a real app, this would come from the API
const mockInvoices = [
  {
    id: 1,
    invoiceNumber: "INV-2023-001",
    date: new Date("2023-01-15"),
    dueDate: new Date("2023-02-15"),
    customer: "Green Valley Farms",
    amount: 1250.00,
    status: "paid",
  },
  {
    id: 2,
    invoiceNumber: "INV-2023-002",
    date: new Date("2023-02-01"),
    dueDate: new Date("2023-03-01"),
    customer: "Organic Harvest Co.",
    amount: 980.50,
    status: "paid",
  },
  {
    id: 3,
    invoiceNumber: "INV-2023-003",
    date: new Date("2023-02-15"),
    dueDate: new Date("2023-03-15"),
    customer: "Sunshine Foods Ltd.",
    amount: 1600.25,
    status: "paid",
  },
  {
    id: 4,
    invoiceNumber: "INV-2023-004",
    date: new Date("2023-03-05"),
    dueDate: new Date("2023-04-05"),
    customer: "Nature's Best Produce",
    amount: 2100.75,
    status: "pending",
  },
  {
    id: 5,
    invoiceNumber: "INV-2023-005",
    date: new Date("2023-03-20"),
    dueDate: new Date("2023-04-20"),
    customer: "Fresh Fields Farms",
    amount: 750.30,
    status: "overdue",
  },
  {
    id: 6,
    invoiceNumber: "INV-2023-006",
    date: new Date("2023-04-01"),
    dueDate: new Date("2023-05-01"),
    customer: "Green Valley Farms",
    amount: 1350.00,
    status: "pending",
  },
  {
    id: 7,
    invoiceNumber: "INV-2023-007",
    date: new Date("2023-04-15"),
    dueDate: new Date("2023-05-15"),
    customer: "Organic Harvest Co.",
    amount: 1100.50,
    status: "draft",
  },
];

export default function FinanceInvoicesPage() {
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { activeCurrency } = useCurrency();
  
  const pageSize = 5;
  
  // Filter invoices based on search term and status
  const filteredInvoices = mockInvoices.filter((invoice) => {
    const matchesSearch = 
      invoice.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.customer.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || invoice.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });
  
  // Pagination
  const totalItems = filteredInvoices.length;
  const paginatedInvoices = filteredInvoices.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );
  
  const handleSearch = (term: string) => {
    setSearchTerm(term);
    setCurrentPage(1);
  };

  // Status badge variants
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-200">Paid</Badge>;
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">Pending</Badge>;
      case "overdue":
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-200">Overdue</Badge>;
      case "draft":
        return <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-200">Draft</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <FinanceLayout title="Invoices">
      <Card>
        <CardContent className="p-6">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" onClick={() => setIsDialogOpen(true)}>
                <Filter className="h-4 w-4 mr-2" />
                Filter
              </Button>
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Filter Invoices</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-2">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Status</label>
                      <Select value={statusFilter} onValueChange={setStatusFilter}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Statuses</SelectItem>
                          <SelectItem value="paid">Paid</SelectItem>
                          <SelectItem value="pending">Pending</SelectItem>
                          <SelectItem value="overdue">Overdue</SelectItem>
                          <SelectItem value="draft">Draft</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex justify-end">
                      <Button 
                        variant="outline" 
                        className="mr-2"
                        onClick={() => {
                          setStatusFilter("all");
                          setSearchTerm("");
                        }}
                      >
                        Reset
                      </Button>
                      <Button onClick={() => setIsDialogOpen(false)}>
                        Apply
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              New Invoice
            </Button>
          </div>
          
          <DataTable
            data={paginatedInvoices}
            columns={[
              {
                header: "Invoice #",
                accessorKey: "invoiceNumber",
              },
              {
                header: "Date",
                cell: (row) => format(new Date(row.date), "MMM dd, yyyy"),
              },
              {
                header: "Due Date",
                cell: (row) => format(new Date(row.dueDate), "MMM dd, yyyy"),
              },
              {
                header: "Customer",
                accessorKey: "customer",
              },
              {
                header: "Amount",
                cell: (row) => formatCurrency(row.amount, activeCurrency),
              },
              {
                header: "Status",
                cell: (row) => getStatusBadge(row.status),
              },
              {
                header: "Actions",
                cell: () => (
                  <div className="flex space-x-2">
                    <Button variant="ghost" size="icon">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon">
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>
                ),
              },
            ]}
            searchPlaceholder="Search invoices..."
            onSearch={handleSearch}
            pagination={{
              currentPage,
              pageSize,
              totalItems,
              onPageChange: setCurrentPage,
            }}
          />
        </CardContent>
      </Card>
    </FinanceLayout>
  );
}