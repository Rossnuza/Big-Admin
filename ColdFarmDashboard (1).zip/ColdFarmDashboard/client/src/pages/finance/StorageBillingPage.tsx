import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { FinanceLayout } from "@/components/finance/FinanceLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useCurrency } from "@/lib/currency-context";
import { formatCurrency } from "@/lib/currency";
import { 
  Download, 
  FileSpreadsheet, 
  Search, 
  Users, 
  RefreshCw, 
  ArrowUpDown,
  FileText,
  AlertCircle
} from "lucide-react";

interface StorageCostsResponse {
  farmers: {
    farmerId: number;
    farmerName: string;
    totalCost: number;
    formattedCost: string;
    itemCount: number;
    totalWeight: number;
  }[];
  totalRevenue: number;
  formattedTotalRevenue: string;
}

export default function StorageBillingPage() {
  const { activeCurrency } = useCurrency();
  const [searchQuery, setSearchQuery] = useState("");
  
  const { data: storageCosts, isLoading, error, refetch } = useQuery<StorageCostsResponse>({
    queryKey: ["/api/finance/storage-costs"],
    queryFn: async () => {
      const response = await fetch("/api/finance/storage-costs");
      if (!response.ok) {
        throw new Error("Failed to fetch storage costs");
      }
      return response.json();
    },
  });
  
  const filteredFarmers = storageCosts?.farmers.filter(farmer => 
    farmer.farmerName.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];
  
  return (
    <FinanceLayout title="Storage Billing Management">
      {/* Action Buttons */}
      <div className="flex flex-wrap justify-between items-center gap-4 mb-6">
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" className="shadow-sm">
            <FileSpreadsheet className="h-4 w-4 mr-2" />
            Generate Billing Reports
          </Button>
          <Button variant="outline" className="shadow-sm">
            <Download className="h-4 w-4 mr-2" />
            Export All Statements
          </Button>
        </div>
        
        <div className="relative w-full sm:w-auto">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search farmers..."
            className="w-full sm:w-[300px] pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>
      
      {/* Summary Statistics */}
      <Card className="mb-6">
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <h3 className="text-lg font-medium">Total Revenue</h3>
              <p className="text-3xl font-bold">
                {isLoading ? '...' : storageCosts?.formattedTotalRevenue || '0 XAF'}
              </p>
              <p className="text-sm text-muted-foreground">From cold storage services</p>
            </div>
            
            <div className="space-y-2">
              <h3 className="text-lg font-medium">Total Weight</h3>
              <p className="text-3xl font-bold">
                {isLoading ? '...' : 
                  (storageCosts?.farmers.reduce((acc, farmer) => acc + farmer.totalWeight, 0) || 0).toFixed(1) + ' kg'}
              </p>
              <p className="text-sm text-muted-foreground">Currently in storage</p>
            </div>
            
            <div className="space-y-2">
              <h3 className="text-lg font-medium">Active Farmers</h3>
              <p className="text-3xl font-bold">
                {isLoading ? '...' : storageCosts?.farmers.length || 0}
              </p>
              <p className="text-sm text-muted-foreground">Using storage services</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Farmer Billing Table */}
      <Card>
        <CardHeader>
          <CardTitle>Farmer Storage Billing</CardTitle>
          <CardDescription>
            Storage costs calculated at 10 XAF per kg per day
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
            </div>
          ) : error ? (
            <div className="flex flex-col items-center justify-center py-12">
              <AlertCircle className="h-12 w-12 text-red-500 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Failed to Load Billing Data</h3>
              <p className="text-muted-foreground mb-6">There was an error loading the storage billing information.</p>
              <Button onClick={() => refetch()} variant="outline">
                <RefreshCw className="h-4 w-4 mr-2" />
                Try Again
              </Button>
            </div>
          ) : (
            <>
              <Tabs defaultValue="all" className="mb-4">
                <TabsList>
                  <TabsTrigger value="all">All Farmers</TabsTrigger>
                  <TabsTrigger value="high-cost">High Cost</TabsTrigger>
                  <TabsTrigger value="recent">Recent Storage</TabsTrigger>
                </TabsList>
              </Tabs>
              
              <div className="rounded-md border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[250px]">Farmer Name</TableHead>
                      <TableHead>Items</TableHead>
                      <TableHead>Total Weight (kg)</TableHead>
                      <TableHead className="text-right">Storage Cost</TableHead>
                      <TableHead className="text-right"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredFarmers.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="h-24 text-center">
                          {searchQuery ? 'No farmers found matching your search.' : 'No farmers with storage costs available.'}
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredFarmers.map((farmer) => (
                        <TableRow key={farmer.farmerId}>
                          <TableCell className="font-medium">
                            {farmer.farmerName}
                          </TableCell>
                          <TableCell>{farmer.itemCount}</TableCell>
                          <TableCell>{farmer.totalWeight.toFixed(1)} kg</TableCell>
                          <TableCell className="text-right font-medium">
                            {farmer.formattedCost}
                          </TableCell>
                          <TableCell className="text-right">
                            <Link href={`/farmers/${farmer.farmerId}`}>
                              <Button variant="ghost" size="sm">
                                Details
                              </Button>
                            </Link>
                            <Link href={`/farmers/${farmer.farmerId}?tab=billing`}>
                              <Button variant="ghost" size="sm">
                                <FileText className="h-4 w-4 mr-2" />
                                Statement
                              </Button>
                            </Link>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
              
              {filteredFarmers.length > 0 && (
                <div className="flex items-center justify-between py-4">
                  <p className="text-sm text-muted-foreground">
                    Showing <strong>{filteredFarmers.length}</strong> of <strong>{storageCosts?.farmers.length}</strong> farmers
                  </p>
                  <Button variant="outline" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Export List
                  </Button>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>
    </FinanceLayout>
  );
}