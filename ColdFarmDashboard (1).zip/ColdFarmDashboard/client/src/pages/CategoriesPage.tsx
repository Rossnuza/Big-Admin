import { useState, useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { useWebSocket } from "@/lib/websocket-context";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PlusCircle, Edit, Trash2, Grid, Loader2, Tag, ArrowLeft } from "lucide-react";

interface Category {
  id: number;
  name: string;
  description: string;
  productCount: number;
}

interface ProductType {
  id: number;
  name: string;
  category: string;
  description: string;
  standardUnit: string;
}

export default function CategoriesPage() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [isAddingCategory, setIsAddingCategory] = useState(false);
  const [isAddingProductType, setIsAddingProductType] = useState(false);
  const [newCategory, setNewCategory] = useState({ name: "", description: "" });
  const [newProductType, setNewProductType] = useState({ 
    name: "", 
    category: "", 
    description: "", 
    standardUnit: "kg" 
  });
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [editingProductType, setEditingProductType] = useState<ProductType | null>(null);

  // Mock data - in a real app, this would come from the API
  const categoriesData: Category[] = [
    { id: 1, name: "Vegetables", description: "All vegetable products", productCount: 15 },
    { id: 2, name: "Fruits", description: "All fruit products", productCount: 12 },
    { id: 3, name: "Dairy", description: "Milk and cheese products", productCount: 5 },
    { id: 4, name: "Meat", description: "All meat products", productCount: 8 },
    { id: 5, name: "Grains", description: "Wheat, rice, and other grains", productCount: 7 },
  ];

  const productTypesData: ProductType[] = [
    { id: 1, name: "Tomatoes", category: "Vegetables", description: "Red ripe tomatoes", standardUnit: "kg" },
    { id: 2, name: "Potatoes", category: "Vegetables", description: "Starchy tubers", standardUnit: "kg" },
    { id: 3, name: "Onions", category: "Vegetables", description: "Pungent bulbs", standardUnit: "kg" },
    { id: 4, name: "Apples", category: "Fruits", description: "Sweet and crunchy", standardUnit: "kg" },
    { id: 5, name: "Bananas", category: "Fruits", description: "Yellow and sweet", standardUnit: "kg" },
    { id: 6, name: "Milk", category: "Dairy", description: "Fresh cow's milk", standardUnit: "liter" },
  ];

  // Real API call to fetch categories
  const { data: categories = [], isLoading: isCategoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
    queryFn: async () => {
      const res = await fetch("/api/categories");
      if (!res.ok) throw new Error("Failed to fetch categories");
      return res.json();
    }
  });

  const { data: productTypes = [], isLoading: isProductTypesLoading } = useQuery<ProductType[]>({
    queryKey: ["/api/product-types"],
    queryFn: async () => {
      const res = await fetch("/api/product-types");
      if (!res.ok) throw new Error("Failed to fetch product types");
      return res.json();
    }
  });
  
  // WebSocket integration to update UI based on real-time events
  const { socket, status } = useWebSocket();
  
  useEffect(() => {
    if (socket && status === 'connected') {
      const handleWebSocketMessage = (event: MessageEvent) => {
        const message = JSON.parse(event.data);
        // Handle specific WebSocket message types related to categories/product types
        if (message.type === 'category_created' || 
            message.type === 'category_updated' || 
            message.type === 'category_deleted') {
          queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
        }
        
        if (message.type === 'product_type_created' || 
            message.type === 'product_type_updated' || 
            message.type === 'product_type_deleted') {
          queryClient.invalidateQueries({ queryKey: ["/api/product-types"] });
          // Also refresh categories to update the product count
          queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
        }
      };
      
      socket.addEventListener('message', handleWebSocketMessage);
      
      // Cleanup the event listener when the component unmounts
      return () => {
        socket.removeEventListener('message', handleWebSocketMessage);
      };
    }
  }, [socket, status, queryClient]);

  // Category mutations
  const addCategoryMutation = useMutation({
    mutationFn: async (category: typeof newCategory) => {
      return apiRequest("POST", "/api/categories", category);
    },
    onSuccess: () => {
      // Invalidate and refetch the categories list
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      toast({
        title: "Category added",
        description: "The category has been added successfully.",
      });
      setIsAddingCategory(false);
      setNewCategory({ name: "", description: "" });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add category: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  const updateCategoryMutation = useMutation({
    mutationFn: async (category: Category) => {
      // In a real implementation:
      // return apiRequest("PUT", `/api/categories/${category.id}`, category);
      console.log("Updating category:", category);
      return Promise.resolve(category);
    },
    onSuccess: () => {
      // In a real implementation:
      // queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      toast({
        title: "Category updated",
        description: "The category has been updated successfully.",
      });
      setEditingCategory(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update category: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  const deleteCategoryMutation = useMutation({
    mutationFn: async (categoryId: number) => {
      // In a real implementation:
      // return apiRequest("DELETE", `/api/categories/${categoryId}`);
      console.log("Deleting category:", categoryId);
      return Promise.resolve({ success: true });
    },
    onSuccess: () => {
      // In a real implementation:
      // queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      toast({
        title: "Category deleted",
        description: "The category has been deleted successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete category: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  // Product type mutations
  const addProductTypeMutation = useMutation({
    mutationFn: async (productType: typeof newProductType) => {
      return apiRequest("POST", "/api/product-types", productType);
    },
    onSuccess: () => {
      // Invalidate and refetch both product types and categories lists
      // to update the product count in categories
      queryClient.invalidateQueries({ queryKey: ["/api/product-types"] });
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      toast({
        title: "Product type added",
        description: "The product type has been added successfully.",
      });
      setIsAddingProductType(false);
      setNewProductType({ name: "", category: "", description: "", standardUnit: "kg" });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add product type: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  const updateProductTypeMutation = useMutation({
    mutationFn: async (productType: ProductType) => {
      // In a real implementation:
      // return apiRequest("PUT", `/api/product-types/${productType.id}`, productType);
      console.log("Updating product type:", productType);
      return Promise.resolve(productType);
    },
    onSuccess: () => {
      // In a real implementation, invalidate both queries:
      queryClient.invalidateQueries({ queryKey: ["/api/product-types"] });
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      toast({
        title: "Product type updated",
        description: "The product type has been updated successfully.",
      });
      setEditingProductType(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update product type: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  const deleteProductTypeMutation = useMutation({
    mutationFn: async (productTypeId: number) => {
      // In a real implementation:
      // return apiRequest("DELETE", `/api/product-types/${productTypeId}`);
      console.log("Deleting product type:", productTypeId);
      return Promise.resolve({ success: true });
    },
    onSuccess: () => {
      // In a real implementation, invalidate both queries:
      queryClient.invalidateQueries({ queryKey: ["/api/product-types"] });
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      toast({
        title: "Product type deleted",
        description: "The product type has been deleted successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete product type: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  // Event handlers
  const handleAddCategory = () => {
    if (!newCategory.name) {
      toast({
        title: "Error",
        description: "Category name is required",
        variant: "destructive",
      });
      return;
    }
    addCategoryMutation.mutate(newCategory);
  };

  const handleUpdateCategory = () => {
    if (!editingCategory || !editingCategory.name) {
      toast({
        title: "Error",
        description: "Category name is required",
        variant: "destructive",
      });
      return;
    }
    updateCategoryMutation.mutate(editingCategory);
  };

  const handleDeleteCategory = (categoryId: number) => {
    const category = categories.find(cat => cat.id === categoryId);
    const hasProducts = category ? category.productCount > 0 : false;
    if (hasProducts) {
      toast({
        title: "Cannot delete",
        description: "This category has associated products. Remove them first.",
        variant: "destructive",
      });
      return;
    }
    deleteCategoryMutation.mutate(categoryId);
  };

  const handleAddProductType = () => {
    if (!newProductType.name || !newProductType.category) {
      toast({
        title: "Error",
        description: "Product name and category are required",
        variant: "destructive",
      });
      return;
    }
    addProductTypeMutation.mutate(newProductType);
  };

  const handleUpdateProductType = () => {
    if (!editingProductType || !editingProductType.name || !editingProductType.category) {
      toast({
        title: "Error",
        description: "Product name and category are required",
        variant: "destructive",
      });
      return;
    }
    updateProductTypeMutation.mutate(editingProductType);
  };

  const handleDeleteProductType = (productTypeId: number) => {
    deleteProductTypeMutation.mutate(productTypeId);
  };
  
  const handleGoBack = () => {
    setLocation('/');
  };

  return (
    <div className="container mx-auto py-6 max-w-6xl">
      <Button 
        variant="ghost" 
        size="sm" 
        onClick={handleGoBack} 
        className="mb-4 hover:bg-transparent"
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back
      </Button>
      
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Product Categories & Types</h1>
          <p className="text-muted-foreground mt-1">
            Organize products by creating categories and defining standard product types
          </p>
        </div>
        <div className="space-x-2">
          <Dialog open={isAddingCategory} onOpenChange={setIsAddingCategory}>
            <DialogTrigger asChild>
              <Button>
                <PlusCircle className="mr-2 h-4 w-4" />
                Add Category
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Category</DialogTitle>
                <DialogDescription>
                  Create a new category to organize your products
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="name">Category Name</Label>
                  <Input
                    id="name"
                    value={newCategory.name}
                    onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
                    placeholder="e.g., Vegetables, Fruits"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="description">Description (optional)</Label>
                  <Input
                    id="description"
                    value={newCategory.description}
                    onChange={(e) => setNewCategory({ ...newCategory, description: e.target.value })}
                    placeholder="Brief description of the category"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddingCategory(false)}>
                  Cancel
                </Button>
                <Button onClick={handleAddCategory} disabled={addCategoryMutation.isPending}>
                  {addCategoryMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Add Category
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Dialog open={isAddingProductType} onOpenChange={setIsAddingProductType}>
            <DialogTrigger asChild>
              <Button>
                <PlusCircle className="mr-2 h-4 w-4" />
                Add Product Type
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Product Type</DialogTitle>
                <DialogDescription>
                  Define a standard product type for your inventory
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="product-name">Product Name</Label>
                  <Input
                    id="product-name"
                    value={newProductType.name}
                    onChange={(e) => setNewProductType({ ...newProductType, name: e.target.value })}
                    placeholder="e.g., Tomatoes, Potatoes"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="product-category">Category</Label>
                  <Select
                    value={newProductType.category}
                    onValueChange={(value) => setNewProductType({ ...newProductType, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category.id} value={category.name}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="product-description">Description (optional)</Label>
                  <Input
                    id="product-description"
                    value={newProductType.description}
                    onChange={(e) => setNewProductType({ ...newProductType, description: e.target.value })}
                    placeholder="Brief description of the product"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="product-unit">Standard Unit</Label>
                  <Select
                    value={newProductType.standardUnit}
                    onValueChange={(value) => setNewProductType({ ...newProductType, standardUnit: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a unit" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="kg">Kilogram (kg)</SelectItem>
                      <SelectItem value="piece">Piece</SelectItem>
                      <SelectItem value="bundle">Bundle</SelectItem>
                      <SelectItem value="carton">Carton</SelectItem>
                      <SelectItem value="liter">Liter</SelectItem>
                      <SelectItem value="dozen">Dozen</SelectItem>
                      <SelectItem value="gram">Gram</SelectItem>
                      <SelectItem value="box">Box</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddingProductType(false)}>
                  Cancel
                </Button>
                <Button onClick={handleAddProductType} disabled={addProductTypeMutation.isPending}>
                  {addProductTypeMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Add Product Type
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Product Organization</CardTitle>
          <CardDescription>
            Create and manage the taxonomy that organizes all produce in your system.
            Define standard product types and group similar products into categories.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="col-span-1 bg-primary/5">
              <CardHeader className="pb-2">
                <div className="flex items-center">
                  <Tag className="mr-2 h-5 w-5 text-primary" />
                  <CardTitle className="text-base">Define Categories</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Create broad categories for grouping similar products together (e.g., Vegetables, Fruits, Grains)
                </p>
              </CardContent>
            </Card>
            <Card className="col-span-1 bg-primary/5">
              <CardHeader className="pb-2">
                <div className="flex items-center">
                  <Grid className="mr-2 h-5 w-5 text-primary" />
                  <CardTitle className="text-base">Create Product Types</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Define standard product types that belong to categories (e.g., Tomatoes, Potatoes, Onions)
                </p>
              </CardContent>
            </Card>
            <Card className="col-span-1 bg-primary/5">
              <CardHeader className="pb-2">
                <div className="flex items-center">
                  <Loader2 className="mr-2 h-5 w-5 text-primary" />
                  <CardTitle className="text-base">Standardize Units</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Set default measurement units for each product type to ensure consistency across the system
                </p>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="categories">
        <TabsList className="mb-4">
          <TabsTrigger value="categories">Categories</TabsTrigger>
          <TabsTrigger value="product-types">Product Types</TabsTrigger>
        </TabsList>
        
        <TabsContent value="categories">
          <Card>
            <CardHeader>
              <CardTitle>Categories</CardTitle>
              <CardDescription>
                Manage your product categories
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isCategoriesLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : (
                <Table>
                  <TableCaption>A list of your product categories</TableCaption>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead className="text-right">Product Types</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {categories.map((category) => (
                      <TableRow key={category.id}>
                        <TableCell className="font-medium">{category.name}</TableCell>
                        <TableCell>{category.description}</TableCell>
                        <TableCell className="text-right">{category.productCount}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end space-x-2">
                            <Dialog open={editingCategory?.id === category.id} onOpenChange={(open) => !open && setEditingCategory(null)}>
                              <DialogTrigger asChild>
                                <Button variant="ghost" size="icon" onClick={() => setEditingCategory(category)}>
                                  <Edit className="h-4 w-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Edit Category</DialogTitle>
                                </DialogHeader>
                                <div className="grid gap-4 py-4">
                                  <div className="grid gap-2">
                                    <Label htmlFor="edit-name">Category Name</Label>
                                    <Input
                                      id="edit-name"
                                      value={editingCategory?.name || ""}
                                      onChange={(e) => setEditingCategory(prev => prev ? { ...prev, name: e.target.value } : null)}
                                      placeholder="e.g., Vegetables, Fruits"
                                    />
                                  </div>
                                  <div className="grid gap-2">
                                    <Label htmlFor="edit-description">Description (optional)</Label>
                                    <Input
                                      id="edit-description"
                                      value={editingCategory?.description || ""}
                                      onChange={(e) => setEditingCategory(prev => prev ? { ...prev, description: e.target.value } : null)}
                                      placeholder="Brief description of the category"
                                    />
                                  </div>
                                </div>
                                <DialogFooter>
                                  <Button variant="outline" onClick={() => setEditingCategory(null)}>
                                    Cancel
                                  </Button>
                                  <Button onClick={handleUpdateCategory} disabled={updateCategoryMutation.isPending}>
                                    {updateCategoryMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                    Update Category
                                  </Button>
                                </DialogFooter>
                              </DialogContent>
                            </Dialog>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              onClick={() => handleDeleteCategory(category.id)}
                              disabled={category.productCount > 0}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="product-types">
          <Card>
            <CardHeader>
              <CardTitle>Product Types</CardTitle>
              <CardDescription>
                Manage your standard product types
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isProductTypesLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : (
                <Table>
                  <TableCaption>A list of your product types</TableCaption>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Standard Unit</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {productTypes.map((productType) => (
                      <TableRow key={productType.id}>
                        <TableCell className="font-medium">{productType.name}</TableCell>
                        <TableCell>{productType.category}</TableCell>
                        <TableCell>{productType.description}</TableCell>
                        <TableCell>{productType.standardUnit}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end space-x-2">
                            <Dialog open={editingProductType?.id === productType.id} onOpenChange={(open) => !open && setEditingProductType(null)}>
                              <DialogTrigger asChild>
                                <Button variant="ghost" size="icon" onClick={() => setEditingProductType(productType)}>
                                  <Edit className="h-4 w-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Edit Product Type</DialogTitle>
                                </DialogHeader>
                                <div className="grid gap-4 py-4">
                                  <div className="grid gap-2">
                                    <Label htmlFor="edit-product-name">Product Name</Label>
                                    <Input
                                      id="edit-product-name"
                                      value={editingProductType?.name || ""}
                                      onChange={(e) => setEditingProductType(prev => prev ? { ...prev, name: e.target.value } : null)}
                                      placeholder="e.g., Tomatoes, Potatoes"
                                    />
                                  </div>
                                  <div className="grid gap-2">
                                    <Label htmlFor="edit-product-category">Category</Label>
                                    <Select
                                      value={editingProductType?.category || ""}
                                      onValueChange={(value) => setEditingProductType(prev => prev ? { ...prev, category: value } : null)}
                                    >
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select a category" />
                                      </SelectTrigger>
                                      <SelectContent>
                                        {categories.map((category) => (
                                          <SelectItem key={category.id} value={category.name}>
                                            {category.name}
                                          </SelectItem>
                                        ))}
                                      </SelectContent>
                                    </Select>
                                  </div>
                                  <div className="grid gap-2">
                                    <Label htmlFor="edit-product-description">Description (optional)</Label>
                                    <Input
                                      id="edit-product-description"
                                      value={editingProductType?.description || ""}
                                      onChange={(e) => setEditingProductType(prev => prev ? { ...prev, description: e.target.value } : null)}
                                      placeholder="Brief description of the product"
                                    />
                                  </div>
                                  <div className="grid gap-2">
                                    <Label htmlFor="edit-product-unit">Standard Unit</Label>
                                    <Select
                                      value={editingProductType?.standardUnit || "kg"}
                                      onValueChange={(value) => setEditingProductType(prev => prev ? { ...prev, standardUnit: value } : null)}
                                    >
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select a unit" />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="kg">Kilogram (kg)</SelectItem>
                                        <SelectItem value="piece">Piece</SelectItem>
                                        <SelectItem value="bundle">Bundle</SelectItem>
                                        <SelectItem value="carton">Carton</SelectItem>
                                        <SelectItem value="liter">Liter</SelectItem>
                                        <SelectItem value="dozen">Dozen</SelectItem>
                                        <SelectItem value="gram">Gram</SelectItem>
                                        <SelectItem value="box">Box</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </div>
                                </div>
                                <DialogFooter>
                                  <Button variant="outline" onClick={() => setEditingProductType(null)}>
                                    Cancel
                                  </Button>
                                  <Button onClick={handleUpdateProductType} disabled={updateProductTypeMutation.isPending}>
                                    {updateProductTypeMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                    Update Product Type
                                  </Button>
                                </DialogFooter>
                              </DialogContent>
                            </Dialog>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              onClick={() => handleDeleteProductType(productType.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}