import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { SideBar } from "@/components/dashboard/SideBar";
import { Header } from "@/components/dashboard/Header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar } from "@/components/ui/calendar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { format } from "date-fns";
import { Loader2, CheckCircle, XCircle, Clock, CalendarIcon, Filter } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { useWebSocket } from "@/lib/websocket-context";

// Interface to match the API response
interface StorageBooking {
  id: number;
  farmerId: number;
  farmerName?: string;
  storageUnitId: number;
  storageUnitName?: string;
  productName: string;
  quantity: number;
  unit: string;
  requestDate: string;
  startDate: string;
  endDate?: string;
  status: string;
  adminNotes?: string;
  farmerNotes?: string;
  lastUpdated: string;
  inventoryItemId?: number;
  costs?: {
    dailyRate: number;
    dailyCost: number;
    durationDays: number;
    totalCost: number;
  };
}

interface StorageBookingDetail extends StorageBooking {
  storageUnit?: any;
  farmer?: any;
  inventoryItem?: any;
}

export default function StorageBookingRequestsPage() {
  const [selectedStatus, setSelectedStatus] = useState<string>("all");
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [selectedBooking, setSelectedBooking] = useState<number | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [statusUpdateNotes, setStatusUpdateNotes] = useState("");
  const { toast } = useToast();
  const { connected } = useWebSocket();

  // Fetch all storage bookings
  const { data: bookings, isLoading, error } = useQuery({
    queryKey: ["/api/storage-bookings", selectedStatus, selectedDate],
    queryFn: async () => {
      let url = "/api/storage-bookings";
      
      if (selectedStatus !== "all") {
        url += `?status=${selectedStatus}`;
      }
      
      // TODO: Add date filtering to the backend API
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error("Failed to fetch storage bookings");
      }
      const data = await response.json();
      return data;
    },
  });

  // Fetch single booking details when selected
  const { data: bookingDetail, isLoading: isLoadingDetail } = useQuery({
    queryKey: ["/api/storage-bookings", selectedBooking],
    queryFn: async () => {
      if (!selectedBooking) return null;
      
      const response = await fetch(`/api/storage-bookings/${selectedBooking}`);
      if (!response.ok) {
        throw new Error("Failed to fetch booking details");
      }
      const data = await response.json();
      return data as StorageBookingDetail;
    },
    enabled: !!selectedBooking,
  });

  // Mutation to update booking status
  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status, adminNotes }: { id: number, status: string, adminNotes?: string }) => {
      const response = await fetch(`/api/storage-bookings/${id}/status`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ status, adminNotes }),
      });
      
      if (!response.ok) {
        throw new Error("Failed to update booking status");
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/storage-bookings"] });
      setDetailOpen(false);
      setStatusUpdateNotes("");
      toast({
        title: "Status updated",
        description: "Booking status has been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update status: ${error instanceof Error ? error.message : "Unknown error"}`,
        variant: "destructive",
      });
    },
  });

  // Handle WebSocket messages for real-time updates using the custom event
  useEffect(() => {
    const handleBookingUpdate = (event: Event) => {
      try {
        const message = (event as CustomEvent).detail;
        
        // Check for booking related events
        if (
          message.type === "booking_request_created" ||
          message.type === "booking_request_updated" ||
          message.type === "booking_status_changed"
        ) {
          // Invalidate the query to refresh the data
          queryClient.invalidateQueries({ queryKey: ["/api/storage-bookings"] });
          
          // Show toast notification
          let title = "Booking Request Update";
          let description = "A booking request has been updated.";
          
          if (message.type === "booking_request_created") {
            title = "New Booking Request";
            description = "A new booking request has been received.";
          } else if (message.type === "booking_status_changed") {
            title = "Status Changed";
            description = `Booking #${message.bookingId} status changed to ${message.newStatus}.`;
          }
          
          toast({ title, description });
        }
      } catch (error) {
        console.error("Error handling WebSocket message:", error);
      }
    };

    // Using the custom event dispatched by the WebSocketProvider
    window.addEventListener('coldfarms:ws-message', handleBookingUpdate);

    return () => {
      window.removeEventListener('coldfarms:ws-message', handleBookingUpdate);
    };
  }, [queryClient, toast]);

  // Handler to view details
  const handleViewDetails = (id: number) => {
    setSelectedBooking(id);
    setDetailOpen(true);
  };

  // Handle status update
  const handleStatusUpdate = (status: string) => {
    if (!bookingDetail) return;
    
    updateStatusMutation.mutate({
      id: bookingDetail.id,
      status,
      adminNotes: statusUpdateNotes,
    });
  };

  // Filter bookings by date
  const filteredBookings = bookings && selectedDate 
    ? bookings.filter((booking: StorageBooking) => {
        const bookingDate = new Date(booking.requestDate);
        return (
          bookingDate.getDate() === selectedDate.getDate() &&
          bookingDate.getMonth() === selectedDate.getMonth() &&
          bookingDate.getFullYear() === selectedDate.getFullYear()
        );
      })
    : bookings;

  // Get status badge styling
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Pending</Badge>;
      case "approved":
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Approved</Badge>;
      case "rejected":
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Rejected</Badge>;
      case "active":
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Active</Badge>;
      case "completed":
        return <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">Completed</Badge>;
      case "cancelled":
        return <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">Cancelled</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const formatDate = (dateString: string) => {
    return format(new Date(dateString), "MMM d, yyyy");
  };

  const formatDateTime = (dateString: string) => {
    return format(new Date(dateString), "MMM d, yyyy h:mm a");
  };

  const pendingCount = bookings?.filter((b: StorageBooking) => b.status === "pending").length || 0;

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <SideBar />
      <main className="flex-1 overflow-x-hidden bg-gray-100">
        <Header 
          title="Storage Booking Requests" 
          subtitle={`Manage farmer storage requests (${pendingCount} pending)`}
        />
        <div className="p-6">
          <div className="grid gap-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Requests</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>

                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="flex items-center gap-2">
                      <CalendarIcon className="h-4 w-4" />
                      {selectedDate ? format(selectedDate, "PPP") : "Pick a date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={selectedDate}
                      onSelect={setSelectedDate}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>

                {selectedDate && (
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setSelectedDate(undefined)}
                  >
                    Clear Date
                  </Button>
                )}
              </div>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Storage Booking Requests</CardTitle>
                <CardDescription>
                  View and manage storage booking requests from farmers
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex justify-center items-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : error ? (
                  <div className="text-center py-8 text-red-500">
                    Error loading booking requests. Please try again.
                  </div>
                ) : filteredBookings?.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    No booking requests found.
                  </div>
                ) : (
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Farmer</TableHead>
                          <TableHead>Storage Unit</TableHead>
                          <TableHead>Product & Quantity</TableHead>
                          <TableHead>Date Range</TableHead>
                          <TableHead>Request Date</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredBookings.map((booking: StorageBooking) => (
                          <TableRow key={booking.id}>
                            <TableCell className="font-medium">#{booking.id}</TableCell>
                            <TableCell>{booking.farmerName}</TableCell>
                            <TableCell>{booking.storageUnitName}</TableCell>
                            <TableCell>
                              {booking.productName}
                              <br />
                              <span className="text-sm text-gray-500">
                                {booking.quantity} {booking.unit}
                              </span>
                            </TableCell>
                            <TableCell>
                              {formatDate(booking.startDate)}
                              <br />
                              <span className="text-sm text-gray-500">
                                {booking.endDate ? `to ${formatDate(booking.endDate)}` : "No end date"}
                              </span>
                            </TableCell>
                            <TableCell>{formatDate(booking.requestDate)}</TableCell>
                            <TableCell>{getStatusBadge(booking.status)}</TableCell>
                            <TableCell>
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => handleViewDetails(booking.id)}
                              >
                                View Details
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Booking Details Dialog */}
          <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
            <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden flex flex-col">
              <DialogHeader>
                <DialogTitle>Booking Request Details</DialogTitle>
                <DialogDescription>
                  Review and manage this storage booking request
                </DialogDescription>
              </DialogHeader>
              
              {isLoadingDetail ? (
                <div className="flex justify-center items-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : !bookingDetail ? (
                <div className="text-center py-8 text-red-500">
                  Error loading booking details. Please try again.
                </div>
              ) : (
                <ScrollArea className="flex-1 pr-4">
                  <Tabs defaultValue="details" className="w-full">
                    <TabsList className="mb-4">
                      <TabsTrigger value="details">Booking Details</TabsTrigger>
                      <TabsTrigger value="farmer">Farmer Info</TabsTrigger>
                      <TabsTrigger value="storage">Storage Unit</TabsTrigger>
                      {bookingDetail.inventoryItem && (
                        <TabsTrigger value="inventory">Inventory</TabsTrigger>
                      )}
                    </TabsList>
                    
                    <TabsContent value="details" className="mt-0">
                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div>
                          <Label className="text-sm text-gray-500">Booking ID</Label>
                          <p className="text-base">#{bookingDetail.id}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Status</Label>
                          <p className="text-base">{getStatusBadge(bookingDetail.status)}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Product</Label>
                          <p className="text-base">{bookingDetail.productName}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Quantity</Label>
                          <p className="text-base">{bookingDetail.quantity} {bookingDetail.unit}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Start Date</Label>
                          <p className="text-base">{formatDate(bookingDetail.startDate)}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">End Date</Label>
                          <p className="text-base">
                            {bookingDetail.endDate ? formatDate(bookingDetail.endDate) : "No end date"}
                          </p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Request Date</Label>
                          <p className="text-base">{formatDateTime(bookingDetail.requestDate)}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Last Updated</Label>
                          <p className="text-base">{formatDateTime(bookingDetail.lastUpdated)}</p>
                        </div>
                        <div className="col-span-2">
                          <Label className="text-sm text-gray-500">Farmer Notes</Label>
                          <p className="text-base bg-gray-50 p-2 rounded-md">
                            {bookingDetail.farmerNotes || "No notes provided"}
                          </p>
                        </div>
                        <div className="col-span-2">
                          <Label className="text-sm text-gray-500">Admin Notes</Label>
                          <p className="text-base bg-gray-50 p-2 rounded-md">
                            {bookingDetail.adminNotes || "No admin notes"}
                          </p>
                        </div>

                        {bookingDetail.costs && (
                          <div className="col-span-2 mt-4">
                            <Card>
                              <CardHeader className="pb-2">
                                <CardTitle className="text-lg">Cost Breakdown</CardTitle>
                              </CardHeader>
                              <CardContent>
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <Label className="text-sm text-gray-500">Daily Rate</Label>
                                    <p className="text-base">{bookingDetail.costs.dailyRate} XAF per {bookingDetail.unit} per day</p>
                                  </div>
                                  <div>
                                    <Label className="text-sm text-gray-500">Daily Cost</Label>
                                    <p className="text-base">{bookingDetail.costs.dailyCost.toLocaleString()} XAF per day</p>
                                  </div>
                                  <div>
                                    <Label className="text-sm text-gray-500">Duration</Label>
                                    <p className="text-base">{bookingDetail.costs.durationDays} days</p>
                                  </div>
                                  <div>
                                    <Label className="text-sm text-gray-500">Total Cost</Label>
                                    <p className="text-base font-bold">{bookingDetail.costs.totalCost.toLocaleString()} XAF</p>
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          </div>
                        )}
                  </div>
                    </TabsContent>
                    
                    <TabsContent value="farmer" className="mt-0">
                      {bookingDetail.farmer && (
                        <div className="grid grid-cols-2 gap-4">
                          <div className="col-span-2 flex items-center gap-4 mb-2">
                            {bookingDetail.farmer.avatar && (
                              <img 
                                src={bookingDetail.farmer.avatar} 
                                alt={bookingDetail.farmer.name} 
                                className="w-12 h-12 rounded-full"
                              />
                            )}
                            <div>
                              <h3 className="text-lg font-medium">{bookingDetail.farmer.name}</h3>
                              <p className="text-gray-500">{bookingDetail.farmer.region}</p>
                            </div>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-500">Contact Person</Label>
                            <p className="text-base">{bookingDetail.farmer.contactPerson}</p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-500">Phone</Label>
                            <p className="text-base">{bookingDetail.farmer.phone}</p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-500">Email</Label>
                            <p className="text-base">{bookingDetail.farmer.email}</p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-500">Join Date</Label>
                            <p className="text-base">{formatDate(bookingDetail.farmer.joinDate)}</p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-500">Marketplace Opt-In</Label>
                            <p className="text-base">{bookingDetail.farmer.marketplaceOptIn ? "Yes" : "No"}</p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-500">Storage Agreement</Label>
                            <p className="text-base">{bookingDetail.farmer.storageAgreement ? "Yes" : "No"}</p>
                          </div>
                          <div className="col-span-2">
                            <Label className="text-sm text-gray-500">Notes</Label>
                            <p className="text-base bg-gray-50 p-2 rounded-md">
                              {bookingDetail.farmer.notes || "No notes available"}
                            </p>
                          </div>
                        </div>
                      )}
                    </TabsContent>
                    
                    <TabsContent value="storage" className="mt-0">
                      {bookingDetail.storageUnit && (
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label className="text-sm text-gray-500">Unit ID</Label>
                            <p className="text-base">{bookingDetail.storageUnit.unitId}</p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-500">Location</Label>
                            <p className="text-base">{bookingDetail.storageUnit.location}</p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-500">Status</Label>
                            <p className="text-base capitalize">{bookingDetail.storageUnit.status}</p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-500">Temperature</Label>
                            <p className="text-base">
                              {bookingDetail.storageUnit.temperature !== null 
                                ? `${bookingDetail.storageUnit.temperature}°C` 
                                : "N/A"}
                            </p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-500">Capacity</Label>
                            <p className="text-base">
                              {bookingDetail.storageUnit.capacity} / {bookingDetail.storageUnit.maxCapacity} kg
                              ({Math.round((bookingDetail.storageUnit.capacity / bookingDetail.storageUnit.maxCapacity) * 100)}%)
                            </p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-500">Solar Panel Status</Label>
                            <p className="text-base capitalize">{bookingDetail.storageUnit.solarPanelStatus}</p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-500">Battery Level</Label>
                            <p className="text-base">{bookingDetail.storageUnit.batteryLevel}%</p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-500">Last Maintenance</Label>
                            <p className="text-base">
                              {bookingDetail.storageUnit.lastMaintenance 
                                ? formatDate(bookingDetail.storageUnit.lastMaintenance)
                                : "N/A"}
                            </p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-500">Next Maintenance</Label>
                            <p className="text-base">
                              {bookingDetail.storageUnit.nextMaintenance
                                ? formatDate(bookingDetail.storageUnit.nextMaintenance)
                                : "N/A"}
                            </p>
                          </div>
                        </div>
                      )}
                    </TabsContent>

                    {bookingDetail.inventoryItem && (
                      <TabsContent value="inventory" className="mt-0">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label className="text-sm text-gray-500">Inventory ID</Label>
                            <p className="text-base">#{bookingDetail.inventoryItem.id}</p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-500">Product</Label>
                            <p className="text-base">{bookingDetail.inventoryItem.productName}</p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-500">Quantity</Label>
                            <p className="text-base">
                              {bookingDetail.inventoryItem.quantity} {bookingDetail.inventoryItem.unit}
                            </p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-500">Status</Label>
                            <p className="text-base capitalize">{bookingDetail.inventoryItem.status}</p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-500">Start Date</Label>
                            <p className="text-base">{formatDate(bookingDetail.inventoryItem.startDate)}</p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-500">End Date</Label>
                            <p className="text-base">
                              {bookingDetail.inventoryItem.endDate 
                                ? formatDate(bookingDetail.inventoryItem.endDate)
                                : "No end date"}
                            </p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-500">Daily Rate</Label>
                            <p className="text-base">{bookingDetail.inventoryItem.dailyRate ? "Yes" : "No"}</p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-500">Listed on Marketplace</Label>
                            <p className="text-base">
                              {bookingDetail.inventoryItem.listedOnMarketplace ? "Yes" : "No"}
                            </p>
                          </div>
                          <div className="col-span-2">
                            <Label className="text-sm text-gray-500">Notes</Label>
                            <p className="text-base bg-gray-50 p-2 rounded-md">
                              {bookingDetail.inventoryItem.notes || "No notes available"}
                            </p>
                          </div>
                        </div>
                      </TabsContent>
                    )}
                  </Tabs>

                  {bookingDetail.status === "pending" && (
                    <div className="mt-6">
                      <Label htmlFor="statusUpdateNotes">Admin Notes (visible to farmer)</Label>
                      <Textarea
                        id="statusUpdateNotes"
                        placeholder="Add notes about this decision..."
                        value={statusUpdateNotes}
                        onChange={(e) => setStatusUpdateNotes(e.target.value)}
                        className="mt-2"
                      />
                    </div>
                  )}
                </ScrollArea>
              )}
              
              <DialogFooter className="mt-4">
                {bookingDetail?.status === "pending" ? (
                  <div className="flex gap-2 justify-end">
                    <Button
                      variant="outline"
                      onClick={() => setDetailOpen(false)}
                    >
                      Cancel
                    </Button>
                    <Button
                      variant="destructive"
                      onClick={() => handleStatusUpdate("rejected")}
                      disabled={updateStatusMutation.isPending}
                    >
                      <XCircle className="mr-2 h-4 w-4" />
                      Reject
                    </Button>
                    <Button
                      onClick={() => handleStatusUpdate("approved")}
                      disabled={updateStatusMutation.isPending}
                    >
                      <CheckCircle className="mr-2 h-4 w-4" />
                      Approve
                    </Button>
                  </div>
                ) : (
                  <Button onClick={() => setDetailOpen(false)}>Close</Button>
                )}
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </main>
    </div>
  );
}