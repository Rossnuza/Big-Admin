import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useCurrency } from "@/lib/currency-context";
import { formatCurrency } from "@/lib/currency";

// Components
import { Header } from "@/components/dashboard/Header";
import { SideBar } from "@/components/dashboard/SideBar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar } from "@/components/ui/calendar";
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import { Skeleton } from "@/components/ui/skeleton";

// Icons
import { 
  Search, 
  ShoppingCart, 
  User, 
  Calendar as CalendarIcon, 
  MapPin, 
  PackageCheck, 
  Truck, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  ArrowUpDown,
  Download,
  Filter,
  MoreVertical,
  RefreshCw,
  Eye,
  CheckCircle,
  AlertCircle,
  TruckIcon
} from "lucide-react";

import { Order } from "@shared/schema";

const statusColors = {
  pending: "bg-yellow-100 text-yellow-800 border-yellow-200",
  processing: "bg-blue-100 text-blue-800 border-blue-200",
  shipped: "bg-indigo-100 text-indigo-800 border-indigo-200",
  delivered: "bg-green-100 text-green-800 border-green-200",
  completed: "bg-emerald-100 text-emerald-800 border-emerald-200",
  cancelled: "bg-red-100 text-red-800 border-red-200",
};

const statusIcons = {
  pending: <Clock className="h-4 w-4 text-yellow-600" />,
  processing: <RefreshCw className="h-4 w-4 text-blue-600" />,
  shipped: <Truck className="h-4 w-4 text-indigo-600" />,
  delivered: <PackageCheck className="h-4 w-4 text-green-600" />,
  completed: <CheckCircle className="h-4 w-4 text-emerald-600" />,
  cancelled: <AlertCircle className="h-4 w-4 text-red-600" />,
};

// Format date to a readable format
function formatDate(dateString: string | Date) {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('en-US', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(date);
}

export default function OrdersPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { activeCurrency } = useCurrency();
  
  // Query state
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [dateFilter, setDateFilter] = useState<string>("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [isFilterDropdownOpen, setIsFilterDropdownOpen] = useState(false);
  
  // Order management state
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isOrderDetailsOpen, setIsOrderDetailsOpen] = useState(false);
  const [isUpdateStatusOpen, setIsUpdateStatusOpen] = useState(false);
  
  const pageSize = 10;
  
  // Fetch orders
  const { 
    data: orders = [], 
    isLoading, 
    isError, 
    refetch 
  } = useQuery<Order[]>({
    queryKey: ['/api/orders', statusFilter, dateFilter, searchQuery],
    queryFn: async () => {
      const url = new URL('/api/orders', window.location.origin);
      
      if (statusFilter !== 'all') {
        url.searchParams.append('status', statusFilter);
      }
      
      if (dateFilter !== 'all') {
        url.searchParams.append('dateRange', dateFilter);
      }
      
      if (searchQuery) {
        url.searchParams.append('search', searchQuery);
      }
      
      const response = await fetch(url.toString());
      if (!response.ok) {
        throw new Error('Failed to fetch orders');
      }
      return response.json();
    }
  });
  
  // Update order status mutation
  const updateOrderStatusMutation = useMutation({
    mutationFn: async ({ orderId, newStatus }: { orderId: number, newStatus: string }) => {
      const res = await apiRequest("PATCH", `/api/orders/${orderId}/status`, { status: newStatus });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/orders'] });
      toast({
        title: "Status updated",
        description: "The order status has been successfully updated.",
      });
      setIsUpdateStatusOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update status",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Filter and paginate orders
  const filteredOrders = orders;
  
  // Paginate
  const totalItems = filteredOrders.length;
  const totalPages = Math.ceil(totalItems / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const paginatedOrders = filteredOrders.slice(startIndex, startIndex + pageSize);
  
  // Handle search
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentPage(1); // Reset to first page on new search
  };
  
  // Handle order actions
  const handleViewOrder = (order: Order) => {
    setSelectedOrder(order);
    setIsOrderDetailsOpen(true);
  };
  
  const handleUpdateStatus = (order: Order) => {
    setSelectedOrder(order);
    setIsUpdateStatusOpen(true);
  };
  
  const handleStatusChange = async (newStatus: string) => {
    if (selectedOrder) {
      updateOrderStatusMutation.mutate({ 
        orderId: selectedOrder.id, 
        newStatus 
      });
    }
  };
  
  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-background">
      <SideBar />
      
      <main className="flex-1">
        <Header title="Order Tracking" />
        
        <div className="p-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 space-y-4 md:space-y-0">
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Orders</h1>
              <p className="text-muted-foreground">
                Manage and track all customer orders from the marketplace
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-3">
              <form onSubmit={handleSearch} className="relative w-full sm:w-auto">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search orders..."
                  className="pl-8 w-full sm:w-[250px] rounded-md"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </form>
              
              <div className="flex gap-2">
                <DropdownMenu 
                  open={isFilterDropdownOpen} 
                  onOpenChange={setIsFilterDropdownOpen}
                >
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm" className="gap-1">
                      <Filter className="h-4 w-4" />
                      Filters
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-[240px] p-4">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <h4 className="font-medium text-sm">Order Status</h4>
                        <Select 
                          value={statusFilter} 
                          onValueChange={(value) => {
                            setStatusFilter(value);
                            setCurrentPage(1);
                          }}
                        >
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Filter by status" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Statuses</SelectItem>
                            <SelectItem value="pending">Pending</SelectItem>
                            <SelectItem value="processing">Processing</SelectItem>
                            <SelectItem value="shipped">Shipped</SelectItem>
                            <SelectItem value="delivered">Delivered</SelectItem>
                            <SelectItem value="completed">Completed</SelectItem>
                            <SelectItem value="cancelled">Cancelled</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <h4 className="font-medium text-sm">Order Date</h4>
                        <Select 
                          value={dateFilter} 
                          onValueChange={(value) => {
                            setDateFilter(value);
                            setCurrentPage(1);
                          }}
                        >
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Filter by date" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Time</SelectItem>
                            <SelectItem value="today">Today</SelectItem>
                            <SelectItem value="last7days">Last 7 Days</SelectItem>
                            <SelectItem value="last30days">Last 30 Days</SelectItem>
                            <SelectItem value="thisMonth">This Month</SelectItem>
                            <SelectItem value="lastMonth">Last Month</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full"
                        onClick={() => {
                          setStatusFilter("all");
                          setDateFilter("all");
                          setSearchQuery("");
                          setCurrentPage(1);
                          setIsFilterDropdownOpen(false);
                        }}
                      >
                        Reset Filters
                      </Button>
                    </div>
                  </DropdownMenuContent>
                </DropdownMenu>
                
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => refetch()}
                  className="gap-1"
                >
                  <RefreshCw className="h-4 w-4" />
                  Refresh
                </Button>
                
                <Button size="sm" variant="default" className="gap-1">
                  <Download className="h-4 w-4" />
                  Export
                </Button>
              </div>
            </div>
          </div>
          
          {/* Status Tabs */}
          <Tabs 
            defaultValue="all" 
            className="mb-6" 
            value={statusFilter} 
            onValueChange={(value) => {
              setStatusFilter(value);
              setCurrentPage(1);
            }}
          >
            <TabsList className="grid grid-cols-4 lg:grid-cols-7 mb-4">
              <TabsTrigger value="all" className="text-xs">All Orders</TabsTrigger>
              <TabsTrigger value="pending" className="text-xs">Pending</TabsTrigger>
              <TabsTrigger value="processing" className="text-xs">Processing</TabsTrigger>
              <TabsTrigger value="shipped" className="text-xs">Shipped</TabsTrigger>
              <TabsTrigger value="delivered" className="text-xs">Delivered</TabsTrigger>
              <TabsTrigger value="completed" className="text-xs">Completed</TabsTrigger>
              <TabsTrigger value="cancelled" className="text-xs">Cancelled</TabsTrigger>
            </TabsList>
          </Tabs>
          
          {/* Active Filters */}
          {(statusFilter !== "all" || dateFilter !== "all" || searchQuery) && (
            <div className="flex flex-wrap gap-2 mb-4">
              {statusFilter !== "all" && (
                <Badge variant="outline" className="flex items-center gap-1 py-1 px-2">
                  <span className="text-xs font-normal">Status: {statusFilter}</span>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-4 w-4 p-0 ml-1" 
                    onClick={() => setStatusFilter("all")}
                  >
                    <XCircle className="h-3 w-3" />
                  </Button>
                </Badge>
              )}
              
              {dateFilter !== "all" && (
                <Badge variant="outline" className="flex items-center gap-1 py-1 px-2">
                  <span className="text-xs font-normal">Date: {dateFilter}</span>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-4 w-4 p-0 ml-1" 
                    onClick={() => setDateFilter("all")}
                  >
                    <XCircle className="h-3 w-3" />
                  </Button>
                </Badge>
              )}
              
              {searchQuery && (
                <Badge variant="outline" className="flex items-center gap-1 py-1 px-2">
                  <span className="text-xs font-normal">Search: {searchQuery}</span>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-4 w-4 p-0 ml-1" 
                    onClick={() => setSearchQuery("")}
                  >
                    <XCircle className="h-3 w-3" />
                  </Button>
                </Badge>
              )}
              
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-6 px-2 text-xs"
                onClick={() => {
                  setStatusFilter("all");
                  setDateFilter("all");
                  setSearchQuery("");
                }}
              >
                Clear All
              </Button>
            </div>
          )}
          
          {/* Orders List */}
          {isLoading ? (
            // Loading skeleton
            <div className="space-y-4">
              {Array.from({ length: 5 }).map((_, i) => (
                <Card key={i} className="overflow-hidden">
                  <div className="p-4">
                    <div className="flex flex-col sm:flex-row gap-4">
                      <div className="flex-1 space-y-2">
                        <Skeleton className="h-5 w-1/4" />
                        <Skeleton className="h-4 w-1/2" />
                        <div className="flex gap-2 mt-2">
                          <Skeleton className="h-6 w-20" />
                          <Skeleton className="h-6 w-24" />
                        </div>
                      </div>
                      <div className="text-right space-y-2">
                        <Skeleton className="h-5 w-20 ml-auto" />
                        <Skeleton className="h-4 w-32 ml-auto" />
                        <div className="flex justify-end gap-2 mt-2">
                          <Skeleton className="h-8 w-8 rounded-md" />
                          <Skeleton className="h-8 w-8 rounded-md" />
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          ) : isError ? (
            // Error state
            <Card className="p-8 text-center">
              <CardTitle className="text-red-500 mb-2">Failed to load orders</CardTitle>
              <CardDescription>There was an error fetching the order data.</CardDescription>
              <Button onClick={() => refetch()} className="mt-4">
                Try Again
              </Button>
            </Card>
          ) : filteredOrders.length === 0 ? (
            // Empty state
            <Card className="p-8 text-center">
              <ShoppingCart className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <CardTitle className="mb-2">No orders found</CardTitle>
              <CardDescription>
                {searchQuery || statusFilter !== "all" || dateFilter !== "all" 
                  ? "Try adjusting your filters or search criteria" 
                  : "When customers place orders, they will appear here"}
              </CardDescription>
              {(searchQuery || statusFilter !== "all" || dateFilter !== "all") && (
                <Button 
                  variant="outline" 
                  className="mt-4"
                  onClick={() => {
                    setStatusFilter("all");
                    setDateFilter("all");
                    setSearchQuery("");
                  }}
                >
                  Clear Filters
                </Button>
              )}
            </Card>
          ) : (
            // Orders list
            <div className="space-y-4">
              {paginatedOrders.map((order) => (
                <Card key={order.id} className="overflow-hidden hover:shadow-md transition-shadow duration-200">
                  <div className="p-4">
                    <div className="flex flex-col sm:flex-row gap-4">
                      {/* Left column - Order info */}
                      <div className="flex-1">
                        <div className="flex flex-col sm:flex-row sm:items-center gap-2 mb-2">
                          <h3 className="text-base font-medium">
                            Order #{order.id}
                          </h3>
                          <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusColors[order.status as keyof typeof statusColors]}`}>
                            {statusIcons[order.status as keyof typeof statusIcons]}
                            <span className="ml-1 capitalize">{order.status}</span>
                          </div>
                        </div>
                        
                        <div className="text-sm text-muted-foreground flex items-center gap-1 mb-1">
                          <User className="h-3.5 w-3.5" />
                          <span>{order.customerName}</span>
                        </div>
                        
                        <div className="text-sm text-muted-foreground flex items-center gap-1 mb-1">
                          <CalendarIcon className="h-3.5 w-3.5" />
                          <span>{formatDate(order.orderDate)}</span>
                        </div>
                        
                        <div className="text-sm text-muted-foreground flex items-center gap-1">
                          <MapPin className="h-3.5 w-3.5" />
                          <span className="truncate max-w-[250px]">{order.deliveryAddress}</span>
                        </div>
                      </div>
                      
                      {/* Right column - Actions */}
                      <div className="flex flex-col items-end">
                        <div className="text-xl font-semibold mb-2">
                          {formatCurrency(order.total, activeCurrency)}
                        </div>
                        
                        <div className="text-sm text-muted-foreground mb-4">
                          {order.paymentMethod}
                        </div>
                        
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="flex gap-1 items-center"
                            onClick={() => handleViewOrder(order)}
                          >
                            <Eye className="h-4 w-4" />
                            View
                          </Button>
                          
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="outline" size="icon" className="h-9 w-9">
                                <MoreVertical className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => handleUpdateStatus(order)}>
                                Update Status
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                Generate Invoice
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                Print Shipping Label
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
              
              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex justify-center mt-6">
                  <Pagination>
                    <PaginationContent>
                      <PaginationItem>
                        <PaginationPrevious 
                          href="#" 
                          onClick={(e) => {
                            e.preventDefault();
                            setCurrentPage(prev => Math.max(1, prev - 1));
                          }}
                          className={currentPage === 1 ? "pointer-events-none opacity-50" : ""}
                        />
                      </PaginationItem>
                      
                      {Array.from({ length: totalPages }).map((_, i) => {
                        // Show first page, last page, and pages around current page
                        if (
                          i === 0 || 
                          i === totalPages - 1 || 
                          (i >= currentPage - 2 && i <= currentPage + 2)
                        ) {
                          return (
                            <PaginationItem key={i}>
                              <PaginationLink 
                                href="#" 
                                onClick={(e) => {
                                  e.preventDefault();
                                  setCurrentPage(i + 1);
                                }}
                                isActive={currentPage === i + 1}
                              >
                                {i + 1}
                              </PaginationLink>
                            </PaginationItem>
                          );
                        }
                        
                        // Show ellipsis for skipped pages
                        if (
                          (i === 1 && currentPage > 3) || 
                          (i === totalPages - 2 && currentPage < totalPages - 2)
                        ) {
                          return (
                            <PaginationItem key={i}>
                              <PaginationEllipsis />
                            </PaginationItem>
                          );
                        }
                        
                        return null;
                      })}
                      
                      <PaginationItem>
                        <PaginationNext 
                          href="#" 
                          onClick={(e) => {
                            e.preventDefault();
                            setCurrentPage(prev => Math.min(totalPages, prev + 1));
                          }}
                          className={currentPage === totalPages ? "pointer-events-none opacity-50" : ""}
                        />
                      </PaginationItem>
                    </PaginationContent>
                  </Pagination>
                </div>
              )}
            </div>
          )}
        </div>
      </main>
      
      {/* Order Details Dialog */}
      {selectedOrder && (
        <Dialog open={isOrderDetailsOpen} onOpenChange={setIsOrderDetailsOpen}>
          <DialogContent className="sm:max-w-[700px]">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                Order Details 
                <Badge className={`ml-2 ${statusColors[selectedOrder.status as keyof typeof statusColors]}`}>
                  {selectedOrder.status}
                </Badge>
              </DialogTitle>
              <DialogDescription>
                Order #{selectedOrder.id} placed on {formatDate(selectedOrder.orderDate)}
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Customer Info */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Customer Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div>
                    <div className="font-medium">Name</div>
                    <div>{selectedOrder.customerName}</div>
                  </div>
                  <div>
                    <div className="font-medium">Email</div>
                    <div>{selectedOrder.customerEmail}</div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Shipping Info */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Delivery Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div>
                    <div className="font-medium">Address</div>
                    <div>{selectedOrder.deliveryAddress}</div>
                  </div>
                  <div>
                    <div className="font-medium">Payment Method</div>
                    <div>{selectedOrder.paymentMethod}</div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Order Items */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Order Items</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border">
                  <div className="grid grid-cols-5 border-b p-3 text-sm font-medium">
                    <div className="col-span-2">Product</div>
                    <div className="text-center">Quantity</div>
                    <div className="text-center">Price</div>
                    <div className="text-right">Total</div>
                  </div>
                  
                  {/* This is a placeholder - in a real app, you'd fetch and display the actual order items */}
                  <div className="p-4 text-center text-sm text-muted-foreground">
                    <div className="mb-2">Loading order items...</div>
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="mx-auto"
                      onClick={() => {
                        toast({
                          title: "Fetching order items",
                          description: "This is a placeholder. In a real app, order items would be displayed here.",
                        });
                      }}
                    >
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Load Items
                    </Button>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between border-t pt-4">
                <div className="font-medium">Total</div>
                <div className="font-bold text-lg">
                  {formatCurrency(selectedOrder.total, activeCurrency)}
                </div>
              </CardFooter>
            </Card>
            
            {/* Order Timeline */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Order Timeline</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex gap-3">
                    <div className="mt-0.5 flex h-6 w-6 items-center justify-center rounded-full bg-green-100">
                      <CheckCircle2 className="h-4 w-4 text-green-600" />
                    </div>
                    <div>
                      <div className="font-medium">Order Received</div>
                      <div className="text-sm text-muted-foreground">
                        {formatDate(selectedOrder.orderDate)}
                      </div>
                    </div>
                  </div>
                  
                  {/* Placeholder - in a real app, you'd show actual order status updates */}
                  <div className="flex gap-3">
                    <div className="mt-0.5 flex h-6 w-6 items-center justify-center rounded-full bg-gray-100">
                      <Clock className="h-4 w-4 text-gray-500" />
                    </div>
                    <div>
                      <div className="font-medium">Status Updated to {selectedOrder.status}</div>
                      <div className="text-sm text-muted-foreground">Current status</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <DialogFooter className="flex flex-col sm:flex-row gap-2">
              <Button 
                variant="outline" 
                onClick={() => setIsOrderDetailsOpen(false)}
              >
                Close
              </Button>
              <Button 
                variant="default"
                onClick={() => {
                  setIsOrderDetailsOpen(false);
                  handleUpdateStatus(selectedOrder);
                }}
              >
                Update Status
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      
      {/* Update Status Dialog */}
      {selectedOrder && (
        <Dialog open={isUpdateStatusOpen} onOpenChange={setIsUpdateStatusOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Update Order Status</DialogTitle>
              <DialogDescription>
                Change the status for order #{selectedOrder.id}
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <h4 className="font-medium text-sm">Current Status</h4>
                <div className={`inline-flex items-center px-2.5 py-1.5 rounded-full text-xs font-medium ${statusColors[selectedOrder.status as keyof typeof statusColors]}`}>
                  {statusIcons[selectedOrder.status as keyof typeof statusIcons]}
                  <span className="ml-1 capitalize">{selectedOrder.status}</span>
                </div>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-medium text-sm">New Status</h4>
                <Select
                  defaultValue={selectedOrder.status}
                  onValueChange={handleStatusChange}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select new status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="processing">Processing</SelectItem>
                    <SelectItem value="shipped">Shipped</SelectItem>
                    <SelectItem value="delivered">Delivered</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <DialogFooter>
              <Button 
                variant="outline" 
                onClick={() => setIsUpdateStatusOpen(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                onClick={() => handleStatusChange(selectedOrder.status)}
                disabled={updateOrderStatusMutation.isPending}
              >
                {updateOrderStatusMutation.isPending ? (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    Updating...
                  </>
                ) : "Save Changes"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}