import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useCurrency } from "@/lib/currency-context";
import { formatCurrency } from "@/lib/currency";

// Components
import { Header } from "@/components/dashboard/Header";
import { SideBar } from "@/components/dashboard/SideBar";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";

// Icons
import {
  ArrowLeft,
  Calendar,
  CheckCircle2,
  Clock,
  Download,
  MapPin,
  PackageCheck,
  Printer,
  RefreshCw,
  Share,
  ShoppingCart,
  Truck,
  User,
  CheckCircle,
  AlertCircle,
  TruckIcon,
} from "lucide-react";

import { Order, OrderItem } from "@shared/schema";

// Status styles and icons
const statusColors = {
  pending: "bg-yellow-100 text-yellow-800 border-yellow-200",
  processing: "bg-blue-100 text-blue-800 border-blue-200",
  shipped: "bg-indigo-100 text-indigo-800 border-indigo-200",
  delivered: "bg-green-100 text-green-800 border-green-200",
  completed: "bg-emerald-100 text-emerald-800 border-emerald-200",
  cancelled: "bg-red-100 text-red-800 border-red-200",
};

const statusIcons = {
  pending: <Clock className="h-4 w-4 text-yellow-600" />,
  processing: <RefreshCw className="h-4 w-4 text-blue-600" />,
  shipped: <Truck className="h-4 w-4 text-indigo-600" />,
  delivered: <PackageCheck className="h-4 w-4 text-green-600" />,
  completed: <CheckCircle className="h-4 w-4 text-emerald-600" />,
  cancelled: <AlertCircle className="h-4 w-4 text-red-600" />,
};

// Format date to a readable format
function formatDate(dateString: string | Date) {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('en-US', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(date);
}

// Format time to a readable format
function formatTime(dateString: string | Date) {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('en-US', {
    hour: 'numeric',
    minute: 'numeric',
    hour12: true,
  }).format(date);
}

export default function OrderDetailPage() {
  const params = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { activeCurrency } = useCurrency();
  
  // Order management state
  const [isUpdateStatusOpen, setIsUpdateStatusOpen] = useState(false);
  
  // Get order ID from URL params
  const orderId = parseInt(params.id);
  
  // Fetch order details
  const { 
    data: order, 
    isLoading: isOrderLoading,
    isError: isOrderError,
    refetch: refetchOrder,
  } = useQuery<Order>({
    queryKey: [`/api/orders/${orderId}`],
    queryFn: async () => {
      const response = await fetch(`/api/orders/${orderId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch order details');
      }
      return response.json();
    },
    enabled: !isNaN(orderId)
  });
  
  // Fetch order items
  const { 
    data: orderItems = [], 
    isLoading: isItemsLoading,
    isError: isItemsError,
    refetch: refetchItems,
  } = useQuery<OrderItem[]>({
    queryKey: [`/api/orders/${orderId}/items`],
    queryFn: async () => {
      const response = await fetch(`/api/orders/${orderId}/items`);
      if (!response.ok) {
        throw new Error('Failed to fetch order items');
      }
      return response.json();
    },
    enabled: !isNaN(orderId)
  });
  
  // Update order status mutation
  const updateOrderStatusMutation = useMutation({
    mutationFn: async ({ orderId, newStatus }: { orderId: number, newStatus: string }) => {
      const res = await apiRequest("PATCH", `/api/orders/${orderId}/status`, { status: newStatus });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/orders/${orderId}`] });
      toast({
        title: "Status updated",
        description: "The order status has been successfully updated.",
      });
      setIsUpdateStatusOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update status",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle status change
  const handleStatusChange = async (newStatus: string) => {
    if (order) {
      updateOrderStatusMutation.mutate({ 
        orderId: order.id, 
        newStatus 
      });
    }
  };
  
  const isLoading = isOrderLoading || isItemsLoading;
  const isError = isOrderError || isItemsError;
  
  // If there's an error, show error message with retry option
  if (isError) {
    return (
      <div className="flex flex-col md:flex-row min-h-screen bg-background">
        <SideBar />
        
        <main className="flex-1">
          <Header title="Order Details" />
          
          <div className="p-6">
            <Breadcrumb className="mb-6">
              <BreadcrumbList>
                <BreadcrumbItem>
                  <BreadcrumbLink href="/orders">Orders</BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator />
                <BreadcrumbItem>
                  <BreadcrumbLink>Order #{orderId}</BreadcrumbLink>
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>
            
            <Card className="p-8 text-center">
              <CardTitle className="text-red-500 mb-2">Failed to load order</CardTitle>
              <CardDescription>There was an error fetching the order data.</CardDescription>
              <div className="flex justify-center gap-4 mt-6">
                <Button 
                  variant="outline" 
                  onClick={() => setLocation("/orders")}
                >
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Return to Orders
                </Button>
                <Button onClick={() => {
                  refetchOrder();
                  refetchItems();
                }}>
                  Try Again
                </Button>
              </div>
            </Card>
          </div>
        </main>
      </div>
    );
  }
  
  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-background">
      <SideBar />
      
      <main className="flex-1">
        <Header title="Order Details" />
        
        <div className="p-6">
          <Breadcrumb className="mb-6">
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink href="/orders">Orders</BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbLink>
                  {isLoading ? "Loading..." : `Order #${orderId}`}
                </BreadcrumbLink>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
          
          {isLoading ? (
            // Loading skeleton
            <div className="space-y-6">
              <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
                <div>
                  <Skeleton className="h-8 w-40 mb-2" />
                  <Skeleton className="h-5 w-60" />
                </div>
                <div className="flex flex-wrap gap-2">
                  <Skeleton className="h-10 w-24" />
                  <Skeleton className="h-10 w-24" />
                  <Skeleton className="h-10 w-36" />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader className="pb-2">
                    <Skeleton className="h-5 w-40" />
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-2/3" />
                    <Skeleton className="h-4 w-3/4" />
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <Skeleton className="h-5 w-40" />
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-2/3" />
                    <Skeleton className="h-4 w-3/4" />
                  </CardContent>
                </Card>
              </div>
              
              <Card>
                <CardHeader className="pb-2">
                  <Skeleton className="h-5 w-32" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-40 w-full" />
                </CardContent>
              </Card>
            </div>
          ) : order ? (
            <>
              <div className="flex flex-col md:flex-row justify-between md:items-center gap-4 mb-6">
                <div>
                  <div className="flex items-center gap-2">
                    <h1 className="text-2xl font-bold tracking-tight">Order #{order.id}</h1>
                    <Badge className={statusColors[order.status as keyof typeof statusColors]}>
                      {statusIcons[order.status as keyof typeof statusIcons]}
                      <span className="ml-1 capitalize">{order.status}</span>
                    </Badge>
                  </div>
                  <p className="text-muted-foreground mt-1">
                    Placed on {formatDate(order.orderDate)} at {formatTime(order.orderDate)}
                  </p>
                </div>
                
                <div className="flex flex-wrap gap-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="gap-1"
                    onClick={() => setLocation("/orders")}
                  >
                    <ArrowLeft className="h-4 w-4" />
                    Back
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="gap-1"
                  >
                    <Printer className="h-4 w-4" />
                    Print
                  </Button>
                  
                  <Button 
                    variant="default" 
                    size="sm" 
                    className="gap-1"
                    onClick={() => setIsUpdateStatusOpen(true)}
                  >
                    <RefreshCw className="h-4 w-4" />
                    Update Status
                  </Button>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                {/* Customer Info */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base font-medium">Customer Information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-start gap-2">
                      <User className="h-4 w-4 mt-0.5 text-muted-foreground" />
                      <div>
                        <div className="font-medium">{order.customerName}</div>
                        <div className="text-sm text-muted-foreground">{order.customerEmail}</div>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-2">
                      <Calendar className="h-4 w-4 mt-0.5 text-muted-foreground" />
                      <div>
                        <div className="font-medium">Order Date</div>
                        <div className="text-sm text-muted-foreground">
                          {formatDate(order.orderDate)} at {formatTime(order.orderDate)}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Shipping Info */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base font-medium">Delivery Information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-start gap-2">
                      <MapPin className="h-4 w-4 mt-0.5 text-muted-foreground" />
                      <div>
                        <div className="font-medium">Delivery Address</div>
                        <div className="text-sm text-muted-foreground">{order.deliveryAddress}</div>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-2">
                      <ShoppingCart className="h-4 w-4 mt-0.5 text-muted-foreground" />
                      <div>
                        <div className="font-medium">Payment Method</div>
                        <div className="text-sm text-muted-foreground">{order.paymentMethod}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              {/* Order Items */}
              <Card className="mb-6">
                <CardHeader className="pb-2 flex flex-row items-center justify-between">
                  <CardTitle className="text-base font-medium">Order Items</CardTitle>
                  <div className="text-sm text-muted-foreground">{orderItems.length} items</div>
                </CardHeader>
                <CardContent>
                  {isItemsLoading ? (
                    <div className="space-y-4 py-2">
                      {[1, 2, 3].map((_, index) => (
                        <div key={index} className="flex gap-4">
                          <Skeleton className="h-16 w-16 rounded-md" />
                          <div className="flex-1 space-y-2">
                            <Skeleton className="h-4 w-1/3" />
                            <Skeleton className="h-4 w-1/4" />
                          </div>
                          <div className="text-right space-y-2">
                            <Skeleton className="h-4 w-20 ml-auto" />
                            <Skeleton className="h-4 w-16 ml-auto" />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : orderItems.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <ShoppingCart className="h-12 w-12 mx-auto mb-4 opacity-20" />
                      <p>No items found for this order</p>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="mt-4"
                        onClick={() => refetchItems()}
                      >
                        <RefreshCw className="mr-2 h-4 w-4" />
                        Refresh
                      </Button>
                    </div>
                  ) : (
                    <div className="rounded-md border">
                      <div className="grid grid-cols-12 border-b p-3 text-sm font-medium">
                        <div className="col-span-6">Product</div>
                        <div className="col-span-2 text-center">Quantity</div>
                        <div className="col-span-2 text-center">Price</div>
                        <div className="col-span-2 text-right">Total</div>
                      </div>
                      
                      <div className="divide-y">
                        {orderItems.map((item) => (
                          <div key={item.id} className="grid grid-cols-12 p-3 text-sm">
                            <div className="col-span-6">
                              {/* In a real app, you'd fetch the product details */}
                              Product #{item.productId}
                            </div>
                            <div className="col-span-2 text-center">{item.quantity}</div>
                            <div className="col-span-2 text-center">
                              {formatCurrency(item.price, activeCurrency)}
                            </div>
                            <div className="col-span-2 text-right">
                              {formatCurrency(item.price * item.quantity, activeCurrency)}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
                <CardFooter className="flex justify-between border-t pt-4">
                  <div className="font-medium">Total Amount</div>
                  <div className="font-bold text-lg">
                    {formatCurrency(order.total, activeCurrency)}
                  </div>
                </CardFooter>
              </Card>
              
              {/* Order Timeline */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base font-medium">Order Timeline</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="flex gap-4">
                      <div className="flex flex-col items-center">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-green-100">
                          <CheckCircle2 className="h-4 w-4 text-green-600" />
                        </div>
                        <div className="flex-1 h-full w-px bg-border mt-2"></div>
                      </div>
                      <div className="space-y-1 pt-1">
                        <div className="font-medium">Order Placed</div>
                        <div className="text-sm text-muted-foreground">
                          {formatDate(order.orderDate)} at {formatTime(order.orderDate)}
                        </div>
                        <div className="text-sm mt-1">
                          Order #{order.id} was placed by {order.customerName}
                        </div>
                      </div>
                    </div>
                    
                    {/* In a real app, you'd fetch and display actual order status history */}
                    <div className="flex gap-4">
                      <div className="flex flex-col items-center">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-100">
                          {statusIcons[order.status as keyof typeof statusIcons] || <Clock className="h-4 w-4 text-blue-600" />}
                        </div>
                      </div>
                      <div className="space-y-1 pt-1">
                        <div className="font-medium">Status Updated to {order.status}</div>
                        <div className="text-sm text-muted-foreground">
                          Current status
                        </div>
                        <div className="text-sm mt-1">
                          The order is currently {order.status}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            // Order not found
            <Card className="p-8 text-center">
              <CardTitle className="mb-2">Order Not Found</CardTitle>
              <CardDescription>The order you're looking for doesn't exist or has been deleted.</CardDescription>
              <Button 
                onClick={() => setLocation("/orders")} 
                className="mt-6"
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Return to Orders
              </Button>
            </Card>
          )}
        </div>
      </main>
      
      {/* Update Status Dialog */}
      {order && (
        <Dialog open={isUpdateStatusOpen} onOpenChange={setIsUpdateStatusOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Update Order Status</DialogTitle>
              <DialogDescription>
                Change the status for order #{order.id}
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <h4 className="font-medium text-sm">Current Status</h4>
                <div className={`inline-flex items-center px-2.5 py-1.5 rounded-full text-xs font-medium ${statusColors[order.status as keyof typeof statusColors]}`}>
                  {statusIcons[order.status as keyof typeof statusIcons]}
                  <span className="ml-1 capitalize">{order.status}</span>
                </div>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-medium text-sm">New Status</h4>
                <Select
                  defaultValue={order.status}
                  onValueChange={handleStatusChange}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select new status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="processing">Processing</SelectItem>
                    <SelectItem value="shipped">Shipped</SelectItem>
                    <SelectItem value="delivered">Delivered</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <DialogFooter>
              <Button 
                variant="outline" 
                onClick={() => setIsUpdateStatusOpen(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                onClick={() => handleStatusChange(order.status)}
                disabled={updateOrderStatusMutation.isPending}
              >
                {updateOrderStatusMutation.isPending ? (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    Updating...
                  </>
                ) : "Save Changes"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}