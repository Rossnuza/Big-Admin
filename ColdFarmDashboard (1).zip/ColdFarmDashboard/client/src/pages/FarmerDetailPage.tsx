import { useParams, useLocation } from "wouter";
import { FarmerDetail } from "@/components/farmers/FarmerDetail";
import { SideBar } from "@/components/dashboard/SideBar";
import { Header } from "@/components/dashboard/Header";

export default function FarmerDetailPage() {
  const params = useParams();
  const [_, setLocation] = useLocation();
  
  // Get the farmer ID from the URL
  const farmerId = params.id ? parseInt(params.id) : 0;
  
  // Handle back button click
  const handleBack = () => {
    setLocation("/farmers");
  };
  
  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <SideBar />
      <main className="flex-1 overflow-x-hidden bg-gray-100">
        <Header title="Farmer Details" />
        <div className="p-6">
          <FarmerDetail farmerId={farmerId} onBack={handleBack} />
        </div>
      </main>
    </div>
  );
}