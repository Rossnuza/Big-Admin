import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { PageHeader } from "@/components/page-header";
import VerificationLogs from "@/components/verification/VerificationLogs";
import VerificationSettings from "@/components/verification/VerificationSettings";
import { MessagesSquare, Settings } from "lucide-react";

export default function VerificationPage() {
  return (
    <div className="container py-6 space-y-6">
      <PageHeader
        title="SMS Verification"
        description="Manage SMS verification for farmer authentication"
        icon={<MessagesSquare className="h-6 w-6" />}
      />
      
      <Separator />
      
      <Tabs defaultValue="logs" className="space-y-6">
        <TabsList>
          <TabsTrigger value="logs">
            <MessagesSquare className="h-4 w-4 mr-2" />
            Verification Logs
          </TabsTrigger>
          <TabsTrigger value="settings">
            <Settings className="h-4 w-4 mr-2" />
            Settings
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="logs" className="space-y-6">
          <VerificationLogs />
        </TabsContent>
        
        <TabsContent value="settings" className="space-y-6">
          <VerificationSettings />
        </TabsContent>
      </Tabs>
    </div>
  );
}