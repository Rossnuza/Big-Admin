import { FarmersPage as FarmersPageComponent } from "@/components/farmers/FarmersPage";

export default function FarmersPage() {
  return <FarmersPageComponent />;
}
