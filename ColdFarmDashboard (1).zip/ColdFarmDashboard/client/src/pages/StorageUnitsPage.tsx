import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { SideBar } from "@/components/dashboard/SideBar";
import { Header } from "@/components/dashboard/Header";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { StorageUnitForm } from "@/components/storage-units/StorageUnitForm";
import { StorageUnit } from "@shared/schema";
import { Plus, Search } from "lucide-react";
import { StorageUnitPage } from "@/components/storage-units/StorageUnitPage";
import { useParams } from "wouter";
import { StorageUnitCard } from "@/components/storage-units/StorageUnitCard";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DataTable } from "@/components/ui/data-table";
import { Badge } from "@/components/ui/badge";
import { Eye, MoreVertical } from "lucide-react";
import { Link } from "wouter";

function StorageUnitsListPage() {
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [currentPage, setCurrentPage] = useState(1);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [viewMode, setViewMode] = useState<"grid" | "table">("grid");
  const pageSize = 10;

  const { data: storageUnits = [], isLoading } = useQuery<StorageUnit[]>({
    queryKey: ["/api/storage-units"],
  });

  // Filter by search term
  const filteredUnits = storageUnits.filter(unit => 
    unit.unitId.toLowerCase().includes(searchTerm.toLowerCase()) ||
    unit.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Pagination
  const totalItems = filteredUnits.length;
  const paginatedUnits = filteredUnits.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  const handleSearch = (term: string) => {
    setSearchTerm(term);
    setCurrentPage(1);
  };

  const statusBadgeVariant = (status: string) => {
    switch (status.toLowerCase()) {
      case 'active':
      case 'operational':
        return 'bg-green-100 text-success';
      case 'maintenance':
        return 'bg-yellow-100 text-warning';
      case 'offline':
        return 'bg-red-100 text-error';
      default:
        return 'bg-gray-100 text-gray-600';
    }
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <SideBar />
      <main className="flex-1 overflow-x-hidden bg-gray-100">
        <Header title="Storage Units" />
        <div className="p-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
            <h1 className="text-2xl font-bold">Manage Storage Units</h1>
            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search units..."
                  className="pl-8 w-full md:w-[250px]"
                  value={searchTerm}
                  onChange={(e) => handleSearch(e.target.value)}
                />
              </div>
              <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Storage Unit
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[600px]">
                  <DialogHeader>
                    <DialogTitle>Add New Storage Unit</DialogTitle>
                  </DialogHeader>
                  <StorageUnitForm 
                    onSuccess={() => {
                      setIsAddModalOpen(false);
                    }} 
                  />
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <Tabs value={viewMode} onValueChange={(value) => setViewMode(value as "grid" | "table")} className="mt-4">
            <TabsList className="mb-4">
              <TabsTrigger value="grid">Grid View</TabsTrigger>
              <TabsTrigger value="table">Table View</TabsTrigger>
            </TabsList>
            
            <TabsContent value="grid" className="mt-0">
              {isLoading ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {Array.from({ length: 4 }).map((_, index) => (
                    <div key={index} className="h-64 bg-gray-200 animate-pulse rounded-lg"></div>
                  ))}
                </div>
              ) : (
                <>
                  {filteredUnits.length === 0 ? (
                    <div className="text-center p-8 bg-white rounded-lg shadow-sm">
                      <h3 className="text-lg font-medium">No storage units found</h3>
                      <p className="text-muted-foreground mt-1">Try adjusting your search or add a new storage unit.</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                      {paginatedUnits.map((unit) => (
                        <StorageUnitCard key={unit.id} storageUnit={unit} />
                      ))}
                    </div>
                  )}
                </>
              )}
            </TabsContent>
            
            <TabsContent value="table" className="mt-0">
              <DataTable
                data={paginatedUnits}
                columns={[
                  {
                    header: "Unit ID",
                    accessorKey: "unitId",
                  },
                  {
                    header: "Location",
                    accessorKey: "location",
                  },
                  {
                    header: "Temperature",
                    cell: (row) => row.temperature !== null ? `${row.temperature}°C` : "N/A",
                  },
                  {
                    header: "Status",
                    cell: (row) => (
                      <Badge variant="outline" className={statusBadgeVariant(row.status)}>
                        {row.status.charAt(0).toUpperCase() + row.status.slice(1)}
                      </Badge>
                    ),
                  },
                  {
                    header: "Next Maintenance",
                    cell: (row) => row.nextMaintenance 
                      ? new Date(row.nextMaintenance).toLocaleDateString() 
                      : "Not scheduled",
                  },
                  {
                    header: "Actions",
                    cell: (row) => (
                      <div className="flex justify-end">
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/storage-units/${row.id}`}>
                            <Eye className="h-4 w-4 text-accent" />
                          </Link>
                        </Button>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="h-4 w-4 text-gray-500" />
                        </Button>
                      </div>
                    ),
                  },
                ]}
                pagination={{
                  currentPage,
                  pageSize,
                  totalItems,
                  onPageChange: setCurrentPage,
                }}
                isLoading={isLoading}
              />
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}

export default function StorageUnitsPage() {
  const { id } = useParams<{ id: string }>();
  
  if (id) {
    return <StorageUnitPage />;
  }
  
  return <StorageUnitsListPage />;
}
