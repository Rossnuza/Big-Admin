import { MarketplacePage as MarketplacePageComponent } from "@/components/marketplace/MarketplacePage";

export default function MarketplacePage() {
  return <MarketplacePageComponent />;
}
