import { AnalyticsPage as AnalyticsPageComponent } from "@/components/analytics/AnalyticsPage";

export default function AnalyticsPage() {
  return <AnalyticsPageComponent />;
}
