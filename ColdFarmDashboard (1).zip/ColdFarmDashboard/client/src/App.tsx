import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import AuthPage from "./pages/auth-page";
import DashboardPage from "./pages/DashboardPage";
import StorageUnitsPage from "./pages/StorageUnitsPage";
import FarmersPage from "./pages/FarmersPage";
import FarmerDetailPage from "./pages/FarmerDetailPage";
import MarketplacePage from "./pages/MarketplacePage";
import CategoriesPage from "./pages/CategoriesPage";
import AnalyticsPage from "./pages/AnalyticsPage";
import SettingsPage from "./pages/SettingsPage";
import OrdersPage from "./pages/OrdersPage";
import OrderDetailPage from "./pages/OrderDetailPage";
import AccountPage from "./pages/AccountPage";
import StorageBookingRequestsPage from "./pages/StorageBookingRequestsPage";
import VerificationPage from "./pages/VerificationPage";
import FinanceOverviewPage from "./pages/finance/FinanceOverviewPage";
import FinanceInvoicesPage from "./pages/finance/FinanceInvoicesPage";
import FinancePaymentsPage from "./pages/finance/FinancePaymentsPage";
import RevenueManagementPage from "./pages/finance/RevenueManagementPage";
import FarmerPaymentsPage from "./pages/finance/FarmerPaymentsPage";
import StorageBillingPage from "./pages/finance/StorageBillingPage";
import { useEffect } from "react";
import { AuthProvider, useAuth } from "./lib/auth.tsx";
import { CurrencyProvider } from "./lib/currency-context";
import { WebSocketProvider } from "./lib/websocket-context";
import { WebSocketStatus } from "@/components/ui/ws-status";
import { WebSocketNotifications } from "@/components/ws-notifications";

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading && !user) {
      setLocation("/auth");
    }
  }, [user, isLoading, setLocation]);

  if (isLoading) {
    return <div className="flex h-screen items-center justify-center">Loading...</div>;
  }

  return user ? <>{children}</> : null;
}

// Redirect component to handle /login to /auth redirects
function LoginRedirect() {
  const [, setLocation] = useLocation();
  
  useEffect(() => {
    setLocation("/auth");
  }, [setLocation]);
  
  return null;
}

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      <Route path="/login" component={LoginRedirect} />
      
      <Route path="/">
        <ProtectedRoute>
          <DashboardPage />
        </ProtectedRoute>
      </Route>
      
      <Route path="/storage-units">
        <ProtectedRoute>
          <StorageUnitsPage />
        </ProtectedRoute>
      </Route>
      
      <Route path="/storage-units/:id">
        <ProtectedRoute>
          <StorageUnitsPage />
        </ProtectedRoute>
      </Route>
      
      <Route path="/farmers">
        <ProtectedRoute>
          <FarmersPage />
        </ProtectedRoute>
      </Route>
      
      <Route path="/farmers/:id">
        <ProtectedRoute>
          <FarmerDetailPage />
        </ProtectedRoute>
      </Route>
      
      <Route path="/marketplace">
        <ProtectedRoute>
          <MarketplacePage />
        </ProtectedRoute>
      </Route>
      
      <Route path="/categories">
        <ProtectedRoute>
          <CategoriesPage />
        </ProtectedRoute>
      </Route>
      
      <Route path="/orders">
        <ProtectedRoute>
          <OrdersPage />
        </ProtectedRoute>
      </Route>
      
      <Route path="/orders/:id">
        <ProtectedRoute>
          <OrderDetailPage />
        </ProtectedRoute>
      </Route>
      
      <Route path="/analytics">
        <ProtectedRoute>
          <AnalyticsPage />
        </ProtectedRoute>
      </Route>
      
      <Route path="/settings">
        <ProtectedRoute>
          <SettingsPage />
        </ProtectedRoute>
      </Route>
      
      <Route path="/account">
        <ProtectedRoute>
          <AccountPage />
        </ProtectedRoute>
      </Route>
      
      <Route path="/finance/overview">
        <ProtectedRoute>
          <FinanceOverviewPage />
        </ProtectedRoute>
      </Route>
      
      <Route path="/finance/invoices">
        <ProtectedRoute>
          <FinanceInvoicesPage />
        </ProtectedRoute>
      </Route>
      
      <Route path="/finance/payments">
        <ProtectedRoute>
          <FinancePaymentsPage />
        </ProtectedRoute>
      </Route>

      {/* Revenue management merged with overview */}
      
      <Route path="/finance/farmer-payments">
        <ProtectedRoute>
          <FarmerPaymentsPage />
        </ProtectedRoute>
      </Route>
      
      <Route path="/finance/storage-billing">
        <ProtectedRoute>
          <StorageBillingPage />
        </ProtectedRoute>
      </Route>
      
      <Route path="/storage-booking-requests">
        <ProtectedRoute>
          <StorageBookingRequestsPage />
        </ProtectedRoute>
      </Route>
      
      <Route path="/verification">
        <ProtectedRoute>
          <VerificationPage />
        </ProtectedRoute>
      </Route>
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <CurrencyProvider>
          <WebSocketProvider>
            <Router />
            <WebSocketStatus />
            <WebSocketNotifications />
            <Toaster />
          </WebSocketProvider>
        </CurrencyProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
