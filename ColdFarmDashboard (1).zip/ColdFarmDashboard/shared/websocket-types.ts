/**
 * WebSocket message types for the Coldfarms application
 */

// Base message interface
export interface BaseWSMessage {
  type: string;
  timestamp?: string;
  data?: any; // For backward compatibility with existing code
}

// Authentication messages
export interface AuthMessage extends BaseWSMessage {
  type: 'auth';
  farmerId: number;
}

export interface AuthSuccessMessage extends BaseWSMessage {
  type: 'auth_success';
  farmerId: number;
}

export interface AuthFailMessage extends BaseWSMessage {
  type: 'auth_fail';
  reason: string;
}

// Ping/Pong messages
export interface PingMessage extends BaseWSMessage {
  type: 'ping';
  data?: {
    timestamp: string;
  };
}

export interface PongMessage extends BaseWSMessage {
  type: 'pong';
  data?: {
    timestamp: string;
    serverTime: string;
  };
}

// Error messages
export interface ErrorMessage extends BaseWSMessage {
  type: 'error';
  error: {
    code: string;
    message: string;
  };
}

// Status messages
export interface StatusMessage extends BaseWSMessage {
  type: 'status';
  connections: number;
  authenticatedFarmers: number;
}

// Farmer activity messages
export interface FarmerRegisteredMessage extends BaseWSMessage {
  type: 'farmer_registered';
  farmerId: number;
  farmerName: string;
  farmerPhone: string;
  farmerRegion: string;
}

export interface FarmerLoginMessage extends BaseWSMessage {
  type: 'farmer_login';
  farmerId: number;
  farmerName: string;
}

export interface FarmerVerifiedMessage extends BaseWSMessage {
  type: 'farmer_verified';
  farmerId: number;
  farmerName: string;
}

export interface FarmerRejectedMessage extends BaseWSMessage {
  type: 'farmer_rejected';
  farmerId: number;
  farmerName: string;
  reason?: string;
}

// Booking messages
export interface BookingRequestCreatedMessage extends BaseWSMessage {
  type: 'booking_request_created';
  bookingId: number;
  farmerId: number;
  storageUnitId: number | string;
  product: string;
  quantity: number;
  startDate: string;
  endDate: string;
}

export interface BookingRequestApprovedMessage extends BaseWSMessage {
  type: 'booking_request_approved';
  bookingId: number;
  farmerId: number;
  adminNotes?: string;
}

export interface BookingRequestRejectedMessage extends BaseWSMessage {
  type: 'booking_request_rejected';
  bookingId: number;
  farmerId: number;
  reason?: string;
}

export interface BookingRequestDeletedMessage extends BaseWSMessage {
  type: 'booking_request_deleted';
  bookingId: number;
  farmerId: number;
}

// Inventory messages
export interface InventoryCreatedMessage extends BaseWSMessage {
  type: 'inventory_created';
  inventoryId: number;
  farmerId: number;
  productName: string;
  quantity: number;
  unit: string;
  storageUnitId: number | string;
}

export interface InventoryUpdatedMessage extends BaseWSMessage {
  type: 'inventory_updated';
  inventoryId: number;
  farmerId: number;
  changes: {
    quantity?: number;
    marketplaceListing?: boolean;
    pricePerKg?: number;
  };
}

// Marketplace messages
export interface MarketplaceListingCreatedMessage extends BaseWSMessage {
  type: 'marketplace_listing_created';
  inventoryId: number;
  farmerId: number;
  productName: string;
  quantity: number;
  pricePerKg: number;
}

export interface MarketplaceListingUpdatedMessage extends BaseWSMessage {
  type: 'marketplace_listing_updated';
  inventoryId: number;
  farmerId: number;
  changes: {
    quantity?: number;
    pricePerKg?: number;
    active?: boolean;
  };
}

// Order messages
export interface OrderCreatedMessage extends BaseWSMessage {
  type: 'order_created';
  orderId: number;
  buyerId: number;
  totalAmount: number;
  items: {
    inventoryId: number;
    farmerId: number;
    quantity: number;
    price: number;
  }[];
}

export interface OrderStatusChangedMessage extends BaseWSMessage {
  type: 'order_status_changed';
  orderId: number;
  buyerId: number;
  status: 'pending' | 'processing' | 'completed' | 'cancelled';
}

// Union type for all WebSocket messages
export type WebSocketMessage =
  | AuthMessage
  | AuthSuccessMessage
  | AuthFailMessage
  | PingMessage
  | PongMessage
  | ErrorMessage
  | StatusMessage
  | FarmerRegisteredMessage
  | FarmerLoginMessage
  | FarmerVerifiedMessage
  | FarmerRejectedMessage
  | BookingRequestCreatedMessage
  | BookingRequestApprovedMessage
  | BookingRequestRejectedMessage
  | BookingRequestDeletedMessage
  | InventoryCreatedMessage
  | InventoryUpdatedMessage
  | MarketplaceListingCreatedMessage
  | MarketplaceListingUpdatedMessage
  | OrderCreatedMessage
  | OrderStatusChangedMessage;