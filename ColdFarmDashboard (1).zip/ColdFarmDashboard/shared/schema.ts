import { pgTable, text, serial, integer, boolean, timestamp, real, json, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// User schema for authentication
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull().default("admin"),
  avatar: text("avatar"),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

// Cold Storage Unit schema
export const storageUnits = pgTable("storage_units", {
  id: serial("id").primaryKey(),
  unitId: text("unit_id").notNull().unique(),
  location: text("location").notNull(),
  temperature: real("temperature"),
  capacity: integer("capacity").notNull().default(0),
  maxCapacity: integer("max_capacity").notNull(),
  status: text("status").notNull().default("operational"),
  lastMaintenance: timestamp("last_maintenance"),
  nextMaintenance: timestamp("next_maintenance"),
  solarPanelStatus: text("solar_panel_status").notNull().default("operational"),
  batteryLevel: integer("battery_level").notNull().default(100),
});

// Create the base schema
const baseStorageUnitSchema = createInsertSchema(storageUnits).omit({
  id: true,
});

// Customize the insert schema to handle date strings
export const insertStorageUnitSchema = baseStorageUnitSchema.transform((data) => {
  // Convert string dates to actual Date objects
  return {
    ...data,
    lastMaintenance: data.lastMaintenance ? new Date(data.lastMaintenance) : null,
    nextMaintenance: data.nextMaintenance ? new Date(data.nextMaintenance) : null,
  };
});

// Farmer schema
export const farmers = pgTable("farmers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  region: text("region").notNull(),
  contactPerson: text("contact_person").notNull(),
  phone: text("phone").notNull(),
  email: text("email").notNull(),
  joinDate: timestamp("join_date").notNull().defaultNow(),
  marketplaceOptIn: boolean("marketplace_opt_in").notNull().default(false),
  storageAgreement: boolean("storage_agreement").notNull().default(false),
  avatar: text("avatar"),
  notes: text("notes"),
  // Mobile app fields
  registrationType: text("registration_type").notNull().default("admin"),
  verificationStatus: text("verification_status").notNull().default("verified"),
  temporaryPasscode: text("temporary_passcode"),
  lastLogin: timestamp("last_login"),
});

// Create the base farmer schema
const baseFarmerSchema = createInsertSchema(farmers).omit({
  id: true,
});

// Customize the insert schema to handle date strings
export const insertFarmerSchema = baseFarmerSchema.transform((data) => {
  return {
    ...data,
    joinDate: data.joinDate ? new Date(data.joinDate) : new Date(),
    lastLogin: data.lastLogin ? new Date(data.lastLogin) : undefined,
  };
});

// Product schema for marketplace
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  farmerId: integer("farmer_id").notNull(),
  price: real("price").notNull(),
  currency: text("currency").notNull().default("XAF"), // USD, EUR, XAF
  unit: text("unit").notNull(), // kg, piece, bundle, etc.
  quantityAvailable: integer("quantity_available").notNull(),
  expiryDate: timestamp("expiry_date"),
  description: text("description"),
  image: text("image"),
  isListed: boolean("is_listed").notNull().default(true),
  storageUnitId: integer("storage_unit_id").notNull(),
  inventoryItemId: integer("inventory_item_id"),
}, (table) => {
  return {
    farmerIdIdx: index("products_farmer_id_idx").on(table.farmerId),
    storageUnitIdIdx: index("products_storage_unit_id_idx").on(table.storageUnitId),
    inventoryItemIdIdx: index("products_inventory_item_id_idx").on(table.inventoryItemId),
  };
});

const baseProductSchema = createInsertSchema(products).omit({
  id: true,
});

export const insertProductSchema = baseProductSchema.transform((data) => {
  return {
    ...data,
    currency: data.currency || "XAF",
  };
});

// Activity for tracking recent actions
export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // new_farmer, temperature_alert, order_placed, maintenance, etc.
  description: text("description").notNull(),
  details: json("details"),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  relatedId: integer("related_id"),
  relatedType: text("related_type"), // storage_unit, farmer, product, etc.
});

export const insertActivitySchema = createInsertSchema(activities).omit({
  id: true,
});

// Consumers schema for marketplace users
export const consumers = pgTable("consumers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  phone: text("phone").notNull().unique(),
  email: text("email"),
  address: text("address"),
  location: json("location"), // For storing latitude and longitude
  registrationDate: timestamp("registration_date").notNull().defaultNow(),
  lastLogin: timestamp("last_login"),
  temporaryPasscode: text("temporary_passcode"),
  verificationStatus: text("verification_status").notNull().default("pending"), // pending, verified
});

export const insertConsumerSchema = createInsertSchema(consumers).omit({
  id: true,
});

// Orders for marketplace sales
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email").notNull(),
  total: real("total").notNull(),
  status: text("status").notNull().default("pending"), // pending, paid, processing, delivering, delivered, cancelled
  orderDate: timestamp("order_date").notNull().defaultNow(),
  deliveryAddress: text("delivery_address").notNull(),
  paymentMethod: text("payment_method").notNull().default("mobile_money"),
  // These fields are in our schema but might not be in the actual database yet
  consumerId: integer("consumer_id"),
  subtotal: real("subtotal"),
  deliveryFee: real("delivery_fee").default(0),
  deliveryLocation: json("delivery_location"), // For storing latitude and longitude
  paymentStatus: text("payment_status").default("pending"), // pending, completed, failed
  paymentReference: text("payment_reference"),
  deliveryNotes: text("delivery_notes"),
  estimatedDeliveryDate: timestamp("estimated_delivery_date"),
}, (table) => {
  return {
    // Only add this index if consumer_id exists in the database
    ...(table.consumerId && { consumerIdIdx: index("orders_consumer_id_idx").on(table.consumerId) }),
  };
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  orderDate: true,
});

// Order items for tracking products in each order
export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  productId: integer("product_id").notNull(),
  inventoryItemId: integer("inventory_item_id"),
  quantity: integer("quantity").notNull(),
  price: real("price").notNull(),
  unit: text("unit").default("kg"),
  productName: text("product_name"),
}, (table) => {
  return {
    orderIdIdx: index("order_items_order_id_idx").on(table.orderId),
    productIdIdx: index("order_items_product_id_idx").on(table.productId),
    inventoryItemIdIdx: index("order_items_inventory_item_id_idx").on(table.inventoryItemId),
  };
});

export const insertOrderItemSchema = createInsertSchema(orderItems).omit({
  id: true,
});

// Farmer Inventory schema for tracking what's in cold storage
export const farmerInventory = pgTable("farmer_inventory", {
  id: serial("id").primaryKey(),
  farmerId: integer("farmer_id").notNull(),
  storageUnitId: integer("storage_unit_id").notNull(),
  productName: text("product_name").notNull(),
  quantity: real("quantity").notNull(), // This is the actual column in the database
  unit: text("unit").notNull(), // kg, crates, boxes, etc.
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  dailyRate: boolean("daily_rate").notNull().default(true),
  status: text("status").notNull().default("active"), // active, expired, removed
  notes: text("notes"),
  price: real("price"),
  listedOnMarketplace: boolean("listed_on_marketplace").default(false),
  inventoryItemId: integer("inventory_item_id"),
}, (table) => {
  return {
    farmerIdIdx: index("farmer_inventory_farmer_id_idx").on(table.farmerId),
    storageUnitIdIdx: index("farmer_inventory_storage_unit_id_idx").on(table.storageUnitId),
    compositeIdx: index("farmer_inventory_farmer_storage_idx").on(
      table.farmerId, 
      table.storageUnitId
    ),
  };
});

// Create the base inventory schema
const baseInventorySchema = createInsertSchema(farmerInventory).omit({
  id: true,
});

// Customize the inventory schema to handle date strings
export const insertInventorySchema = baseInventorySchema.transform((data) => {
  return {
    ...data,
    startDate: data.startDate ? new Date(data.startDate) : new Date(),
    endDate: data.endDate ? new Date(data.endDate) : null,
  };
});

// Type definitions
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type StorageUnit = typeof storageUnits.$inferSelect;
export type InsertStorageUnit = z.infer<typeof insertStorageUnitSchema>;

export type Farmer = typeof farmers.$inferSelect;
export type InsertFarmer = z.infer<typeof insertFarmerSchema>;

export type Consumer = typeof consumers.$inferSelect;
export type InsertConsumer = z.infer<typeof insertConsumerSchema>;

export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;

export type Activity = typeof activities.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;

export type Order = typeof orders.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;

export type OrderItem = typeof orderItems.$inferSelect;
export type InsertOrderItem = z.infer<typeof insertOrderItemSchema>;

export type FarmerInventory = typeof farmerInventory.$inferSelect & {
  // Add these computed properties for compatibility
  quantityInKg?: number;
  ratePerKgPerDay?: number;
};
export type InsertFarmerInventory = z.infer<typeof insertInventorySchema>;

// Storage Booking Requests schema
export const storageBookings = pgTable("storage_bookings", {
  id: serial("id").primaryKey(),
  farmerId: integer("farmer_id").notNull(),
  storageUnitId: integer("storage_unit_id").notNull(),
  productName: text("product_name").notNull(),
  quantity: real("quantity").notNull(),
  unit: text("unit").notNull(), // kg, crates, boxes, etc.
  requestDate: timestamp("request_date").notNull().defaultNow(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  status: text("status").notNull().default("pending"), // pending, approved, rejected, active, completed, cancelled
  adminNotes: text("admin_notes"),
  farmerNotes: text("farmer_notes"),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
  inventoryItemId: integer("inventory_item_id"), // Reference to created inventory item when approved
}, (table) => {
  return {
    farmerIdIdx: index("storage_bookings_farmer_id_idx").on(table.farmerId),
    storageUnitIdIdx: index("storage_bookings_storage_unit_id_idx").on(table.storageUnitId),
    statusIdx: index("storage_bookings_status_idx").on(table.status),
  };
});

// Create the base storage booking schema
const baseStorageBookingSchema = createInsertSchema(storageBookings).omit({
  id: true,
  requestDate: true,
  lastUpdated: true,
  inventoryItemId: true,
});

// Customize the storage booking schema to handle date strings
export const insertStorageBookingSchema = baseStorageBookingSchema.transform((data) => {
  return {
    ...data,
    startDate: data.startDate ? new Date(data.startDate) : new Date(),
    endDate: data.endDate ? new Date(data.endDate) : null,
  };
});

export type StorageBooking = typeof storageBookings.$inferSelect;
export type InsertStorageBooking = z.infer<typeof insertStorageBookingSchema>;

// Categories schema
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertCategorySchema = createInsertSchema(categories).omit({
  id: true,
  createdAt: true,
});

export type Category = typeof categories.$inferSelect & {
  // Add computed property for compatibility with frontend
  productCount: number;
};
export type InsertCategory = z.infer<typeof insertCategorySchema>;

// Product Types schema
export const productTypes = pgTable("product_types", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  description: text("description"),
  standardUnit: text("standard_unit").notNull().default("kg"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => {
  return {
    categoryIdx: index("product_types_category_idx").on(table.category),
  };
});

export const insertProductTypeSchema = createInsertSchema(productTypes).omit({
  id: true,
  createdAt: true,
});

export type ProductType = typeof productTypes.$inferSelect;
export type InsertProductType = z.infer<typeof insertProductTypeSchema>;

// Cart items for marketplace
export const cartItems = pgTable("cart_items", {
  id: serial("id").primaryKey(),
  consumerId: integer("consumer_id").notNull(),
  productId: integer("product_id").notNull(),
  quantity: integer("quantity").notNull().default(1),
  addedAt: timestamp("added_at").notNull().defaultNow(),
}, (table) => {
  return {
    consumerIdIdx: index("cart_items_consumer_id_idx").on(table.consumerId),
    productIdIdx: index("cart_items_product_id_idx").on(table.productId),
  };
});

export const insertCartItemSchema = createInsertSchema(cartItems).omit({
  id: true,
  addedAt: true,
});

export type CartItem = typeof cartItems.$inferSelect;
export type InsertCartItem = z.infer<typeof insertCartItemSchema>;

// Delivery settings for marketplace
export const deliverySettings = pgTable("delivery_settings", {
  id: serial("id").primaryKey(),
  minimumOrderAmount: real("minimum_order_amount").notNull().default(0),
  baseDeliveryFee: real("base_delivery_fee").notNull().default(0),
  perKilometerFee: real("per_kilometer_fee").notNull().default(0),
  maximumDeliveryRadius: integer("maximum_delivery_radius").notNull().default(20), // in kilometers
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertDeliverySettingsSchema = createInsertSchema(deliverySettings).omit({
  id: true,
  updatedAt: true,
});

export type DeliverySetting = typeof deliverySettings.$inferSelect;
export type InsertDeliverySetting = z.infer<typeof insertDeliverySettingsSchema>;

// Relations
export const productTypesRelations = relations(productTypes, ({ many }) => ({
  products: many(products),
}));

export const categoriesRelations = relations(categories, ({ many }) => ({
  productTypes: many(productTypes, {
    relationName: "category_product_types",
  }),
}));

export const consumersRelations = relations(consumers, ({ many }) => ({
  orders: many(orders),
  cartItems: many(cartItems),
}));

export const ordersRelations = relations(orders, ({ one, many }) => ({
  consumer: one(consumers, {
    fields: [orders.consumerId],
    references: [consumers.id],
  }),
  orderItems: many(orderItems),
}));

export const productsRelations = relations(products, ({ one, many }) => ({
  farmer: one(farmers, {
    fields: [products.farmerId],
    references: [farmers.id],
  }),
  orderItems: many(orderItems),
  cartItems: many(cartItems),
}));
