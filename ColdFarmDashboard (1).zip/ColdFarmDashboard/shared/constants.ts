// Storage pricing constants
export const STORAGE_RATE_PER_KG_PER_DAY = 10; // XAF per kg per day
export const DEFAULT_CURRENCY = 'XAF';

// Duration constants (in milliseconds)
export const ONE_DAY_MS = 24 * 60 * 60 * 1000;

// Weight conversion constants
export const TON_TO_KG = 1000; // 1 ton = 1000 kg

// Function to calculate storage cost
export function calculateStorageCost(weightInKg: number, daysStored: number): number {
  return weightInKg * daysStored * STORAGE_RATE_PER_KG_PER_DAY;
}

// Function to calculate days between two dates
export function calculateDaysBetween(startDate: Date, endDate: Date = new Date()): number {
  const start = new Date(startDate).setHours(0, 0, 0, 0);
  const end = new Date(endDate).setHours(0, 0, 0, 0);
  const differenceMs = Math.abs(end - start);
  return Math.ceil(differenceMs / ONE_DAY_MS);
}

// Function to format currency with proper formatting
export function formatCurrency(amount: number, currency: string = DEFAULT_CURRENCY): string {
  return `${amount.toLocaleString()} ${currency}`;
}