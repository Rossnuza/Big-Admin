import { FarmerInventory } from './schema';
import { STORAGE_RATE_PER_KG_PER_DAY, calculateDaysBetween, formatCurrency } from './constants';

export interface StorageCostItem {
  inventoryId: number;
  productName: string;
  quantityInKg: number;
  daysStored: number;
  dailyRate: number;
  totalCost: number;
  formattedCost: string;
  startDate: Date;
  endDate?: Date | null;
  status: string;
}

export interface FarmerStorageSummary {
  farmerId: number;
  itemCount: number;
  totalWeight: number;
  totalCost: number;
  formattedCost: string;
  items: StorageCostItem[];
}

/**
 * Calculate storage costs for a single inventory item
 */
export function calculateInventoryItemCost(item: FarmerInventory): StorageCostItem {
  const endDate = item.endDate || new Date();
  const daysStored = calculateDaysBetween(item.startDate, endDate);
  const rate = STORAGE_RATE_PER_KG_PER_DAY; // Use constant rate
  
  // Convert quantity to kg based on unit if needed
  let quantityInKg = item.quantity;
  if (item.unit.toLowerCase() === 'ton' || item.unit.toLowerCase() === 'tons') {
    quantityInKg = item.quantity * 1000; // 1 ton = 1000 kg
  }
  
  const totalCost = quantityInKg * daysStored * rate;
  
  return {
    inventoryId: item.id,
    productName: item.productName,
    quantityInKg: quantityInKg,
    daysStored,
    dailyRate: rate,
    totalCost,
    formattedCost: formatCurrency(totalCost),
    startDate: item.startDate,
    endDate: item.endDate,
    status: item.status
  };
}

/**
 * Calculate total storage costs for a list of inventory items
 */
export function calculateFarmerStorageCosts(farmerId: number, items: FarmerInventory[]): FarmerStorageSummary {
  if (!items.length) {
    return {
      farmerId,
      itemCount: 0,
      totalWeight: 0,
      totalCost: 0,
      formattedCost: formatCurrency(0),
      items: []
    };
  }

  const costItems = items.map(calculateInventoryItemCost);
  
  const totalWeight = costItems.reduce((sum, item) => sum + item.quantityInKg, 0);
  const totalCost = costItems.reduce((sum, item) => sum + item.totalCost, 0);
  
  return {
    farmerId,
    itemCount: items.length,
    totalWeight,
    totalCost,
    formattedCost: formatCurrency(totalCost),
    items: costItems
  };
}

/**
 * Calculate daily storage cost for an inventory item
 */
export function calculateDailyStorageCost(item: FarmerInventory): number {
  const rate = STORAGE_RATE_PER_KG_PER_DAY;
  
  // Convert quantity to kg based on unit if needed
  let quantityInKg = item.quantity;
  if (item.unit.toLowerCase() === 'ton' || item.unit.toLowerCase() === 'tons') {
    quantityInKg = item.quantity * 1000; // 1 ton = 1000 kg
  }
  
  return quantityInKg * rate;
}

/**
 * Format storage costs as a detailed statement
 */
export function formatStorageStatement(summary: FarmerStorageSummary): string {
  let statement = `Storage Statement\n`;
  statement += `Total Items: ${summary.itemCount}\n`;
  statement += `Total Weight: ${summary.totalWeight.toFixed(2)} kg\n`;
  statement += `Total Cost: ${summary.formattedCost}\n\n`;
  
  statement += `Itemized Costs:\n`;
  summary.items.forEach((item, index) => {
    statement += `${index + 1}. ${item.productName}\n`;
    statement += `   Quantity: ${item.quantityInKg.toFixed(2)} kg\n`;
    statement += `   Days Stored: ${item.daysStored}\n`;
    statement += `   Rate: ${item.dailyRate} XAF per kg per day\n`;
    statement += `   Cost: ${item.formattedCost}\n\n`;
  });
  
  return statement;
}